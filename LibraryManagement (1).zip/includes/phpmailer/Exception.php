<?php
namespace PHPMailer\PHPMailer;

/**
 * PHPMailer exception handler
 *
 * Note: This is a simplified placeholder class for the actual PHPMailer library
 * In a production environment, you should install PHPMailer via Composer
 * or include the proper library files.
 */
class Exception extends \Exception
{
    /**
     * Prettify error message output
     * @return string
     */
    public function errorMessage()
    {
        return '<strong>' . htmlspecialchars($this->getMessage()) . "</strong><br />\n";
    }
} 