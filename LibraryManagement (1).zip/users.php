<?php 
session_start();
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php"; 

// Check if user is logged in as admin
if (!(isset($_SESSION['auth']) && $_SESSION['auth'] === true)) {
    header("Location: login.php?access=false");
    exit();
}
else {
    $admin = $_SESSION['admin'];
}

if(isset($_POST['del'])){

	$id = sanitize(trim($_POST['id']));
    // echo $id;

	$sql_del = "DELETE from admin where adminId = $id"; 
        $error = false;

	$result = mysqli_query($conn,$sql_del);
			if ($result)
			{
		      $error = true;
			}
			

 }


?>

<style>
    /* Enhanced Admin Navbar Styling */
    .admin-navbar {
        background: linear-gradient(to right, #0a9396, #005f73);
        border: none;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
        margin-bottom: 25px;
        border-radius: 0;
    }
    
    .admin-navbar .navbar-brand {
        color: #ffffff !important;
        font-weight: 700;
        font-size: 22px;
        letter-spacing: 0.5px;
        padding: 15px 15px;
        height: auto;
        display: flex;
        align-items: center;
    }
    
    .admin-navbar .navbar-brand i {
        font-size: 24px;
        margin-right: 8px;
        color: #e9d8a6;
    }
    
    .admin-navbar .navbar-nav > li > a {
        color: rgba(255, 255, 255, 0.9) !important;
        font-weight: 500;
        padding: 18px 15px;
        position: relative;
        text-transform: uppercase;
        font-size: 13px;
        letter-spacing: 0.5px;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li > a:hover,
    .admin-navbar .navbar-nav > li > a:focus,
    .admin-navbar .navbar-nav > li.active > a {
        color: #ffffff !important;
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .navbar-nav > li.active > a:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: #e9d8a6;
    }
    
    .admin-navbar .navbar-nav > li > a:hover:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: rgba(233, 216, 166, 0.7);
        transform: scaleX(0);
        transition: transform 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li > a:hover:after {
        transform: scaleX(1);
    }
    
    .admin-navbar .navbar-toggle {
        border-color: transparent;
        margin-top: 12px;
    }
    
    .admin-navbar .navbar-toggle .icon-bar {
        background-color: #ffffff;
        height: 2px;
    }
    
    .admin-navbar .navbar-collapse {
        border-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .user-welcome {
        display: flex;
        align-items: center;
        color: rgba(255, 255, 255, 0.9) !important;
        padding: 18px 15px;
        margin-right: 5px;
        font-weight: 500;
    }
    
    .admin-navbar .user-welcome i {
        color: #e9d8a6;
        margin-right: 8px;
        font-size: 16px;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a {
        background-color: rgba(255, 255, 255, 0.15);
        border-radius: 4px;
        padding: 8px 15px;
        margin: 10px 0;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:hover {
        background-color: rgba(255, 255, 255, 0.25);
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:after {
        display: none;
    }
    
    @media (max-width: 767px) {
        .admin-navbar .navbar-collapse {
            background-color: #005f73;
            max-height: none;
        }
        
        .admin-navbar .navbar-nav {
            margin: 0 -15px;
        }
        
        .admin-navbar .navbar-nav > li > a {
            padding: 12px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .admin-navbar .navbar-nav > li.active > a:after {
            display: none;
        }
        
        .admin-navbar .user-welcome {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding: 15px 20px;
            margin: 0;
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a {
            border-radius: 0;
            margin: 0;
            padding: 12px 20px;
        }
    }
    
    /* Enhanced Users Page Styles */
    .users-alert {
        background-color: #f8f9fa;
        border-left: 4px solid #0a9396;
        color: #333;
        padding: 15px 20px;
        margin-top: 25px;
        border-radius: 4px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        display: flex;
        align-items: center;
    }
    
    .users-alert i {
        font-size: 24px;
        color: #0a9396;
        margin-right: 10px;
    }
    
    .users-alert .admin_name {
        font-size: 18px;
        font-weight: 600;
    }
    
    .navbar-logo {
        height: 30px;
        margin-right: 10px;
    }
</style>

<div class="container-fluid">
    <!-- Custom Admin Navbar -->
    <nav class="navbar navbar-default admin-navbar">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#admin-navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="admin.php">
                    <img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
                    <i class="fa fa-tachometer"></i> Admin Dashboard
                </a>
            </div>

            <div class="collapse navbar-collapse" id="admin-navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="admin.php"><i class="fa fa-home"></i> Dashboard</a></li>
                    <li><a href="bookstable.php"><i class="fa fa-book"></i> Books</a></li>
                    <li class="active"><a href="users.php"><i class="fa fa-users"></i> Admins</a></li>
                    <li><a href="viewstudents.php"><i class="fa fa-graduation-cap"></i> Students</a></li>
                    <li><a href="borrowedbooks.php"><i class="fa fa-exchange"></i> Borrowed Books</a></li>
                    <li><a href="fines.php"><i class="fa fa-money"></i> Fines</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $admin; ?></li>
                    <li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- navbar ends -->
    
    <div class="container">
        <!-- info alert -->
        <div class="users-alert">
            <i class="fa fa-users"></i>
            <span class="admin_name">Users List</span>
        </div>
    </div>
    
    <div class="container">
        <div class="panel panel-default">
          <!-- Default panel contents -->
          <div class="panel-heading">
            <?php if(isset($error)===true) { ?>
        <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <strong>Record Deleted Successfully!</strong>
            </div>
            <?php } ?>
		  	<div class="row">
          <a href="adduser.php"><button class="btn btn-success col-lg-3 col-md-4 col-sm-11 col-xs-11 button" style="margin-left: 15px;margin-bottom: 5px"><span class="glyphicon glyphicon-plus-sign"></span> Add Admin</button></a>
		  		<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pull-right">
			  	<!-- <form action="users.php" method="post" enctype="multipart / form-data">
			  		<div class="input-group pull-right">
				      <span class="input-group-addon">
					  <button class="btn btn-success" name="search">Search</button> 
				      </span>
				      <input type="text" class="form-control" class="text" name="text" id="text">
			      </div>
			  	</form> -->
			    
			  </div>
			</div>
		  </div>
		  <table class="table table-bordered">

 	<thead>
	 <tr>
			  <th>adminId</th>
			  <th>adminName</th>
			  <th>password</th>
			  <th>username</th>
			  <th>email</th>
			   <th>Delete</th>
	 </tr>
	</thead>

		  <?php 
	$sql = "SELECT * from admin";

	$query = mysqli_query($conn, $sql);
    $counter = 1;
	while($row=mysqli_fetch_array($query)){ ?>
	   <tbody>
	   <td> <?php echo $counter++ ?></td>
	   <td> <?php echo $row['adminName']?></td>
	   <td> <?php echo $row['password']?></td>
	   <td> <?php echo $row['username']?></td>	
	   <td> <?php echo $row['email']?></td>
	   <form method='post' action='users.php'>
	   <input type='hidden' value="<?php echo $row['adminId']; ?>" name='id'>
	   <td><button name='del' type='submit' value='Delete' class='btn btn-warning' onclick='return Delete()'>DELETE</button></td>
	   </form>
	   </tbody>
	
	<?php } ?>
	
		   </table>
		 
	  </div>

		
	</div>

	<!-- Confirm delete modal begins here -->
	<div class="mod modal fade" id="popUpWindow">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			
        			<!-- header begins here -->
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
        				<h3 class="modal-title"> Warning</h3>
        			</div>

        			<!-- body begins here -->
        			<div class="modal-body">
        				<p>Are you sure you want to delete this book?</p>
        			</div>

        			<!-- button -->
        			<div class="modal-footer ">
        				<button class="col-lg-4 col-sm-4 col-xs-6 col-md-4 btn btn-warning pull-right"  style="margin-left: 10px" class="close" data-dismiss="modal">
        					No
        				</button>&nbsp;
        				<button class="col-lg-4 col-sm-4 col-xs-6 col-md-4 btn btn-success pull-right"  class="close" data-dismiss="modal" data-toggle="modal" data-target="#info">
        					Yes
        				</button>
        			</div>
        		</div>
        	</div>
        </div>
        <!-- Confirm delete modal ends here -->
        <!-- delete message modal starts here -->
        <div class="modal fade" id="info">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			
        			<!-- header begins here -->
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
        				<h3 class="modal-title"> Warning</h3>
        			</div>

        			<!-- body begins here -->
        			<div class="modal-body">
        				<p>Book deleted <span class="glyphicon glyphicon-ok"></span></p>
        			</div>

        		</div>
        	</div>
        </div>
        <!-- delete message modal ends here -->
        <!-- update modal begins here -->
        <div class="modal fade" id="update">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			
        			<!-- header begins here -->
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
        				<h2 class="modal-title"> Update</h2>
        			</div>

        			<!-- body begins here -->
        			<div class="modal-body">
        				<form role="form" >
        					<div class="input-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
        					   <span class="input-group-addon">ID</span>
        					   <input type="Username" class="form-control" name="id" value="1" contenteditable="disabled">
        						
        					</div><br>
        					<div class="input-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
        					   <span class="input-group-addon">Username</span>
        					   <input type="Username" class="form-control" name="id" value="1" contenteditable="disabled">
        						
        					</div><br>
        					<div class="input-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
        					   <span class="input-group-addon">Password</span>
        					   <input type="Username" class="form-control" name="id" value="1" contenteditable="disabled">
        						
        					</div><br>

        				
        				</form>
        			</div>

        			<!-- button -->
        			<div class="modal-footer">
        				<button class="col-lg-12 col-sm-12 col-xs-12 col-md-12 btn btn-success" data-target="alert">
        					UPDATE
        				</button>
        			</div>
        		</div>
        	</div>
        </div>
        <!-- update modal ends here -->
		




<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>	
<script type="text/javascript">

function Delete() {
            return confirm('Would you like to delete the user');
        }


function search(){
	alert("Hello Wildling!");
}
</script>
</body>
</html>