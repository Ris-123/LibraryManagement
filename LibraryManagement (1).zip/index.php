<?php
session_start();
// session_destroy();
// if (!(isset($_SESSION['auth']) && $_SESSION['auth'] === true)) {
// 	header("Location: admin.php?access=false");
// 	exit();
// }
// else {
 	// $admin = $_SESSION['admin'];
// }
require 'includes/snippet.php';
require 'includes/db-inc.php';
 include "includes/header.php";

	// if(isset($_SESSION['admin'])){
	// 	$admin = $_SESSION['admin'];
	// 	// echo "Hello $user";
	// }

 if(isset($_POST['submit'])){

    $news = sanitize(trim($_POST['news']));

    $sql = "INSERT into news (announcement) values ('$news')"; 

    $query = mysqli_query($conn,$sql);
    $error = false;

       if($query){
       $error = true;
      }
      else{
        echo "<script>alert('Not successful!! Try again.');
                    </script>"; 
      }
 }

     if(isset($_POST['UpDat'])){
		$id = sanitize(trim($_POST['id']));
        $text = sanitize(trim($_POST['text']));

        $sql_up = "UPDATE news set announcement = '$text' where newsId = '$id'";
		echo mysqli_error($sql_up);
         $result = mysqli_query($conn,$sql_del);
                if ($result)
                {
                    echo "<script>
            
           
                   alert('Update successful');

         </script>";
                }


     }

     if(isset($_POST['del'])){

        $id = sanitize(trim($_POST['id']));

        $sql_del = "DELETE from news where newsId = $id"; 

        $result = mysqli_query($conn,$sql_del);
                if ($result)
                {
         //            echo "<script>
            
         //    var response = confirm('Would you like to delete the user');
         //    if (response == true) {
         //        alert('User was successfully deleted from the database');
         //            location.href ='admin.php';
         //    }   

         //    else
         //        {
         //            alert('Could not delete user');
         //        }
            

         // </script>";
                }

     }






  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="flickity/flickity.css">
	<script type="text/javascript" src="flickity/flickity.js"></script>
	<title>RegentLibrary</title>
	<style>
		body {
			font-family: 'Arial', sans-serif;
			padding-top: 70px;
		}
		.navbar {
			background-color: #fff;
			border: none;
			box-shadow: 0 2px 10px rgba(0,0,0,0.1);
			transition: all 0.3s ease;
			padding: 10px 0;
		}
		.navbar-brand {
			color: #0a9396 !important;
			font-weight: bold;
			font-size: 24px;
			display: flex;
			align-items: center;
		}
		.navbar-brand i {
			color: #0a9396;
			margin-right: 8px;
			font-size: 28px;
		}
		.nav > li > a {
			color: #444 !important;
			font-weight: 500;
			text-transform: uppercase;
			font-size: 14px;
			padding: 15px;
			transition: all 0.3s ease;
			position: relative;
		}
		.nav > li > a:after {
			content: '';
			position: absolute;
			width: 0;
			height: 2px;
			background-color: #0a9396;
			bottom: 10px;
			left: 50%;
			transform: translateX(-50%);
			transition: all 0.3s ease;
		}
		.nav > li > a:hover:after,
		.nav > li.active > a:after {
			width: 70%;
		}
		.nav > li > a:hover,
		.nav > li > a:focus,
		.nav > li.active > a {
			background-color: transparent;
			color: #0a9396 !important;
		}
		.btn-register {
			background-color: #0a9396;
			color: white !important;
			border-radius: 30px;
			padding: 8px 24px !important;
			margin-top: 7px;
			margin-left: 10px;
			border: 2px solid #0a9396;
			font-weight: 600 !important;
			box-shadow: 0 4px 10px rgba(10, 147, 150, 0.3);
			text-transform: none !important;
		}
		.btn-register:hover {
			background-color: white !important;
			color: #0a9396 !important;
			border-color: #0a9396;
			transform: translateY(-2px);
		}
		.btn-register:after {
			display: none;
		}
		.navbar-toggle {
			border: none;
			background: transparent !important;
		}
		.navbar-toggle:hover {
			background: transparent !important;
		}
		.navbar-toggle .icon-bar {
			background-color: #0a9396 !important;
			width: 22px;
			transition: all 0.3s;
		}
		.navbar-toggle .top-bar {
			transform: rotate(45deg);
			transform-origin: 10% 10%;
		}
		.navbar-toggle .middle-bar {
			opacity: 0;
		}
		.navbar-toggle .bottom-bar {
			transform: rotate(-45deg);
			transform-origin: 10% 90%;
		}
		.navbar-toggle.collapsed .top-bar {
			transform: rotate(0);
		}
		.navbar-toggle.collapsed .middle-bar {
			opacity: 1;
		}
		.navbar-toggle.collapsed .bottom-bar {
			transform: rotate(0);
		}
		@media (max-width: 767px) {
			.navbar-nav {
				margin: 0;
			}
			.navbar-collapse {
				box-shadow: 0 5px 10px rgba(0,0,0,0.1);
				border: none;
				background-color: white;
				margin-top: 10px;
			}
			.nav > li > a:after {
				display: none;
			}
			.nav > li > a {
				padding: 15px 20px;
			}
			.btn-register {
				margin: 10px 20px;
				display: inline-block;
				text-align: center;
			}
		}
		.hero-section {
			background: linear-gradient(rgba(10, 147, 150, 0.9), rgba(10, 147, 150, 0.9)), url('images/header-bg.jpg');
			background-size: cover;
			background-position: center;
			padding: 80px 0;
			color: white;
			position: relative;
			min-height: 500px;
		}
		.hero-content {
			padding: 50px 0;
		}
		.hero-title {
			font-size: 36px;
			font-weight: bold;
			margin-bottom: 20px;
		}
		.hero-subtitle {
			font-size: 18px;
			margin-bottom: 20px;
		}
		.explore-btn {
			background-color: white;
			color: #0a9396;
			border-radius: 25px;
			padding: 10px 25px;
			font-weight: bold;
			margin-top: 20px;
			border: none;
		}
		.explore-btn i {
			margin-right: 5px;
		}
		.hero-image {
			text-align: center;
		}
		.hero-image img {
			max-width: 100%;
			height: auto;
		}
		.about-section {
			padding: 80px 0;
			background-color: #f8f9fa;
			position: relative;
			overflow: hidden;
		}
		.about-section::before {
			content: "";
			position: absolute;
			top: -50px;
			right: -50px;
			width: 200px;
			height: 200px;
			border-radius: 50%;
			background-color: rgba(10, 147, 150, 0.05);
			z-index: 0;
		}
		.about-section::after {
			content: "";
			position: absolute;
			bottom: -100px;
			left: -100px;
			width: 300px;
			height: 300px;
			border-radius: 50%;
			background-color: rgba(10, 147, 150, 0.05);
			z-index: 0;
		}
		.about-title {
			color: #0a9396;
			font-weight: bold;
			display: inline-block;
			padding: 10px 25px;
			border-radius: 30px;
			margin-bottom: 30px;
			background-color: rgba(10, 147, 150, 0.1);
			position: relative;
			z-index: 1;
		}
		.about-content {
			position: relative;
			z-index: 1;
			margin-bottom: 40px;
		}
		.about-content h3 {
			font-size: 32px;
			margin-bottom: 25px;
			color: #333;
			font-weight: 600;
		}
		.about-content p {
			font-size: 16px;
			line-height: 1.8;
			color: #666;
			margin-bottom: 20px;
		}
		.feature-card {
			background-color: white;
			border-radius: 10px;
			padding: 30px 25px;
			margin-bottom: 30px;
			box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
			transition: all 0.3s ease;
			height: 100%;
			position: relative;
			z-index: 1;
		}
		.feature-card:hover {
			transform: translateY(-5px);
			box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
		}
		.feature-icon {
			width: 70px;
			height: 70px;
			border-radius: 50%;
			background-color: rgba(10, 147, 150, 0.1);
			display: flex;
			align-items: center;
			justify-content: center;
			margin: 0 auto 20px;
		}
		.feature-icon i {
			font-size: 30px;
			color: #0a9396;
		}
		.feature-title {
			font-size: 20px;
			font-weight: 600;
			margin-bottom: 15px;
			color: #333;
		}
		.feature-text {
			font-size: 14px;
			line-height: 1.6;
			color: #777;
		}
		.stats-container {
			background-color: #0a9396;
			border-radius: 10px;
			padding: 40px 30px;
			color: white;
			margin-top: 40px;
			margin-bottom: 20px;
			box-shadow: 0 10px 30px rgba(10, 147, 150, 0.3);
			position: relative;
			z-index: 1;
		}
		.stat-item {
			text-align: center;
			padding: 0 15px;
		}
		.stat-number {
			font-size: 36px;
			font-weight: 700;
			margin-bottom: 10px;
			display: block;
		}
		.stat-text {
			font-size: 16px;
			opacity: 0.9;
		}
		@media (max-width: 767px) {
			.feature-card {
				margin-bottom: 20px;
			}
			.stats-container {
				padding: 20px;
			}
			.stat-item {
				margin-bottom: 20px;
			}
		}
	</style>
</head>
<body>
	<?php include "includes/nav.php"; ?>

	<section class="hero-section">
<div class="container">
			<div class="row">
				<div class="col-md-6 hero-content">
					<h1 class="hero-title">Improve Your Reading Experience Better Instantly</h1>
					<p class="hero-subtitle">We have 40k Book Choices & 500k+ Online registered readers. Discover your next favorite book with us today!</p>
					<button class="btn explore-btn"><i class="fa fa-book"></i> Explore Our Library</button>
					<br> <br>
					<div class="mt-4">
                                <ul class="list-unstyled d-flex align-items-center">
                                    <li class="d-flex me-3">
                                        <img src="https://edmy-react.hibootstrap.com/images/banner/client-1.jpg"
                                            alt="reader" class="client rounded-circle" width="50">
                                        <img src="https://edmy-react.hibootstrap.com/images/banner/client-2.jpg"
                                            alt="reader" class="client rounded-circle" style="margin-left: -15px;" width="50">
                                        <img src="https://edmy-react.hibootstrap.com/images/banner/client-3.jpg"
                                            alt="reader" class="client rounded-circle" style="margin-left: -15px;" width="50">
                                    </li>
                                    <li>
                                        <p class="mb-2">
                                            <span class="fw-bold">500k+</span> readers already trust us
                                        </p>
                                    </li>
                                </ul>
                            </div>
				</div>
				<div class="col-md-6 hero-image">
					<img src="https://edmy-react.hibootstrap.com/images/banner/banner-img-1.png" alt="Reading Experience">
			</div>
			</div>
		</div>
	</section>

	<section class="about-section" id="about">
		<div class="container">
			<h2 class="about-title">About Our Library System</h2>
			
			<div class="row about-content">
				<div class="col-md-10 col-md-offset-1">
					<h3>Transforming Library Management for the Digital Age</h3>
					<?php 
					$sql2 = "SELECT * from news ORDER BY newsId DESC LIMIT 1";
					$query2 = mysqli_query($conn, $sql2);
					if (mysqli_num_rows($query2) > 0) {
						$row = mysqli_fetch_array($query2);
						echo "<p class='announcement'>" . $row['announcement'] . "</p>";
					}
					?>
					<p>Regent Library is a comprehensive Library Management System designed to streamline and enhance the way libraries operate in the digital age. Our platform bridges the gap between traditional library services and modern technology, making it easier for both administrators and users to manage and access library resources.</p>
                    
                    <p>At Regent Library, we believe that knowledge should be easily accessible to everyone. Our mission is to empower libraries of all sizes with powerful digital tools that simplify administrative tasks, enhance user experience, and provide valuable insights through data-driven analytics.</p>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-4">
					<div class="feature-card">
						<div class="feature-icon">
							<i class="fa fa-book"></i>
						  </div>
						<h4 class="feature-title">Efficient Cataloging</h4>
						<p class="feature-text">Our system enables quick and accurate cataloging of books, journals, and digital resources with advanced search capabilities and metadata management. Administrators can easily add, update, and track all library materials.</p>
						  </div>
						  </div>
						  
				<div class="col-md-4">
					<div class="feature-card">
						<div class="feature-icon">
							<i class="fa fa-users"></i>
						</div>
						<h4 class="feature-title">User Management</h4>
						<p class="feature-text">Manage library members with ease through our intuitive user interface. Track borrowing history, manage permissions, and communicate with users directly through integrated notification systems.</p>
						  </div>
						  </div>

				<div class="col-md-4">
					<div class="feature-card">
						<div class="feature-icon">
							<i class="fa fa-exchange"></i>
						</div>
						<h4 class="feature-title">Smooth Circulation</h4>
						<p class="feature-text">Handle checkouts, returns, renewals, and reservations with minimal effort. Our system automates routine tasks, sends due date reminders, and calculates fines when necessary.</p>
					</div>
	  		</div>
		</div>

		  	<div class="row">
				<div class="col-md-4">
					<div class="feature-card">
						<div class="feature-icon">
							<i class="fa fa-bar-chart"></i>
						</div>
						<h4 class="feature-title">Insightful Analytics</h4>
						<p class="feature-text">Gain valuable insights into library usage patterns, popular resources, and user demographics. Our robust reporting tools help librarians make informed decisions about collection development.</p>
			</div>
		  </div>
				
				<div class="col-md-4">
					<div class="feature-card">
						<div class="feature-icon">
							<i class="fa fa-mobile"></i>
	  </div>
						<h4 class="feature-title">Accessible Anywhere</h4>
						<p class="feature-text">Our system is fully responsive and accessible on any device, allowing users to search the catalog, reserve items, and manage their accounts from anywhere, at any time.</p>
			</div>
	</div>

				<div class="col-md-4">
					<div class="feature-card">
						<div class="feature-icon">
							<i class="fa fa-shield"></i>
		  			</div>
						<h4 class="feature-title">Robust Security</h4>
						<p class="feature-text">Protect sensitive user data and valuable library assets with our advanced security features, including role-based access control, secure authentication, and regular backups.</p>
	  			</div>
	  			</div>
	  		</div>

			<div class="stats-container">
				<div class="row">
					<div class="col-md-3 col-sm-6">
						<div class="stat-item">
							<span class="stat-number">40,000+</span>
							<span class="stat-text">Books Available</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="stat-item">
							<span class="stat-number">500,000+</span>
							<span class="stat-text">Registered Users</span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="stat-item">
							<span class="stat-number">1,200+</span>
							<span class="stat-text">Libraries Served</span>
						</div>
				</div>
					<div class="col-md-3 col-sm-6">
						<div class="stat-item">
							<span class="stat-number">99.9%</span>
							<span class="stat-text">System Uptime</span>
				</div>
				</div>
				</div>
			</div>
			</div>
	</section>

	<footer class="footer" style="background-color: #f8f9fa; padding: 20px 0; margin-top: 50px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<p>&copy; <?php echo date('Y'); ?> Regent Library. All rights reserved.</p>
				</div>
			</div>
		</div>
	</footer>

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.js"></script>
</body>
</html>