<?php 
session_start();
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php"; 

// Check if user is logged in as admin
if (!(isset($_SESSION['auth']) && $_SESSION['auth'] === true)) {
    header("Location: login.php?access=false");
    exit();
}
else {
    $admin = $_SESSION['admin'];
}

// Get student ID from URL
if (isset($_GET['id'])) {
    $studentId = $_GET['id'];
    
    // Fetch student data
    $sql = "SELECT * FROM students WHERE studentId = '$studentId'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $student = mysqli_fetch_assoc($result);
    } else {
        echo "<script>alert('Student not found!'); window.location='viewstudents.php';</script>";
        exit();
    }
} else {
    header("Location: viewstudents.php");
    exit();
}

// Process form submission
if (isset($_POST['update'])) {
    $matric = sanitize(trim($_POST['matric_no']));
    $username = sanitize(trim($_POST['username']));
    $dept = sanitize(trim($_POST['dept']));
    $phone = sanitize(trim($_POST['phone']));
    
    // Check if password was updated
    if (!empty($_POST['password']) && !empty($_POST['password2'])) {
        $password = sanitize(trim($_POST['password']));
        $password2 = sanitize(trim($_POST['password2']));
        
        if ($password != $password2) {
            $password_error = "Passwords do not match!";
        } else {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Update query with password
            $update_sql = "UPDATE students SET 
                        matric_no = '$matric', 
                        username = '$username', 
                        dept = '$dept', 
                        phoneNumber = '$phone', 
                        password = '$hashed_password' 
                        WHERE studentId = '$studentId'";
        }
    } else {
        // Update query without password
        $update_sql = "UPDATE students SET 
                    matric_no = '$matric', 
                    username = '$username', 
                    dept = '$dept', 
                    phoneNumber = '$phone' 
                    WHERE studentId = '$studentId'";
    }
    
    // Execute update query if no password error
    if (!isset($password_error)) {
        $update_query = mysqli_query($conn, $update_sql);
        
        if ($update_query) {
            $success = true;
            // Refresh student data
            $result = mysqli_query($conn, $sql);
            $student = mysqli_fetch_assoc($result);
        } else {
            $update_error = "Failed to update student information: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Update Student - Easy Library</title>
    <style type="text/css">
        /* Enhanced Admin Navbar Styling */
        .admin-navbar {
            background: linear-gradient(to right, #0a9396, #005f73);
            border: none;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
            margin-bottom: 25px;
            border-radius: 0;
        }
        
        .admin-navbar .navbar-brand {
            color: #ffffff !important;
            font-weight: 700;
            font-size: 22px;
            letter-spacing: 0.5px;
            padding: 15px 15px;
            height: auto;
            display: flex;
            align-items: center;
        }
        
        .admin-navbar .navbar-brand i {
            font-size: 24px;
            margin-right: 8px;
            color: #e9d8a6;
        }
        
        .admin-navbar .navbar-nav > li > a {
            color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
            padding: 18px 15px;
            position: relative;
            text-transform: uppercase;
            font-size: 13px;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }
        
        .admin-navbar .navbar-nav > li > a:hover,
        .admin-navbar .navbar-nav > li > a:focus,
        .admin-navbar .navbar-nav > li.active > a {
            color: #ffffff !important;
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .admin-navbar .navbar-nav > li.active > a:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background-color: #e9d8a6;
        }
        
        .admin-navbar .navbar-nav > li > a:hover:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background-color: rgba(233, 216, 166, 0.7);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }
        
        .admin-navbar .navbar-nav > li > a:hover:after {
            transform: scaleX(1);
        }
        
        .admin-navbar .navbar-toggle {
            border-color: transparent;
            margin-top: 12px;
        }
        
        .admin-navbar .navbar-toggle .icon-bar {
            background-color: #ffffff;
            height: 2px;
        }
        
        .admin-navbar .navbar-collapse {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .admin-navbar .user-welcome {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.9) !important;
            padding: 18px 15px;
            margin-right: 5px;
            font-weight: 500;
        }
        
        .admin-navbar .user-welcome i {
            color: #e9d8a6;
            margin-right: 8px;
            font-size: 16px;
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a {
            background-color: rgba(255, 255, 255, 0.15);
            border-radius: 4px;
            padding: 8px 15px;
            margin: 10px 0;
            transition: all 0.3s ease;
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a:hover {
            background-color: rgba(255, 255, 255, 0.25);
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a:after {
            display: none;
        }
        
        @media (max-width: 767px) {
            .admin-navbar .navbar-collapse {
                background-color: #005f73;
                max-height: none;
            }
            
            .admin-navbar .navbar-nav {
                margin: 0 -15px;
            }
            
            .admin-navbar .navbar-nav > li > a {
                padding: 12px 20px;
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            }
            
            .admin-navbar .navbar-nav > li.active > a:after {
                display: none;
            }
            
            .admin-navbar .user-welcome {
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                padding: 15px 20px;
                margin: 0;
            }
            
            .admin-navbar .navbar-nav > li.logout-btn > a {
                border-radius: 0;
                margin: 0;
                padding: 12px 20px;
            }
        }
        
        .update-container {
            max-width: 800px;
            margin: 40px auto;
        }
        
        .update-card {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-bottom: 30px;
        }
        
        .update-header {
            text-align: center;
            margin-bottom: 30px;
            color: #0a9396;
            border-bottom: 2px solid #e9d8a6;
            padding-bottom: 15px;
        }
        
        .update-header h2 {
            font-weight: 700;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .update-header p {
            color: #666;
            font-size: 16px;
            margin-bottom: 0;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .control-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }
        
        .form-control {
            height: 45px;
            border-radius: 4px;
            border: 1px solid #ddd;
            padding: 10px 15px;
            font-size: 15px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #0a9396;
            box-shadow: 0 0 8px rgba(10, 147, 150, 0.2);
        }
        
        .help-block {
            color: #dc3545;
            font-size: 13px;
            margin-top: 5px;
        }
        
        .btn-update {
            background: linear-gradient(to right, #0a9396, #005f73);
            color: white;
            border: none;
            border-radius: 4px;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .btn-update:hover {
            background: linear-gradient(to right, #005f73, #003d47);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .btn-cancel {
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .btn-cancel:hover {
            background: #5a6268;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .alert {
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background-color: #d1e7dd;
            border-color: #badbcc;
            color: #0f5132;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c2c7;
            color: #842029;
        }
        
        .input-group-addon {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-right: none;
            color: #0a9396;
        }
        
        .input-group-addon i {
            width: 16px;
        }
        
        .form-section {
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 25px;
        }
        
        .form-section-title {
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 20px;
            color: #0a9396;
            font-weight: 600;
        }
        
        .readonly-field {
            background-color: #f8f9fa;
            cursor: not-allowed;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Custom Admin Navbar -->
        <nav class="navbar navbar-default admin-navbar">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#admin-navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="admin.php">
                        <i class="fa fa-tachometer"></i> Admin Dashboard
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="admin-navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="admin.php"><i class="fa fa-home"></i> Dashboard</a></li>
                        <li><a href="bookstable.php"><i class="fa fa-book"></i> Books</a></li>
                        <li><a href="users.php"><i class="fa fa-users"></i> Admins</a></li>
                        <li class="active"><a href="viewstudents.php"><i class="fa fa-graduation-cap"></i> Students</a></li>
                        <li><a href="borrowedbooks.php"><i class="fa fa-exchange"></i> Borrowed Books</a></li>
                        <li><a href="fines.php"><i class="fa fa-money"></i> Fines</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $admin; ?></li>
                        <li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- navbar ends -->
    </div>
    
    <div class="container">
        <div class="update-container">
            <div class="update-card">
                <div class="update-header">
                    <h2><i class="fa fa-user-circle"></i> Update Student</h2>
                    <p>Modify student information</p>
                </div>

                <?php if(isset($success) && $success === true) { ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong><i class="fa fa-check-circle"></i> Success!</strong> Student information has been updated successfully.
                </div>
                <?php } ?>
                
                <?php if(isset($update_error)) { ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong><i class="fa fa-exclamation-circle"></i> Error!</strong> <?php echo $update_error; ?>
                </div>
                <?php } ?>
                
                <form class="form-horizontal" role="form" action="updatestudent.php?id=<?php echo $studentId; ?>" method="post">
                    <div class="form-section">
                        <div class="form-section-title">Student Information</div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name" class="control-label">Full Name (Read-only)</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                        <input type="text" class="form-control readonly-field" value="<?php echo $student['name']; ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="matric_no" class="control-label">Matric Number</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-id-card"></i></span>
                                        <input type="text" class="form-control" name="matric_no" value="<?php echo $student['matric_no']; ?>" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="dept" class="control-label">Department</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-building"></i></span>
                                        <input type="text" class="form-control" name="dept" value="<?php echo $student['dept']; ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone" class="control-label">Phone Number</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                        <input type="text" class="form-control" name="phone" value="<?php echo $student['phoneNumber']; ?>" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="email" class="control-label">Email Address (Read-only)</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                <input type="email" class="form-control readonly-field" value="<?php echo $student['email']; ?>" readonly>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <div class="form-section-title">Account Information</div>
                        <div class="form-group">
                            <label for="username" class="control-label">Username</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user-circle"></i></span>
                                <input type="text" class="form-control" name="username" value="<?php echo $student['username']; ?>" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="password" class="control-label">New Password (Leave blank to keep current)</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                        <input type="password" class="form-control" name="password" placeholder="Enter new password">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="password2" class="control-label">Confirm New Password</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                        <input type="password" class="form-control" name="password2" placeholder="Confirm new password">
                                    </div>
                                    <?php if(isset($password_error)) { ?>
                                    <span class="help-block"><i class="fa fa-exclamation-triangle"></i> <?php echo $password_error; ?></span>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-update" name="update">
                                        <i class="fa fa-save"></i> Update Student
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <a href="viewstudents.php" class="btn btn-cancel">
                                        <i class="fa fa-times"></i> Cancel
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html> 