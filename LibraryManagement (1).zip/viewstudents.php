<?php 
session_start();
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php"; 

// Check if user is logged in as admin
if (!(isset($_SESSION['auth']) && $_SESSION['auth'] === true)) {
    header("Location: login.php?access=false");
    exit();
}
else {
    $admin = $_SESSION['admin'];
}

if (isset($_POST['submit'])) {
	$id = trim($_POST['del_btn']);
	$sql = "DELETE from students where studentId = '$id' ";
	$query = mysqli_query($conn, $sql);

	if ($query) {
		echo "<script>alert('Student Deleted!')</script>";
	}
}

?>

<style>
    /* Enhanced Admin Navbar Styling */
    .admin-navbar {
        background: linear-gradient(to right, #0a9396, #005f73);
        border: none;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
        margin-bottom: 25px;
        border-radius: 0;
    }
    
    .admin-navbar .navbar-brand {
        color: #ffffff !important;
        font-weight: 700;
        font-size: 22px;
        letter-spacing: 0.5px;
        padding: 15px 15px;
        height: auto;
        display: flex;
        align-items: center;
    }
    
    .admin-navbar .navbar-brand i {
        font-size: 24px;
        margin-right: 8px;
        color: #e9d8a6;
    }
    
    .admin-navbar .navbar-nav > li > a {
        color: rgba(255, 255, 255, 0.9) !important;
        font-weight: 500;
        padding: 18px 15px;
        position: relative;
        text-transform: uppercase;
        font-size: 13px;
        letter-spacing: 0.5px;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li > a:hover,
    .admin-navbar .navbar-nav > li > a:focus,
    .admin-navbar .navbar-nav > li.active > a {
        color: #ffffff !important;
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .navbar-nav > li.active > a:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: #e9d8a6;
    }
    
    .admin-navbar .navbar-nav > li > a:hover:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: rgba(233, 216, 166, 0.7);
        transform: scaleX(0);
        transition: transform 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li > a:hover:after {
        transform: scaleX(1);
    }
    
    .admin-navbar .navbar-toggle {
        border-color: transparent;
        margin-top: 12px;
    }
    
    .admin-navbar .navbar-toggle .icon-bar {
        background-color: #ffffff;
        height: 2px;
    }
    
    .admin-navbar .navbar-collapse {
        border-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .user-welcome {
        display: flex;
        align-items: center;
        color: rgba(255, 255, 255, 0.9) !important;
        padding: 18px 15px;
        margin-right: 5px;
        font-weight: 500;
    }
    
    .admin-navbar .user-welcome i {
        color: #e9d8a6;
        margin-right: 8px;
        font-size: 16px;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a {
        background-color: rgba(255, 255, 255, 0.15);
        border-radius: 4px;
        padding: 8px 15px;
        margin: 10px 0;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:hover {
        background-color: rgba(255, 255, 255, 0.25);
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:after {
        display: none;
    }
    
    @media (max-width: 767px) {
        .admin-navbar .navbar-collapse {
            background-color: #005f73;
            max-height: none;
        }
        
        .admin-navbar .navbar-nav {
            margin: 0 -15px;
        }
        
        .admin-navbar .navbar-nav > li > a {
            padding: 12px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .admin-navbar .navbar-nav > li.active > a:after {
            display: none;
        }
        
        .admin-navbar .user-welcome {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding: 15px 20px;
            margin: 0;
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a {
            border-radius: 0;
            margin: 0;
            padding: 12px 20px;
        }
    }
    
    /* Enhanced Students Page Styles */
    .students-alert {
        background-color: #f8f9fa;
        border-left: 4px solid #0a9396;
        color: #333;
        padding: 15px 20px;
        margin-top: 25px;
        border-radius: 4px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        display: flex;
        align-items: center;
    }
    
    .students-alert i {
        font-size: 24px;
        color: #0a9396;
        margin-right: 10px;
    }
    
    .students-alert strong {
        font-size: 18px;
        font-weight: 600;
    }
    
    .navbar-logo {
        height: 30px;
        margin-right: 10px;
    }
</style>

<div class="container-fluid">
    <!-- Custom Admin Navbar -->
    <nav class="navbar navbar-default admin-navbar">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#admin-navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="admin.php">
                    <img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
                    <i class="fa fa-tachometer"></i> Admin Dashboard
                </a>
            </div>

            <div class="collapse navbar-collapse" id="admin-navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="admin.php"><i class="fa fa-home"></i> Dashboard</a></li>
                    <li><a href="bookstable.php"><i class="fa fa-book"></i> Books</a></li>
                    <li><a href="users.php"><i class="fa fa-users"></i> Admins</a></li>
                    <li class="active"><a href="viewstudents.php"><i class="fa fa-graduation-cap"></i> Students</a></li>
                    <li><a href="borrowedbooks.php"><i class="fa fa-exchange"></i> Borrowed Books</a></li>
                    <li><a href="fines.php"><i class="fa fa-money"></i> Fines</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $admin; ?></li>
                    <li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- navbar ends -->
    
    <div class="container">
        <!-- info alert -->
        <div class="students-alert">
            <i class="fa fa-graduation-cap"></i>
            <strong>Student Table</strong>
        </div>
    </div>
    
    <div class="container col-lg-11">
        <div class="panel panel-default">
          <!-- Default panel contents -->
          <div class="panel-heading">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <!-- <form >
                    <div class="input-group pull-right">
                      <span class="input-group-addon">
                        <label>Search</label> 
                      </span>
                      <input type="text" class="form-control" onkeyup="hey()">
                  </div>
                </form> -->
                
              </div><!-- /.col-lg-6 -->
              </div>
          </div>
          <table class="table table-bordered">
            <thead>
                 <tr>
                 	  <th>ID</th> 
                    <th>Student Name</th>
                    <th>Matric No</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>Phone No.</th>
                    
                    <th>Username</th>
                    <th>Password</th>
                    <th>Actions</th>
                  </tr>    
            </thead>    
            <?php 

            $sql = "SELECT * FROM students";
            $query = mysqli_query($conn, $sql);
            $counter = 1;
            while ( $row = mysqli_fetch_assoc($query)) {        	
             ?>
            <tbody> 
              <tr> 
               <td><?php echo $counter++; ?></td>
               <td><?php echo $row['name']; ?></td>
               <td><?php echo $row['matric_no']; ?></td>
               <td><?php echo $row['email']; ?></td>
               <td><?php echo $row['dept']; ?></td>
               <td><?php echo $row['phoneNumber']; ?></td>
               
               <td><?php echo $row['username']; ?></td>
               <td><?php echo $row['password']; ?></td>
               <td>
                <div class="btn-group">
                  <a href="updatestudent.php?id=<?php echo $row['studentId']; ?>" class="btn btn-info">
                    <i class="fa fa-edit"></i> UPDATE
                  </a>
                  <form action="viewstudents.php" method="post" style="display: inline;">
                    <input type="hidden" value="<?php echo $row['studentId']; ?>" name="del_btn">
                    <button name="submit" class="btn btn-warning">
                      <i class="fa fa-trash"></i> DELETE
                    </button>
                  </form>
                </div>
               </td>
              </tr> 
		           
           </tbody> 
           <?php } ?>
     </table>
		 
</div>
</div>
<div class="mod modal fade" id="popUpWindow">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			
        			<!-- header begins here -->
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
        				<h3 class="modal-title"> Warning</h3>
        			</div>

        			<!-- body begins here -->
        			<div class="modal-body">
        				<p>Are you sure you want to delete this Member?</p>
        			</div>

        			<!-- button -->
        			<div class="modal-footer ">
        				<button class="col-lg-4 col-sm-4 col-xs-6 col-md-4 btn btn-warning pull-right"  style="margin-left: 10px" class="close" data-dismiss="modal">
        					No
        				</button>&nbsp;
        				<button class="col-lg-4 col-sm-4 col-xs-6 col-md-4 btn btn-success pull-right"  class="close" data-dismiss="modal" data-toggle="modal" data-target="#info">
        					Yes
        				</button>
        			</div>
        		</div>
        	</div>
        </div>
        <div class="modal fade" id="info">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			
        			<!-- header begins here -->
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
        				<h3 class="modal-title"> Warning</h3>
        			</div>

        			<!-- body begins here -->
        			<div class="modal-body">
        				<p>Member deleted <span class="glyphicon glyphicon-ok"></span></p>
        			</div>

        		</div>
        	</div>
        </div>
		




<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>	
<script type="text/javascript">
function hey(){
	alert("Hello");
}
</script>
</body>
</html>