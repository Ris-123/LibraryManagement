<?php 
// Only start session if one hasn't been started already
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Get current page filename for active menu highlighting
$currentPage = basename($_SERVER['PHP_SELF']);

// Check for admin login
if (isset($_SESSION['admin'])) {
    $admin = $_SESSION['admin'];
?>
<!-- Admin Navbar -->
<nav class="navbar navbar-default navbar-fixed-top admin-navbar">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="adminportal.php">
                <img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
                <i class="fa fa-book"></i> Regent Library
            </a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example">
            <ul class="nav navbar-nav">
                <li <?php echo ($currentPage == 'adminportal.php') ? 'class="active"' : ''; ?>>
                    <a href="adminportal.php"><i class="fa fa-dashboard"></i> Dashboard</a>
                </li>
                <li <?php echo ($currentPage == 'addbook.php') ? 'class="active"' : ''; ?>>
                    <a href="addbook.php"><i class="fa fa-book"></i> Add Book</a>
                </li>
                <li <?php echo ($currentPage == 'viewstudents.php') ? 'class="active"' : ''; ?>>
                    <a href="viewstudents.php"><i class="fa fa-users"></i> View Students</a>
                </li>
                <li <?php echo ($currentPage == 'viewbooks.php') ? 'class="active"' : ''; ?>>
                    <a href="viewbooks.php"><i class="fa fa-list"></i> View Books</a>
                </li>
                <li <?php echo ($currentPage == 'borrow.php') ? 'class="active"' : ''; ?>>
                    <a href="borrow.php"><i class="fa fa-exchange"></i> Borrow Books</a>
                </li>
                <li <?php echo ($currentPage == 'return.php') ? 'class="active"' : ''; ?>>
                    <a href="return.php"><i class="fa fa-undo"></i> Return Books</a>
                </li>
                <li <?php echo ($currentPage == 'fines.php') ? 'class="active"' : ''; ?>>
                    <a href="fines.php"><i class="fa fa-money"></i> Fines</a>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="user-welcome">
                    <i class="fa fa-user-circle"></i> Hello, <?php echo isset($admin) ? $admin : 'Admin'; ?>
                </li>
                <li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<?php 
} elseif (isset($_SESSION['student-name'])) {
    // Student login
    $student = $_SESSION['student-name'];
    // Student navbar would go here if needed
    // For now, we'll redirect to student portal
    if ($currentPage != 'studentportal.php') {
        echo "<script>window.location.href = 'studentportal.php';</script>";
    }
} else {
    // Guest navbar (before login)
?>
<!-- Guest Navbar -->
<nav class="navbar navbar-default navbar-fixed-top guest-navbar">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#guest-navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">
                <img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
                <!-- <i class="fa fa-book"></i> Easy Library -->
            </a>
        </div>

        <div class="collapse navbar-collapse" id="guest-navbar">
            <ul class="nav navbar-nav">
                <!-- Left side is now empty -->
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li <?php echo ($currentPage == 'index.php' || $currentPage == '') ? 'class="active"' : ''; ?>>
                    <a href="index.php"><i class="fa fa-home"></i> Home</a>
                </li>
                <li <?php echo ($currentPage == 'contact.php') ? 'class="active"' : ''; ?>>
                    <a href="contact.php"><i class="fa fa-envelope"></i> Contact</a>
                </li>
                <li <?php echo ($currentPage == 'addstudent.php') ? 'class="active"' : ''; ?>>
                    <a href="addstudent.php"><i class="fa fa-user-plus"></i> Register</a>
                </li>
                <li <?php echo ($currentPage == 'login.php') ? 'class="active"' : ''; ?>>
                    <a href="login.php"><i class="fa fa-sign-in"></i> Login</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php } ?>

<style type="text/css">
    /* Admin Navbar Styles */
    .admin-navbar {
        background: linear-gradient(to right, #2c3e50, #3498db);
        border: none;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
        margin-bottom: 25px;
        border-radius: 0;
    }
    
    .admin-navbar .navbar-brand {
        color: #ffffff !important;
        font-weight: 700;
        font-size: 22px;
        letter-spacing: 0.5px;
        padding: 15px 15px;
        height: auto;
        display: flex;
        align-items: center;
    }
    
    .admin-navbar .navbar-brand i {
        font-size: 24px;
        margin-right: 8px;
        color: #f1c40f;
    }
    
    .admin-navbar .navbar-nav > li > a {
        color: rgba(255, 255, 255, 0.9) !important;
        font-weight: 500;
        padding: 18px 15px;
        position: relative;
        text-transform: uppercase;
        font-size: 13px;
        letter-spacing: 0.5px;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li > a:hover,
    .admin-navbar .navbar-nav > li > a:focus,
    .admin-navbar .navbar-nav > li.active > a {
        color: #ffffff !important;
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .navbar-nav > li.active > a:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: #f1c40f;
    }
    
    .admin-navbar .navbar-nav > li > a:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: rgba(241, 196, 15, 0.7);
        transform: scaleX(0);
        transition: transform 0.3s ease;
        transform-origin: center;
    }
    
    .admin-navbar .navbar-nav > li > a:hover:after {
        transform: scaleX(1);
    }
    
    .admin-navbar .navbar-toggle {
        border-color: transparent;
        margin-top: 12px;
    }
    
    .admin-navbar .navbar-toggle .icon-bar {
        background-color: #ffffff;
        height: 2px;
    }
    
    .admin-navbar .navbar-collapse {
        border-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .user-welcome {
        display: flex;
        align-items: center;
        color: rgba(255, 255, 255, 0.9) !important;
        padding: 18px 15px;
        margin-right: 5px;
        font-weight: 500;
    }
    
    .admin-navbar .user-welcome i {
        color: #f1c40f;
        margin-right: 8px;
        font-size: 16px;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a {
        background-color: rgba(255, 255, 255, 0.15);
        border-radius: 4px;
        padding: 8px 15px;
        margin: 10px 0;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:hover {
        background-color: rgba(255, 255, 255, 0.25);
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:after {
        display: none;
    }
    
    .navbar-logo {
        height: 30px;
        margin-right: 10px;
    }
    
    /* Guest Navbar Styles */
    .guest-navbar {
        background: linear-gradient(to right,rgb(52, 219, 88),rgb(41, 137, 185));
        border: none;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
        margin-bottom: 25px;
        border-radius: 0;
    }
    
    .guest-navbar .navbar-brand {
        color: #ffffff !important;
        font-weight: 700;
        font-size: 22px;
        letter-spacing: 0.5px;
        padding: 15px 15px;
        height: auto;
        display: flex;
        align-items: center;
    }
    
    .guest-navbar .navbar-brand i {
        font-size: 24px;
        margin-right: 8px;
        color: #f1c40f;
    }
    
    .guest-navbar .navbar-nav > li > a {
        color: rgba(255, 255, 255, 0.9) !important;
        font-weight: 500;
        padding: 18px 15px;
        position: relative;
        text-transform: uppercase;
        font-size: 13px;
        letter-spacing: 0.5px;
        transition: all 0.3s ease;
    }
    
    .guest-navbar .navbar-nav > li > a:hover,
    .guest-navbar .navbar-nav > li > a:focus,
    .guest-navbar .navbar-nav > li.active > a {
        color: #ffffff !important;
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .guest-navbar .navbar-nav > li.active > a:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: #f1c40f;
    }
    
    /* Clean implementation of the hover effect */
    .guest-navbar .navbar-nav > li > a:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        width: 0;
        height: 3px;
        background-color: rgba(241, 196, 15, 0.9);
        transition: all 0.3s ease;
    }
    
    .guest-navbar .navbar-nav > li > a:hover:after {
        width: 100%;
        left: 0;
    }
    
    .guest-navbar .navbar-logo {
        height: 30px;
        margin-right: 10px;
    }
    
    @media (max-width: 767px) {
        .admin-navbar .navbar-collapse,
        .guest-navbar .navbar-collapse {
            background-color: #2c3e50;
            max-height: none;
        }
        
        .admin-navbar .navbar-nav,
        .guest-navbar .navbar-nav {
            margin: 0 -15px;
        }
        
        .admin-navbar .navbar-nav > li > a,
        .guest-navbar .navbar-nav > li > a {
            padding: 12px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .admin-navbar .navbar-nav > li.active > a:after,
        .guest-navbar .navbar-nav > li.active > a:after {
            display: none;
        }
        
        .admin-navbar .user-welcome {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding: 15px 20px;
            margin: 0;
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a {
            border-radius: 0;
            margin: 0;
            padding: 12px 20px;
        }
    }
</style> 