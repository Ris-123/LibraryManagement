<?php
/**
 * Script to add logo to all navbar-brand elements in the project
 * 
 * This script will scan all PHP files in the current directory and its subdirectories,
 * looking for navbar-brand elements and adding the logo image to them if missing.
 */

// Configuration
$logoPath = 'images/logo.png';
$logoAlt = 'Easy Library Logo';
$logoClass = 'navbar-logo';
$cssStyle = '
.navbar-logo {
    height: 30px;
    margin-right: 10px;
}';

// Function to process a file
function processFile($filePath, $logoPath, $logoAlt, $logoClass, $cssStyle) {
    echo "Processing file: $filePath\n";
    
    // Read file contents
    $content = file_get_contents($filePath);
    $modified = false;
    
    // Check if the file contains navbar-brand
    if (strpos($content, 'navbar-brand') !== false) {
        // Add logo to navbar-brand
        $pattern = '/<a\s+class="navbar-brand"([^>]*)>/i';
        $replacement = '<a class="navbar-brand"$1><img src="' . $logoPath . '" alt="' . $logoAlt . '" class="' . $logoClass . '"> ';
        
        // Only replace if the logo doesn't already exist
        if (strpos($content, $logoPath) === false) {
            $newContent = preg_replace($pattern, $replacement, $content);
            if ($newContent !== $content) {
                $content = $newContent;
                $modified = true;
                echo "  - Added logo to navbar-brand\n";
            }
        } else {
            echo "  - Logo already exists in navbar-brand\n";
        }
        
        // Add CSS style for logo if it doesn't exist
        if (strpos($content, '.navbar-logo') === false) {
            // Look for style tag
            $stylePattern = '/<style[^>]*>(.*?)<\/style>/s';
            if (preg_match($stylePattern, $content, $matches)) {
                $oldStyle = $matches[0];
                $newStyle = str_replace('</style>', $cssStyle . "\n</style>", $oldStyle);
                $content = str_replace($oldStyle, $newStyle, $content);
                $modified = true;
                echo "  - Added CSS style for logo\n";
            } else {
                // Add style tag before </head>
                $headClosePattern = '/<\/head>/i';
                $styleTag = '<style type="text/css">' . $cssStyle . '</style>' . "\n</head>";
                $content = preg_replace($headClosePattern, $styleTag, $content);
                $modified = true;
                echo "  - Added style tag with logo CSS\n";
            }
        } else {
            echo "  - Logo CSS already exists\n";
        }
        
        // Save changes if modified
        if ($modified) {
            file_put_contents($filePath, $content);
            echo "  - File saved with changes\n";
        } else {
            echo "  - No changes needed\n";
        }
    } else {
        echo "  - No navbar-brand found, skipping\n";
    }
}

// Function to recursively scan directory
function scanDirectory($dir, $logoPath, $logoAlt, $logoClass, $cssStyle) {
    $files = scandir($dir);
    
    foreach ($files as $file) {
        if ($file == '.' || $file == '..') continue;
        
        $path = $dir . '/' . $file;
        
        if (is_dir($path)) {
            scanDirectory($path, $logoPath, $logoAlt, $logoClass, $cssStyle);
        } elseif (pathinfo($path, PATHINFO_EXTENSION) == 'php') {
            processFile($path, $logoPath, $logoAlt, $logoClass, $cssStyle);
        }
    }
}

// Process only specific files from the grep results
$filesToProcess = [
    'viewstudents.php',
    'users.php',
    'updatestudent.php',
    'profile.php',
    'lend-student.php',
    'fines.php',
    'fine-student.php',
    'cart.php',
    'borrow-student.php',
    'borrowedbooks.php',
    'admin.php',
    'adduser.php'
];

echo "Starting logo addition process...\n";

foreach ($filesToProcess as $file) {
    if (file_exists($file)) {
        processFile($file, $logoPath, $logoAlt, $logoClass, $cssStyle);
    } else {
        echo "File not found: $file\n";
    }
}

echo "Process completed!\n"; 