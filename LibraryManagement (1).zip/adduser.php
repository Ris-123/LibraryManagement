<?php 
session_start(); // Add session_start at the top to avoid errors
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

// echo "Hello Uche";

if (isset($_POST['submit'])) {
	//Getting the values from the forms
	$name = sanitize(trim($_POST['name']));
	$username = sanitize(trim($_POST['username']));
	$password1 = sanitize(trim($_POST['password1']));
	$password2 = sanitize(trim($_POST['password2']));
	$email = sanitize(trim($_POST['email']));
			 		
	// $img_picture = upload_image($_FILES['postimg']);
	// if($img_picture != false ){
	// 	$img_picture_path = $img_picture;
	// }

	  //Process the image that is uploaded by the user
  // $target_dir = "uploads/";
  // $target_file = $target_dir . basename($_FILES["imageUpload"]["name"]);
  // $uploadOk = 1;
  // $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

  // if (move_uploaded_file($_FILES["imageUpload"]["tmp_name"], $target_file)) {
  //     echo "The file ". basename( $_FILES["imageUpload"]["name"]). " has been uploaded.";
  // } else {
  //     echo "Sorry, there was an error uploading your file.";
  // }

  // $image=basename( $_FILES["imageUpload"]["name"],".jpg"); // used to store the filename in a variable


if (isset($_FILES['postimg'])) {
        $img_size = $_FILES['postimg']['size'];
        $temp = $_FILES['postimg']['tmp_name'];
        $img_type = $_FILES['postimg']['type'];
        $img_name = $_FILES['postimg']['name'];

        if ($img_size > 500000) {
            $err_flag = true;
            $error_msg = "Your image size is too big... Try again.";
        }

        $extensions = array('jpg', 'jpeg', 'png', 'gif');
        $img_ext = explode('/', $img_type);
        $img_ext = end($img_ext);
        $img_ext = strtolower($img_ext);
        if (!(in_array($img_ext, $extensions))) {
            $err_flag = true;
            $error_msg = "Unwanted image file type... Only jpg, jpeg, png and gif allowed";
        }
// Prepare image folder in the server
//      $imgFile = 'posts-images/';
		
		// $filepath = $imgFile . basename($img_name);
		// $thumb_path = "";
		// if (!isset($err_flag) && $err_flag === false) {
		// 	$result = move_uploaded_file($temp, $filepath);
		// 	if ($result) {
		// 		$magicianObj = new imageLib($filepath);
 //            $magicianObj -> resizeImage(150, 150);
 //            $magicianObj -> saveImage($imgFile . 'thumbnails/', 100);
		// 		$img_path = $imgFile.$filepath;
		// 		$thumb_path = $imgFile . 'thumbnails/' . $filepath;
		// 	}
		// }

	$upload_dir = 'posts-images/';
	if(!is_dir($upload_dir)){
		mkdir($upload_dir);
	}
	$img_path = "";
	$img_path = $upload_dir.time().mt_rand(10,99).'.'.$img_ext;

	if (!isset($err_flag)) {
		$send = move_uploaded_file($temp, $img_path);
		if(!$send){
			$upload_error = "File upload failed. Please try again.";
		}
	}
}





//Check if the password matches
	if ($password1 == $password2) {
		//create an sql statement
	$sql = "INSERT into admin (adminName, password, username, email, photo) values ('$name', '$password1', '$username', '$email', '$img_path')";
	 
	// Removing the undefined variable reference
	// echo $img_picture;

	//query the database
	$query = mysqli_query($conn, $sql);
	$error = false;

	if ($query) {
	$error = true;
	}
	else {
	echo "<script>alert('Admin not added!');
				</script>";	
	}

	}

	else {
		echo  "<script>alert('Password mismatched!')</script>";
	}

	
}

 ?>

<div class="container-fluid">
    <!-- Custom Admin Navbar -->
    <nav class="navbar navbar-default admin-navbar">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#admin-navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="admin.php">
                    <img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
                    <i class="fa fa-tachometer"></i> Admin Dashboard
                </a>
            </div>

            <div class="collapse navbar-collapse" id="admin-navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="admin.php"><i class="fa fa-home"></i> Dashboard</a></li>
                    <li><a href="bookstable.php"><i class="fa fa-book"></i> Books</a></li>
                    <li class="active"><a href="users.php"><i class="fa fa-users"></i> Admins</a></li>
                    <li><a href="viewstudents.php"><i class="fa fa-graduation-cap"></i> Students</a></li>
                    <li><a href="borrowedbooks.php"><i class="fa fa-exchange"></i> Borrowed Books</a></li>
                    <li><a href="fines.php"><i class="fa fa-money"></i> Fines</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo isset($_SESSION['admin']) ? $_SESSION['admin'] : 'Admin'; ?></li>
                    <li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- navbar ends -->
</div>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default" style="margin-top: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);">
                <div class="panel-heading" style="background: linear-gradient(to right, #0a9396, #005f73); color: white; border-radius: 10px 10px 0 0; padding: 15px 20px;">
                    <h3 class="panel-title" style="font-size: 20px; font-weight: 600;"><i class="fa fa-user-plus"></i> Add New Admin</h3>
                </div>
                <div class="panel-body" style="padding: 25px;">
                    <?php if(isset($error)) { ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <strong><i class="fa fa-check-circle"></i> Success!</strong> Admin record added successfully.
                    </div>
                    <?php } ?>
                    
                    <form class="form-horizontal" role="form" method="post" action="adduser.php" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="name" class="col-sm-3 control-label">Full Name</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                    <input type="text" class="form-control" name="name" placeholder="Enter Full Name" id="name" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="username" class="col-sm-3 control-label">Username</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-user-circle"></i></span>
                                    <input type="text" class="form-control" name="username" placeholder="Enter Username" id="username" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password1" class="col-sm-3 control-label">Password</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                    <input type="password" class="form-control" name="password1" placeholder="Enter Password" id="password1" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password2" class="col-sm-3 control-label">Confirm Password</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                    <input type="password" class="form-control" name="password2" placeholder="Confirm Password" id="password2" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email" class="col-sm-3 control-label">Email</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                    <input type="email" class="form-control" name="email" placeholder="Enter Email" id="email" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="postimg" class="col-sm-3 control-label">Profile Image</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-image"></i></span>
                                    <input type="file" class="form-control" name="postimg" id="postimg" required accept="image/*">
                                </div>
                                <p class="help-block">Accepted formats: JPG, JPEG, PNG, GIF. Max size: 500KB</p>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-9">
                                <button type="submit" class="btn btn-primary" name="submit" style="background: linear-gradient(to right, #0a9396, #005f73); border: none; padding: 10px 20px; font-weight: 600;">
                                    <i class="fa fa-plus-circle"></i> Add Admin
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Enhanced Admin Navbar Styling */
.admin-navbar {
    background: linear-gradient(to right, #0a9396, #005f73);
    border: none;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
    margin-bottom: 25px;
    border-radius: 0;
}

.navbar-logo {
    height: 30px;
    margin-right: 10px;
}

.admin-navbar .navbar-brand {
    color: #ffffff !important;
    font-weight: 700;
    font-size: 22px;
    letter-spacing: 0.5px;
    padding: 15px 15px;
    height: auto;
    display: flex;
    align-items: center;
}

.admin-navbar .navbar-brand i {
    font-size: 24px;
    margin-right: 8px;
    color: #e9d8a6;
}

.admin-navbar .navbar-nav > li > a {
    color: rgba(255, 255, 255, 0.9) !important;
    font-weight: 500;
    padding: 18px 15px;
    position: relative;
    text-transform: uppercase;
    font-size: 13px;
    letter-spacing: 0.5px;
    transition: all 0.3s ease;
}

.admin-navbar .navbar-nav > li > a:hover,
.admin-navbar .navbar-nav > li > a:focus,
.admin-navbar .navbar-nav > li.active > a {
    color: #ffffff !important;
    background-color: rgba(255, 255, 255, 0.1);
}

.admin-navbar .navbar-nav > li.active > a:after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background-color: #e9d8a6;
}

.admin-navbar .navbar-nav > li > a:hover:after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background-color: rgba(233, 216, 166, 0.7);
    transform: scaleX(0);
    transition: transform 0.3s ease;
}

.admin-navbar .navbar-nav > li > a:hover:after {
    transform: scaleX(1);
}

.admin-navbar .navbar-toggle {
    border-color: transparent;
    margin-top: 12px;
}

.admin-navbar .navbar-toggle .icon-bar {
    background-color: #ffffff;
    height: 2px;
}

.admin-navbar .navbar-collapse {
    border-color: rgba(255, 255, 255, 0.1);
}

.admin-navbar .user-welcome {
    display: flex;
    align-items: center;
    color: rgba(255, 255, 255, 0.9) !important;
    padding: 18px 15px;
    margin-right: 5px;
    font-weight: 500;
}

.admin-navbar .user-welcome i {
    color: #e9d8a6;
    margin-right: 8px;
    font-size: 16px;
}

.admin-navbar .navbar-nav > li.logout-btn > a {
    background-color: rgba(255, 255, 255, 0.15);
    border-radius: 4px;
    padding: 8px 15px;
    margin: 10px 0;
    transition: all 0.3s ease;
}

.admin-navbar .navbar-nav > li.logout-btn > a:hover {
    background-color: rgba(255, 255, 255, 0.25);
}

.admin-navbar .navbar-nav > li.logout-btn > a:after {
    display: none;
}

@media (max-width: 767px) {
    .admin-navbar .navbar-collapse {
        background-color: #005f73;
        max-height: none;
    }
    
    .admin-navbar .navbar-nav {
        margin: 0 -15px;
    }
    
    .admin-navbar .navbar-nav > li > a {
        padding: 12px 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .navbar-nav > li.active > a:after {
        display: none;
    }
    
    .admin-navbar .user-welcome {
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding: 15px 20px;
        margin: 0;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a {
        border-radius: 0;
        margin: 0;
        padding: 12px 20px;
    }
}

body {
    background-color: #f8f9fa;
    padding-top: 0;
    padding-bottom: 30px;
}

.form-control {
    height: 40px;
    border-radius: 4px;
}

.input-group-addon {
    background-color: #f8f9fa;
    border: 1px solid #ddd;
    color: #0a9396;
}

.help-block {
    font-size: 12px;
    color: #6c757d;
    margin-top: 5px;
}
</style>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript">
 	window.onload = function () {
		var input = document.getElementById('name').focus();
	}
 </script>
</body>
</html>