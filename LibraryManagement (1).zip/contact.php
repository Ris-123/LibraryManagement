<?php
session_start();
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_SESSION['contact_success'])) {
    echo '<div class="alert alert-success">' . $_SESSION['contact_success'] . '</div>';
    unset($_SESSION['contact_success']);
}
if (isset($_SESSION['contact_error'])) {
    echo '<div class="alert alert-danger">' . $_SESSION['contact_error'] . '</div>';
    unset($_SESSION['contact_error']);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Contact Us - Easy Library</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            padding-top: 70px;
        }
        .navbar {
            background-color: #fff;
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            padding: 10px 0;
        }
        .navbar-brand {
            color: #0a9396 !important;
            font-weight: bold;
            font-size: 24px;
            display: flex;
            align-items: center;
        }
        .navbar-brand i {
            color: #0a9396;
            margin-right: 8px;
            font-size: 28px;
        }
        .nav > li > a {
            color: #444 !important;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 14px;
            padding: 15px;
            transition: all 0.3s ease;
            position: relative;
        }
        .nav > li > a:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            background-color: #0a9396;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            transition: all 0.3s ease;
        }
        .nav > li > a:hover:after,
        .nav > li.active > a:after {
            width: 70%;
        }
        .nav > li > a:hover,
        .nav > li > a:focus,
        .nav > li.active > a {
            background-color: transparent;
            color: #0a9396 !important;
        }
        .btn-register {
            background-color: #0a9396;
            color: white !important;
            border-radius: 30px;
            padding: 8px 24px !important;
            margin-top: 7px;
            margin-left: 10px;
            border: 2px solid #0a9396;
            font-weight: 600 !important;
            box-shadow: 0 4px 10px rgba(10, 147, 150, 0.3);
            text-transform: none !important;
        }
        .btn-register:hover {
            background-color: white !important;
            color: #0a9396 !important;
            border-color: #0a9396;
            transform: translateY(-2px);
        }
        .btn-register:after {
            display: none;
        }
        .navbar-toggle {
            border: none;
            background: transparent !important;
        }
        .navbar-toggle:hover {
            background: transparent !important;
        }
        .navbar-toggle .icon-bar {
            background-color: #0a9396 !important;
            width: 22px;
            transition: all 0.3s;
        }
        .navbar-toggle .top-bar {
            transform: rotate(45deg);
            transform-origin: 10% 10%;
        }
        .navbar-toggle .middle-bar {
            opacity: 0;
        }
        .navbar-toggle .bottom-bar {
            transform: rotate(-45deg);
            transform-origin: 10% 90%;
        }
        .navbar-toggle.collapsed .top-bar {
            transform: rotate(0);
        }
        .navbar-toggle.collapsed .middle-bar {
            opacity: 1;
        }
        .navbar-toggle.collapsed .bottom-bar {
            transform: rotate(0);
        }
        @media (max-width: 767px) {
            .navbar-nav {
                margin: 0;
            }
            .navbar-collapse {
                box-shadow: 0 5px 10px rgba(0,0,0,0.1);
                border: none;
                background-color: white;
                margin-top: 10px;
            }
            .nav > li > a:after {
                display: none;
            }
            .nav > li > a {
                padding: 15px 20px;
            }
            .btn-register {
                margin: 10px 20px;
                display: inline-block;
                text-align: center;
            }
        }
        .contact-section {
            padding: 80px 0;
            background-color: #f8f9fa;
        }
        .contact-heading {
            color: #0a9396;
            margin-bottom: 30px;
            font-weight: bold;
        }
        .contact-info {
            margin-bottom: 40px;
        }
        .info-item {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .info-icon {
            width: 50px;
            height: 50px;
            background-color: #0a9396;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: white;
            font-size: 20px;
        }
        .form-control {
            border-radius: 0;
            height: 45px;
            margin-bottom: 20px;
        }
        textarea.form-control {
            height: 150px;
        }
        .submit-btn {
            background-color: #0a9396;
            color: white;
            border: none;
            padding: 10px 30px;
            border-radius: 25px;
            font-weight: bold;
        }
        .submit-btn:hover {
            background-color: #077f82;
            color: white;
        }
    </style>
</head>
<body>
    <?php include "includes/nav.php"; ?>

    <!-- Contact Section -->
    <section class="contact-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 class="contact-heading">Get In Touch</h2>
                    <div class="contact-info">
                        <div class="info-item">
                            <div class="info-icon">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div>
                                <h4>Our Location</h4>
                                <p>Bara kanthalia, Barrackpore, Telini Para, Kolkata - 700121</p>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div>
                                <h4>Call Us</h4>
                                <p>9836816130, 9007231000</p>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-icon">
                                <i class="fa fa-envelope"></i>
                            </div>
                            <div>
                                <h4>Email Us</h4>
                                <p>contact@regentlibrary.com</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <h2 class="contact-heading">Send us a Message</h2>
                    <form action="contact_submit.php" method="post">
                        <div class="form-group">
                            <input type="text" class="form-control" name="name" placeholder="Your Name" required>
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" name="email" placeholder="Your Email" required>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="subject" placeholder="Subject" required>
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" name="message" placeholder="Your Message" required></textarea>
                        </div>
                        <button type="submit" class="btn submit-btn">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer" style="background-color: #f8f9fa; padding: 20px 0; margin-top: 0; border-top: 1px solid #eee;">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <p>&copy; <?php echo date('Y'); ?> Regent Library. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html> 