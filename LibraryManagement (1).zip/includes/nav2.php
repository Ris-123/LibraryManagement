<?php 
require 'includes/db-inc.php';
?>
<nav class="navbar navbar-default navbar-fixed-top admin-navbar">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="adminportal.php">
                <img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
                <i class="fa fa-book"></i> Regent Library
            </a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example">
            <ul class="nav navbar-nav">
                <li><a href="adminportal.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li class="active"><a href="addstudent.php"><i class="fa fa-user-plus"></i> Add Student</a></li>
                <li><a href="addbook.php"><i class="fa fa-book"></i> Add Book</a></li>
                <li><a href="viewstudents.php"><i class="fa fa-users"></i> View Students</a></li>
                <li><a href="viewbooks.php"><i class="fa fa-list"></i> View Books</a></li>
                <li><a href="borrow.php"><i class="fa fa-exchange"></i> Borrow Books</a></li>
                <li><a href="return.php"><i class="fa fa-undo"></i> Return Books</a></li>
                <li><a href="fines.php"><i class="fa fa-money"></i> Fines</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="user-welcome">
                    <i class="fa fa-user-circle"></i> Hello, <?php echo isset($_SESSION['admin-name']) ? $_SESSION['admin-name'] : 'Admin'; ?>
                </li>
                <li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<style type="text/css">
    .admin-navbar {
        background: linear-gradient(to right, #2c3e50, #3498db);
        border: none;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
        margin-bottom: 25px;
        border-radius: 0;
    }
    
    .admin-navbar .navbar-brand {
        color: #ffffff !important;
        font-weight: 700;
        font-size: 22px;
        letter-spacing: 0.5px;
        padding: 15px 15px;
        height: auto;
        display: flex;
        align-items: center;
    }
    
    .admin-navbar .navbar-brand i {
        font-size: 24px;
        margin-right: 8px;
        color: #f1c40f;
    }
    
    .admin-navbar .navbar-nav > li > a {
        color: rgba(255, 255, 255, 0.9) !important;
        font-weight: 500;
        padding: 18px 15px;
        position: relative;
        text-transform: uppercase;
        font-size: 13px;
        letter-spacing: 0.5px;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li > a:hover,
    .admin-navbar .navbar-nav > li > a:focus,
    .admin-navbar .navbar-nav > li.active > a {
        color: #ffffff !important;
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .navbar-nav > li.active > a:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: #f1c40f;
    }
    
    .admin-navbar .navbar-nav > li > a:hover:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: rgba(241, 196, 15, 0.7);
        transform: scaleX(0);
        transition: transform 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li > a:hover:after {
        transform: scaleX(1);
    }
    
    .admin-navbar .navbar-toggle {
        border-color: transparent;
        margin-top: 12px;
    }
    
    .admin-navbar .navbar-toggle .icon-bar {
        background-color: #ffffff;
        height: 2px;
    }
    
    .admin-navbar .navbar-collapse {
        border-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .user-welcome {
        display: flex;
        align-items: center;
        color: rgba(255, 255, 255, 0.9) !important;
        padding: 18px 15px;
        margin-right: 5px;
        font-weight: 500;
    }
    
    .admin-navbar .user-welcome i {
        color: #f1c40f;
        margin-right: 8px;
        font-size: 16px;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a {
        background-color: rgba(255, 255, 255, 0.15);
        border-radius: 4px;
        padding: 8px 15px;
        margin: 10px 0;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:hover {
        background-color: rgba(255, 255, 255, 0.25);
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:after {
        display: none;
    }
    
    @media (max-width: 767px) {
        .admin-navbar .navbar-collapse {
            background-color: #2c3e50;
            max-height: none;
        }
        
        .admin-navbar .navbar-nav {
            margin: 0 -15px;
        }
        
        .admin-navbar .navbar-nav > li > a {
            padding: 12px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .admin-navbar .navbar-nav > li.active > a:after {
            display: none;
        }
        
        .admin-navbar .user-welcome {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding: 15px 20px;
            margin: 0;
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a {
            border-radius: 0;
            margin: 0;
            padding: 12px 20px;
        }
    }
    
    .navbar-logo {
        height: 30px;
        margin-right: 10px;
    }
</style>