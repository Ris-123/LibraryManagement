# Email Troubleshooting Guide

## Immediate Solution
I've made temporary changes to help you complete registration while we fix the email issue:

1. The OTP will now display on the verification page
2. You can use this displayed OTP to complete your registration
3. This is a temporary measure until we resolve the email sending issue

## Steps to Fix Email Sending

### Option 1: Setup Mailtrap (Recommended for Testing)

1. Go to [Mailtrap.io](https://mailtrap.io) and create a free account
2. Create a new inbox
3. Go to the inbox and find SMTP credentials 
4. Open `includes/mailer.php` and update these lines:
   ```php
   $mail->Username = '1a2b3c4d5e6f7g'; // Replace with your Mailtrap username
   $mail->Password = 'abcd1234efgh5678'; // Replace with your Mailtrap password
   ```
5. Emails will be captured in your Mailtrap inbox (not delivered to real email addresses)

### Option 2: Configure Gmail SMTP

1. You need a Gmail account
2. Open `includes/mailer.php` and uncomment the Gmail section, comment out Mailtrap
3. Update the credentials with your Gmail account:
   ```php
   $mail->Username = 'your.actual.email@gmail.com'; 
   $mail->Password = 'your-actual-password-or-app-password';
   ```
4. For Gmail with 2-factor authentication, you need an "App Password":
   - Go to your Google Account → Security → App passwords
   - Select "Mail" and "Other (Custom name)"
   - Use the generated password

### Option 3: Test PHP's mail() Function

1. Make sure sendmail or another mail service is installed on your server
2. Comment out all SMTP configurations in mailer.php
3. Add this code instead:
   ```php
   // No SMTP - use PHP mail()
   $to = $email;
   $subject = 'OTP Verification - Library Management System';
   $headers = "MIME-Version: 1.0" . "\r\n";
   $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
   $headers .= "From: Library Management System <noreply@library.com>" . "\r\n";
   $message = getEmailBody($name, $otp);
   mail($to, $subject, $message, $headers);
   ```

## Checking for Errors

1. Open `C:\xampp\php\php.ini`
2. Make sure these settings are enabled (remove semicolons if present):
   ```
   error_reporting = E_ALL
   display_errors = On
   log_errors = On
   error_log = "C:\xampp\logs\php_error_log"
   ```
3. Restart Apache server
4. Check `C:\xampp\logs\php_error_log` after attempting to send an email

## Verifying XAMPP Mail Settings

1. Open XAMPP Control Panel
2. Make sure Mercury (mail server) is installed and running
3. Click on the "Config" button next to Mercury
4. Check if your local mail server is properly configured

## Need Further Help?

If you continue to have problems, please provide:
1. What type of email server are you trying to use?
2. Any error messages from the PHP error log
3. Have you enabled less secure app access for your Gmail (if using Gmail)? 

# Configuring XAMPP for Email Sending

Here's how to set up your XAMPP environment to send real emails:

## Option 1: Configure Mercury Mail Server (Built-in)

1. **Start Mercury Mail Server**
   - Open XAMPP Control Panel
   - Click "Start" next to Mercury
   - If Mercury isn't shown, you may need to install it through the XAMPP installer

2. **Configure Mercury**
   - Open XAMPP Control Panel
   - Click "Admin" next to Mercury
   - Set up your local domain (typically localhost)
   - Create a mail account if prompted

3. **Configure php.ini**
   - Open `C:\xampp\php\php.ini`
   - Find the [mail function] section
   - Ensure these settings:
     ```
     [mail function]
     SMTP=localhost
     smtp_port=25
     sendmail_from=your-email@localhost
     mail.add_x_header=Off
     ```
   - Save the file and restart Apache

## Option 2: Use Gmail SMTP (More Reliable)

1. **Edit your mailer.php file**
   - Edit `includes/mailer.php`
   - Replace the current code with PHPMailer using Gmail SMTP

2. **Install PHPMailer**
   - Create a folder `phpmailer` in your `includes` directory
   - Download PHPMailer from GitHub
   - Extract the files into the `phpmailer` folder

3. **Update mailer.php**:

```php
<?php
// Include PHPMailer files
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendOTP($email, $name, $otp) {
    // Always store OTP in session for verification
    $_SESSION['last_otp'] = $otp;
    
    try {
        $mail = new PHPMailer(true);
        
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'your-gmail@gmail.com'; // YOUR GMAIL
        $mail->Password   = 'your-app-password';    // APP PASSWORD (not regular password)
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;
        
        // Recipients
        $mail->setFrom('your-gmail@gmail.com', 'Library System');
        $mail->addAddress($email, $name);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = 'OTP Verification - Library Management System';
        $mail->Body    = getEmailBody($name, $otp);
        $mail->AltBody = 'Your OTP is: ' . $otp;
        
        $mail->send();
        error_log("Email sent to $email with OTP: $otp");
        return true;
    } catch (Exception $e) {
        error_log("Email could not be sent. Error: {$mail->ErrorInfo}");
        return false;
    }
}

// Keep your existing getEmailBody function
function getEmailBody($name, $otp) {
    // Existing code...
}
```

4. **Important Gmail Notes**:
   - You need to use an "App Password" (not your regular password)
   - To generate an App Password:
     - Enable 2-Step Verification on your Google Account
     - Go to your Google Account → Security → App passwords
     - Select "App" and "Other" (custom name)
     - Copy the generated 16-character password

## Option 3: Use Mailtrap (Development Testing)

1. **Sign up for Mailtrap**
   - Create a free account at [Mailtrap.io](https://mailtrap.io/)
   - Create an inbox

2. **Update your mailer.php**
   - Use PHPMailer with Mailtrap credentials:

```php
// Server settings
$mail->isSMTP();
$mail->Host       = 'smtp.mailtrap.io';
$mail->SMTPAuth   = true;
$mail->Username   = 'your-mailtrap-username'; // From Mailtrap inbox
$mail->Password   = 'your-mailtrap-password'; // From Mailtrap inbox
$mail->Port       = 2525;
```

## Testing Your Configuration

After making these changes:
1. Comment out `return true;` in `includes/mailer.php`
2. Uncomment the email sending code
3. Restart Apache
4. Try registering a new user

Which option would you prefer to implement? 