<?php
session_start();
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

// Check if user has registration data in session
if (!isset($_SESSION['student_reg'])) {
    // Redirect to registration page if no data found
    header("Location: addstudent.php");
    exit();
}

$verification_error = '';
$success = false;

// Define OTP expiration time (10 minutes)
$otp_expiry_time = 10 * 60; // 10 minutes in seconds

// Check if OTP is expired
if (isset($_SESSION['otp_generated_time'])) {
    $elapsed_time = time() - $_SESSION['otp_generated_time'];
    if ($elapsed_time > $otp_expiry_time) {
        $verification_error = "Your OTP has expired. Please request a new one.";
        $_SESSION['otp_expired'] = true;
    }
}

// Process OTP verification
if (isset($_POST['verify_otp'])) {
    $entered_otp = sanitize(trim($_POST['otp']));
    $stored_otp = $_SESSION['student_reg']['otp'];
    $last_otp = isset($_SESSION['last_otp']) ? $_SESSION['last_otp'] : null;
    
    // Check if OTP is expired before verification
    if (isset($_SESSION['otp_expired']) && $_SESSION['otp_expired']) {
        $verification_error = "Your OTP has expired. Please request a new one.";
    } 
    // Verify OTP
    else if ($entered_otp == $stored_otp || ($last_otp !== null && $entered_otp == $last_otp)) {
        // OTP is valid, proceed with registration
        $reg_data = $_SESSION['student_reg'];
        
        // Hash the password for security
        $hashed_password = password_hash($reg_data['password'], PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO students(matric_no, password, username, email, dept, numOfBooks, moneyOwed, photo, phoneNumber, name)
                VALUES ('{$reg_data['matric_no']}', '{$hashed_password}', '{$reg_data['username']}', 
                '{$reg_data['email']}', '{$reg_data['dept']}', '{$reg_data['numOfBooks']}', '{$reg_data['moneyOwed']}', 
                '{$reg_data['photo']}', '{$reg_data['phoneNumber']}', '{$reg_data['name']}')";
        
        $query = mysqli_query($conn, $sql);
        
        if ($query) {
            $success = true;
            // Clear the registration data from session
            unset($_SESSION['student_reg']);
            unset($_SESSION['last_otp']);
            unset($_SESSION['otp_generated_time']);
            unset($_SESSION['otp_expired']);
        } else {
            $verification_error = "Registration failed! Database error: " . mysqli_error($conn);
        }
    } else {
        $verification_error = "Invalid OTP. Please check and try again.";
    }
}

// Resend OTP
if (isset($_POST['resend_otp'])) {
    // Generate new OTP
    $new_otp = rand(100000, 999999);
    $_SESSION['student_reg']['otp'] = $new_otp;
    $_SESSION['otp_generated_time'] = time();
    unset($_SESSION['otp_expired']);
    
    $email = $_SESSION['student_reg']['email'];
    $name = $_SESSION['student_reg']['name'];
    
    // Send new OTP email
    require 'includes/mailer.php';
    $mail_sent = sendOTP($email, $name, $new_otp);
    
    if ($mail_sent) {
        $resend_success = true;
    } else {
        $verification_error = "Failed to resend OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>OTP Verification - Easy Library</title>
    <style type="text/css">
        body {
            background-color: #f8f9fa;
            padding-top: 20px;
            padding-bottom: 50px;
        }
        
        .verification-container {
            max-width: 600px;
            margin: 80px auto;
        }
        
        .verification-card {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .verification-header {
            margin-bottom: 30px;
            color: #0a9396;
            border-bottom: 2px solid #e9d8a6;
            padding-bottom: 15px;
        }
        
        .verification-header h2 {
            font-weight: 700;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .verification-header p {
            color: #666;
            font-size: 16px;
            margin-bottom: 0;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .otp-input {
            letter-spacing: 15px;
            font-size: 24px;
            padding: 10px 15px;
            text-align: center;
            font-weight: bold;
        }
        
        .btn-verify {
            background: linear-gradient(to right, #0a9396, #005f73);
            color: white;
            border: none;
            border-radius: 4px;
            padding: 12px 25px;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .btn-verify:hover {
            background: linear-gradient(to right, #005f73, #003d47);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .btn-resend {
            background: transparent;
            color: #0a9396;
            border: 1px solid #0a9396;
            border-radius: 4px;
            padding: 10px 20px;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            transition: all 0.3s ease;
            margin-top: 20px;
        }
        
        .btn-resend:hover {
            background-color: #f8f9fa;
            color: #005f73;
            border-color: #005f73;
        }
        
        .alert {
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background-color: #d1e7dd;
            border-color: #badbcc;
            color: #0f5132;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c2c7;
            color: #842029;
        }
        
        .success-icon {
            font-size: 80px;
            color: #0f5132;
            margin: 20px 0;
        }
        
        .login-link {
            display: inline-block;
            background: linear-gradient(to right, #0a9396, #005f73);
            color: white;
            text-decoration: none;
            border-radius: 4px;
            padding: 12px 25px;
            font-size: 16px;
            font-weight: 600;
            margin-top: 20px;
            transition: all 0.3s ease;
        }
        
        .login-link:hover {
            background: linear-gradient(to right, #005f73, #003d47);
            color: white;
            text-decoration: none;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .timer {
            font-size: 16px;
            color: #666;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include "includes/nav.php"; ?>
        
        <div class="verification-container">
            <div class="verification-card">
                <?php if($success): ?>
                    <div class="verification-header">
                        <h2>Registration Successful!</h2>
                    </div>
                    <div class="success-message">
                        <i class="fa fa-check-circle success-icon"></i>
                        <p>Your account has been created successfully. You can now login to access the library services.</p>
                        <a href="login.php" class="login-link">
                            <i class="fa fa-sign-in"></i> Login Now
                        </a>
                    </div>
                <?php else: ?>
                    <div class="verification-header">
                        <h2><i class="fa fa-key"></i> OTP Verification</h2>
                        <p>We've sent a verification code to your email address</p>
                    </div>
                    
                    <?php if(isset($verification_error) && !empty($verification_error)): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <strong><i class="fa fa-exclamation-circle"></i> Error!</strong> <?php echo $verification_error; ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if(isset($resend_success)): ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <strong><i class="fa fa-check-circle"></i> Success!</strong> A new OTP has been sent to your email.
                    </div>
                    <?php endif; ?>
                    
                    <form action="" method="POST">
                        <div class="form-group">
                            <label for="otp">Enter the 6-digit OTP sent to your email</label>
                            <input type="text" class="form-control otp-input" id="otp" name="otp" maxlength="6" pattern="[0-9]{6}" placeholder="******" required autocomplete="off">
                            <p class="timer">OTP expires in <span id="countdown">10:00</span> minutes</p>
                        </div>
                        <button type="submit" name="verify_otp" class="btn btn-verify">
                            <i class="fa fa-check-circle"></i> Verify OTP
                        </button>
                    </form>
                    
                    <hr>
                    
                    <p>Didn't receive the code?</p>
                    <form action="" method="POST">
                        <button type="submit" name="resend_otp" class="btn btn-resend">
                            <i class="fa fa-refresh"></i> Resend OTP
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script type="text/javascript">
        // OTP Countdown Timer
        function startTimer(duration, display) {
            var timer = duration, minutes, seconds;
            var interval = setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);

                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;

                display.textContent = minutes + ":" + seconds;

                if (--timer < 0) {
                    clearInterval(interval);
                    display.textContent = "Expired";
                    document.getElementById("otp").disabled = true;
                    document.querySelector(".btn-verify").disabled = true;
                    
                    // Show expired message
                    var errorDiv = document.createElement("div");
                    errorDiv.className = "alert alert-danger";
                    errorDiv.innerHTML = "<strong><i class='fa fa-exclamation-circle'></i> Error!</strong> Your OTP has expired. Please request a new one.";
                    document.querySelector("form").prepend(errorDiv);
                }
            }, 1000);
        }

        window.onload = function () {
            var tenMinutes = 60 * 10,
                display = document.querySelector('#countdown');
            startTimer(tenMinutes, display);
        };
    </script>
</body>
</html> 