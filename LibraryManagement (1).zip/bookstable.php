<?php 
session_start();
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php"; 

// Check if user is logged in as admin
if (!(isset($_SESSION['auth']) && $_SESSION['auth'] === true)) {
	header("Location: login.php?access=false");
	exit();
}
else {
 	$admin = $_SESSION['admin'];
}

if(isset($_POST['del'])){

	$id = sanitize(trim($_POST['id']));

	$sql_del = "DELETE from books where BookId = $id"; 
	$error = false;
	$result = mysqli_query($conn,$sql_del);
			if ($result)
			{
			$error = true;
			}
}
?>

<style>
    /* Enhanced Admin Navbar Styling */
    .admin-navbar {
        background: linear-gradient(to right, #0a9396, #005f73);
        border: none;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
        margin-bottom: 25px;
        border-radius: 0;
    }
    
    .admin-navbar .navbar-brand {
        color: #ffffff !important;
        font-weight: 700;
        font-size: 22px;
        letter-spacing: 0.5px;
        padding: 15px 15px;
        height: auto;
        display: flex;
        align-items: center;
    }
    
    .admin-navbar .navbar-brand i {
        font-size: 24px;
        margin-right: 8px;
        color: #e9d8a6;
    }
    
    .admin-navbar .navbar-nav > li > a {
        color: rgba(255, 255, 255, 0.9) !important;
        font-weight: 500;
        padding: 18px 15px;
        position: relative;
        text-transform: uppercase;
        font-size: 13px;
        letter-spacing: 0.5px;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li > a:hover,
    .admin-navbar .navbar-nav > li > a:focus,
    .admin-navbar .navbar-nav > li.active > a {
        color: #ffffff !important;
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .navbar-nav > li.active > a:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: #e9d8a6;
    }
    
    .admin-navbar .navbar-nav > li > a:hover:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: rgba(233, 216, 166, 0.7);
        transform: scaleX(0);
        transition: transform 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li > a:hover:after {
        transform: scaleX(1);
    }
    
    .admin-navbar .navbar-toggle {
        border-color: transparent;
        margin-top: 12px;
    }
    
    .admin-navbar .navbar-toggle .icon-bar {
        background-color: #ffffff;
        height: 2px;
    }
    
    .admin-navbar .navbar-collapse {
        border-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .user-welcome {
        display: flex;
        align-items: center;
        color: rgba(255, 255, 255, 0.9) !important;
        padding: 18px 15px;
        margin-right: 5px;
        font-weight: 500;
    }
    
    .admin-navbar .user-welcome i {
        color: #e9d8a6;
        margin-right: 8px;
        font-size: 16px;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a {
        background-color: rgba(255, 255, 255, 0.15);
        border-radius: 4px;
        padding: 8px 15px;
        margin: 10px 0;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:hover {
        background-color: rgba(255, 255, 255, 0.25);
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:after {
        display: none;
    }
    
    @media (max-width: 767px) {
        .admin-navbar .navbar-collapse {
            background-color: #005f73;
            max-height: none;
        }
        
        .admin-navbar .navbar-nav {
            margin: 0 -15px;
        }
        
        .admin-navbar .navbar-nav > li > a {
            padding: 12px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .admin-navbar .navbar-nav > li.active > a:after {
            display: none;
        }
        
        .admin-navbar .user-welcome {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding: 15px 20px;
            margin: 0;
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a {
            border-radius: 0;
            margin: 0;
            padding: 12px 20px;
        }
    }
    
    /* Enhance Books table page */
    .books-alert {
        background-color: #f8f9fa;
        border-left: 4px solid #0a9396;
        color: #333;
        padding: 15px 20px;
        margin-top: 25px;
        border-radius: 4px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        display: flex;
        align-items: center;
    }
    
    .books-alert i {
        font-size: 24px;
        color: #0a9396;
        margin-right: 10px;
    }
    
    .books-alert strong {
        font-size: 18px;
        font-weight: 600;
    }
    
    /* Book Card Styles - Admin Version */
    .book-row {
        display: flex;
        flex-wrap: wrap;
        margin: 0 -15px;
    }
    
    .book-col {
        width: 33.333%;
        padding: 0 15px;
        margin-bottom: 30px;
    }
    
    .book-card {
        transition: all 0.3s ease;
        height: 100%;
        display: flex;
        flex-direction: column;
        border: 1px solid #e0e0e0;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        background-color: #fff;
        position: relative;
    }
    
    .book-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        border-color: #d0d0d0;
    }
    
    .book-card-img {
        height: 220px;
        overflow: hidden;
        position: relative; 
        background-color: #f8f8f8;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.4s ease;
    }
    
    .book-card-img img {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
        transition: all 0.4s ease;
    }
    
    .book-card:hover .book-card-img img {
        transform: scale(1.08);
    }
    
    .book-card-content {
        flex: 1;
        display: flex;
        flex-direction: column;
        padding: 20px;
        min-height: 280px;
        position: relative;
    }
    
    .book-card h4 {
        font-weight: 700;
        margin-top: 0;
        margin-bottom: 8px;
        color: #222;
        font-size: 18px;
        line-height: 1.3;
        height: 47px;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }
    
    .book-meta {
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 15px;
        font-size: 13px;
        color: #777;
    }
    
    .book-meta-item {
        width: 100%;
        margin-bottom: 8px;
        padding-bottom: 8px;
        border-bottom: 1px dashed #eee;
    }
    
    .book-meta-item:last-child {
        border-bottom: none;
    }
    
    .book-meta-label {
        font-weight: 600;
        color: #005f73;
        display: inline-block;
        width: 90px;
    }
    
    .book-meta i {
        color: #0a9396;
        margin-right: 5px;
        width: 15px;
        text-align: center;
    }
    
    .availability-badge {
        position: absolute;
        top: 15px;
        right: 15px;
        z-index: 2;
    }
    
    .availability-badge .label {
        font-size: 12px;
        padding: 6px 10px;
        border-radius: 50px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        font-weight: 600;
        letter-spacing: 0.5px;
    }
    
    .label-success {
        background-color: #0a9396;
    }
    
    .label-danger {
        background-color: #e63946;
    }
    
    .book-details {
        margin-bottom: 15px;
    }
    
    .book-details h5 {
        font-weight: 600;
        margin-top: 0;
        margin-bottom: 8px;
        color: #0a9396;
        font-size: 15px;
        position: relative;
        padding-bottom: 8px;
    }
    
    .book-details h5:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 50px;
        height: 2px;
        background-color: #0a9396;
    }
    
    .book-details p {
        font-size: 13px;
        color: #666;
        line-height: 1.6;
        height: 63px;
        overflow: hidden;
        margin-bottom: 5px;
    }
    
    .button-container {
        margin-top: auto;
        display: flex;
    }
    
    .btn-delete {
        border-radius: 50px;
        padding: 10px 0;
        font-weight: 600;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        font-size: 14px;
        transition: all 0.3s ease;
        width: 100%;
        background: linear-gradient(135deg, #e63946, #d00000);
        border: none;
        box-shadow: 0 4px 10px rgba(230, 57, 70, 0.3);
        color: #fff;
    }
    
    .btn-delete:hover {
        background: linear-gradient(135deg, #d00000, #e63946);
        box-shadow: 0 6px 15px rgba(230, 57, 70, 0.4);
    }
    
    .form-search {
        margin-bottom: 20px;
    }
    
    .book-id-badge {
        position: absolute;
        top: 15px;
        left: 15px;
        z-index: 2;
        background-color: rgba(0, 95, 115, 0.8);
        color: #fff;
        border-radius: 50px;
        padding: 5px 10px;
        font-size: 12px;
        font-weight: 600;
    }
    
    @media (max-width: 991px) {
        .book-col {
            width: 50%;
        }
    }
    
    @media (max-width: 767px) {
        .book-col {
            width: 100%;
            margin-bottom: 20px;
        }
    }

    .navbar-logo {
        height: 30px;
        margin-right: 10px;
    }
</style>

<div class="container-fluid">
    <!-- Custom Admin Navbar -->
    <nav class="navbar navbar-default admin-navbar">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#admin-navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="admin.php">
                    <img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
                    <i class="fa fa-tachometer"></i> Admin Dashboard
                </a>
            </div>

            <div class="collapse navbar-collapse" id="admin-navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="admin.php"><i class="fa fa-home"></i> Dashboard</a></li>
                    <li class="active"><a href="bookstable.php"><i class="fa fa-book"></i> Books</a></li>
                    <li><a href="users.php"><i class="fa fa-users"></i> Admins</a></li>
                    <li><a href="viewstudents.php"><i class="fa fa-graduation-cap"></i> Students</a></li>
                    <li><a href="borrowedbooks.php"><i class="fa fa-exchange"></i> Borrowed Books</a></li>
                    <li><a href="fines.php"><i class="fa fa-money"></i> Fines</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $admin; ?></li>
                    <li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- navbar ends -->

<div class="container">
	<!-- info alert -->
        <div class="books-alert">
            <i class="fa fa-book"></i>
            <strong>Books Table</strong>
        </div>
	</div>

	<div class="container">
		<div class="panel panel-default">
		  <!-- Default panel contents -->
		  <div class="panel-heading">
		  	 <?php if(isset($error)===true) { ?>
        <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <strong>Record Deleted Successfully!</strong>
            </div>
            <?php } ?>
		  	<div class="row">
		  	  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <a href="addbook.php"><button class="btn btn-success button" style="margin-bottom: 5px"><span class="glyphicon glyphicon-plus-sign"></span> Add Book</button></a>
          </div>
		  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		  	<form method="post" action="bookstable.php" enctype="multipart/form-data" class="form-inline form-search pull-right">
		  		<div class="input-group">
			      <input type="text" class="form-control" name="text" placeholder="Search by ID">
			      <span class="input-group-btn">
			        <button class="btn btn-success" type="submit" name="search"><i class="fa fa-search"></i> Search</button>
			      </span>
		      </div>
		  	</form>
		  </div>
		</div>
		  </div>

		  <div class="panel-body">
		    <div class="book-row">
		      <?php 
		      // Default query to get all books
		      $sql = "SELECT * from books";
		      
		      // Search functionality
		      if(isset($_POST['search'])){
		        $text = sanitize(trim($_POST['text']));
		        $sql = "SELECT * FROM books where BookId = '$text'";
		      }
		      
		      $query = mysqli_query($conn, $sql);
		      
		      if(mysqli_num_rows($query) > 0) {
		        while($row = mysqli_fetch_array($query)) { 
		            // Determine availability badge
		            $availabilityClass = $row['available'] == 'YES' ? 'success' : 'danger';
		            $availabilityStatus = $row['available'] == 'YES' ? 
		                '<span class="label label-success">Available</span>' : 
		                '<span class="label label-danger">Not Available</span>';
		            
		            // Prepare image path
		            $imagePath = !empty($row['image']) && file_exists("book-images/".$row['image']) ? 
		                "book-images/".$row['image'] : 
		                "https://via.placeholder.com/200x250/0a9396/ffffff?text=No+Image";
		            
		            // Prepare details
		            $details = !empty($row['details']) ? $row['details'] : 'No details available';
		            $short_details = substr($details, 0, 100) . (strlen($details) > 100 ? '...' : '');
		        ?>
		        <div class="book-col">
		            <div class="book-card">
		                <!-- Book ID Badge -->
		                <div class="book-id-badge">
		                    ID: <?php echo $row['bookId']; ?>
		                </div>
		                
		                <!-- Card Header - Image -->
		                <div class="book-card-img">
		                    <img src="<?php echo $imagePath; ?>" alt="<?php echo htmlspecialchars($row['bookTitle']); ?>">
		                    <div class="availability-badge">
		                        <?php echo $availabilityStatus; ?>
		                    </div>
		                </div>
		                
		                <!-- Card Body - Content -->
		                <div class="book-card-content">
		                    <h4><?php echo htmlspecialchars($row['bookTitle']); ?></h4>
		                    
		                    <div class="book-meta">
		                        <div class="book-meta-item">
		                            <i class="fa fa-user"></i> 
		                            <span class="book-meta-label">Author:</span> 
		                            <?php echo htmlspecialchars($row['author']); ?>
		                        </div>
		                        <div class="book-meta-item">
		                            <i class="fa fa-barcode"></i> 
		                            <span class="book-meta-label">ISBN:</span> 
		                            <?php echo htmlspecialchars($row['ISBN']); ?>
		                        </div>
		                        <div class="book-meta-item">
		                            <i class="fa fa-copy"></i> 
		                            <span class="book-meta-label">Copies:</span> 
		                            <?php echo $row['bookCopies']; ?>
		                        </div>
		                        <div class="book-meta-item">
		                            <i class="fa fa-building"></i> 
		                            <span class="book-meta-label">Publisher:</span> 
		                            <?php echo htmlspecialchars($row['publisherName']); ?>
		                        </div>
		                        <div class="book-meta-item">
		                            <i class="fa fa-tags"></i> 
		                            <span class="book-meta-label">Category:</span> 
		                            <?php echo htmlspecialchars($row['categories']); ?>
		                        </div>
		                    </div>
		                    
		                    <?php if(!empty($row['details'])): ?>
		                    <div class="book-details">
		                        <h5>Details</h5>
		                        <p><?php echo $short_details; ?></p>
		                    </div>
		                    <?php endif; ?>
		                    
		                    <!-- Delete Button -->
		                    <div class="button-container">
		                        <form method="post" action="bookstable.php" style="width: 100%;">
		                            <input type="hidden" value="<?php echo $row['bookId']; ?>" name="id">
		                            <button name="del" type="submit" class="btn-delete" onclick="return Delete()">
		                                <i class="fa fa-trash"></i> DELETE
		                            </button>
		                        </form>
		                    </div>
		                </div>
		            </div>
		        </div>
		        <?php }
		      } else {
		          echo '<div class="col-xs-12 text-center"><div class="alert alert-info"><i class="fa fa-info-circle"></i> No books found. Please try a different search or add some books.</div></div>';
		      }
		      ?>
		    </div>
		  </div>
		</div>
	</div>
	<div class="mod modal fade" id="popUpWindow">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			
        			<!-- header begins here -->
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
        				<h3 class="modal-title"> Warning</h3>
        			</div>

        			<!-- body begins here -->
        			<div class="modal-body">
        				<p>Are you sure you want to delete this book?</p>
        			</div>

        			<!-- button -->
        			<div class="modal-footer ">
        				<button class="col-lg-4 col-sm-4 col-xs-6 col-md-4 btn btn-warning pull-right"  style="margin-left: 10px" class="close" data-dismiss="modal">
        					No
        				</button>&nbsp;
        				<button class="col-lg-4 col-sm-4 col-xs-6 col-md-4 btn btn-success pull-right"  class="close" data-dismiss="modal" data-toggle="modal" data-target="#info">
        					Yes
        				</button>
        			</div>
        		</div>
        	</div>
        </div>
        <div class="modal fade" id="info">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			
        			<!-- header begins here -->
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
        				<h3 class="modal-title"> Warning</h3>
        			</div>

        			<!-- body begins here -->
        			<div class="modal-body">
        				<p>Book deleted <span class="glyphicon glyphicon-ok"></span></p>
        			</div>

        		</div>
        	</div>
        </div>
		




<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>	
<script>
 function Delete() {
            return confirm('Would you like to delete the news');
        }
</script>
</body>
</html>