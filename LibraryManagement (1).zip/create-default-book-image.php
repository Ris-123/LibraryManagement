<?php
// Set the image dimensions
$width = 200;
$height = 280;

// Create an image resource
$image = imagecreatetruecolor($width, $height);

// Define colors
$bg_color = imagecolorallocate($image, 240, 240, 240);
$text_color = imagecolorallocate($image, 10, 147, 150); // #0a9396
$border_color = imagecolorallocate($image, 10, 147, 150);

// Fill the background
imagefill($image, 0, 0, $bg_color);

// Add a border
imagerectangle($image, 0, 0, $width-1, $height-1, $border_color);
imagerectangle($image, 1, 1, $width-2, $height-2, $border_color);

// Add a book icon
$book_width = 80;
$book_height = 100;
$book_x = ($width - $book_width) / 2;
$book_y = ($height - $book_height) / 2 - 30;

// Draw a simplified book shape
imagefilledrectangle($image, $book_x, $book_y, $book_x + $book_width, $book_y + $book_height, $text_color);
imagefilledrectangle($image, $book_x + 5, $book_y + 5, $book_x + $book_width - 5, $book_y + $book_height - 5, $bg_color);

// Add text
$text = "NO IMAGE";
$font_size = 5;
$text_x = ($width - imagefontwidth($font_size) * strlen($text)) / 2;
$text_y = $book_y + $book_height + 20;
imagestring($image, $font_size, $text_x, $text_y, $text, $text_color);

// Set header to output as PNG
header('Content-Type: image/png');

// Output the image to a file
imagepng($image, 'book-images/default-book.jpg');

// Free up memory
imagedestroy($image);

echo "Default book image created successfully!";
?> 