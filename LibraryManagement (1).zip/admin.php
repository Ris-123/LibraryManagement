<?php
session_start();

// Check if user is logged in as admin
if (!(isset($_SESSION['auth']) && $_SESSION['auth'] === true)) {
	header("Location: login.php?access=false");
	exit();
}
else {
 	$admin = $_SESSION['admin'];
}

require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

// Get statistics for dashboard
// 1. Total number of books
$sql_books = "SELECT COUNT(*) as total_books, SUM(bookCopies) as total_copies FROM books";
$query_books = mysqli_query($conn, $sql_books);
$books_data = mysqli_fetch_assoc($query_books);
$total_books = $books_data['total_books'] ?? 0;
$total_copies = $books_data['total_copies'] ?? 0;

// 2. Total number of students
$sql_students = "SELECT COUNT(*) as total_students FROM students";
$query_students = mysqli_query($conn, $sql_students);
$students_data = mysqli_fetch_assoc($query_students);
$total_students = $students_data['total_students'] ?? 0;

// 3. Total borrowed books
$sql_borrowed = "SELECT COUNT(*) as total_borrowed FROM borrow";
$query_borrowed = mysqli_query($conn, $sql_borrowed);
$borrowed_data = mysqli_fetch_assoc($query_borrowed);
$total_borrowed = $borrowed_data['total_borrowed'] ?? 0;

// 4. Total fines
$sql_fines = "SELECT COUNT(*) as fines_count, SUM(CASE WHEN fine != 'Paid' AND fine != '' THEN CAST(REPLACE(fine, 'Rs.', '') AS DECIMAL(10,2)) ELSE 0 END) as total_fines FROM borrow WHERE fine != ''";
$query_fines = mysqli_query($conn, $sql_fines);
$fines_data = mysqli_fetch_assoc($query_fines);
$total_fines = $fines_data['total_fines'] ?? 0;
$fines_count = $fines_data['fines_count'] ?? 0;

// 5. Books by category
$sql_categories = "SELECT categories, COUNT(*) as count FROM books GROUP BY categories ORDER BY count DESC LIMIT 5";
$query_categories = mysqli_query($conn, $sql_categories);
$categories = [];
$category_counts = [];
while ($row = mysqli_fetch_assoc($query_categories)) {
    $categories[] = $row['categories'] ? $row['categories'] : 'Uncategorized';
    $category_counts[] = $row['count'];
}

// 6. Recent borrows
$sql_recent = "SELECT b.borrowId, b.memberName, b.bookName, b.borrowDate, b.returnDate 
              FROM borrow b 
              ORDER BY b.borrowId DESC LIMIT 5";
$query_recent = mysqli_query($conn, $sql_recent);

// 7. Books available vs borrowed
$available_books = $total_copies - $total_borrowed;

// 8. Books borrowed per month (last 6 months)
$months = [];
$monthly_borrows = [];
for ($i = 5; $i >= 0; $i--) {
    $month = date('M Y', strtotime("-$i months"));
    $months[] = $month;
    
    $month_start = date('Y-m-01', strtotime("-$i months"));
    $month_end = date('Y-m-t', strtotime("-$i months"));
    
    $sql_monthly = "SELECT COUNT(*) as count FROM borrow WHERE borrowDate BETWEEN '$month_start' AND '$month_end'";
    $query_monthly = mysqli_query($conn, $sql_monthly);
    $monthly_data = mysqli_fetch_assoc($query_monthly);
    $monthly_borrows[] = $monthly_data['count'] ?? 0;
}

// Handle announcements
if(isset($_POST['submit'])){
    $news = sanitize(trim($_POST['news']));
    $sql = "INSERT into news (announcement) values ('$news')"; 
    $query = mysqli_query($conn,$sql);
    $error = false;
    if($query){
        $error = true;
    }
    else{
        echo "<script>alert('Not successful!! Try again.');</script>"; 
    }
}

if(isset($_POST['del'])){
    $id = sanitize(trim($_POST['id']));
    $sql_del = "DELETE from news where newsId = $id"; 
    $result = mysqli_query($conn,$sql_del);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - Easy Library</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Load Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Add logo styling */
        .navbar-logo {
            height: 30px;
            margin-right: 10px;
        }
        
        /* Enhanced Admin Navbar Styling */
        .admin-navbar {
            background: linear-gradient(to right, #0a9396, #005f73);
            border: none;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
            margin-bottom: 25px;
            border-radius: 0;
        }
        
        .admin-navbar .navbar-brand {
            color: #ffffff !important;
            font-weight: 700;
            font-size: 22px;
            letter-spacing: 0.5px;
            padding: 15px 15px;
            height: auto;
            display: flex;
            align-items: center;
        }
        
        .admin-navbar .navbar-brand i {
            font-size: 24px;
            margin-right: 8px;
            color: #e9d8a6;
        }
        
        .admin-navbar .navbar-nav > li > a {
            color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
            padding: 18px 15px;
            position: relative;
            text-transform: uppercase;
            font-size: 13px;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }
        
        .admin-navbar .navbar-nav > li > a:hover,
        .admin-navbar .navbar-nav > li > a:focus,
        .admin-navbar .navbar-nav > li.active > a {
            color: #ffffff !important;
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .admin-navbar .navbar-nav > li.active > a:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background-color: #e9d8a6;
        }
        
        .admin-navbar .navbar-nav > li > a:hover:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background-color: rgba(233, 216, 166, 0.7);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }
        
        .admin-navbar .navbar-nav > li > a:hover:after {
            transform: scaleX(1);
        }
        
        .admin-navbar .navbar-toggle {
            border-color: transparent;
            margin-top: 12px;
        }
        
        .admin-navbar .navbar-toggle .icon-bar {
            background-color: #ffffff;
            height: 2px;
        }
        
        .admin-navbar .navbar-collapse {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .admin-navbar .user-welcome {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.9) !important;
            padding: 18px 15px;
            margin-right: 5px;
            font-weight: 500;
        }
        
        .admin-navbar .user-welcome i {
            color: #e9d8a6;
            margin-right: 8px;
            font-size: 16px;
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a {
            background-color: rgba(255, 255, 255, 0.15);
            border-radius: 4px;
            padding: 8px 15px;
            margin: 10px 0;
            transition: all 0.3s ease;
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a:hover {
            background-color: rgba(255, 255, 255, 0.25);
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a:after {
            display: none;
        }
        
        @media (max-width: 767px) {
            .admin-navbar .navbar-collapse {
                background-color: #005f73;
                max-height: none;
            }
            
            .admin-navbar .navbar-nav {
                margin: 0 -15px;
            }
            
            .admin-navbar .navbar-nav > li > a {
                padding: 12px 20px;
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            }
            
            .admin-navbar .navbar-nav > li.active > a:after {
                display: none;
            }
            
            .admin-navbar .user-welcome {
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                padding: 15px 20px;
                margin: 0;
            }
            
            .admin-navbar .navbar-nav > li.logout-btn > a {
                border-radius: 0;
                margin: 0;
                padding: 12px 20px;
            }
        }
        
        /* Admin Dashboard specific styles */
        .admin-welcome-alert {
            background-color: #f8f9fa;
            border-left: 4px solid #0a9396;
            color: #333;
            padding: 15px 20px;
            margin-top: 25px;
            border-radius: 4px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .admin-welcome-alert h4 {
            margin: 0;
            font-weight: 600;
            display: flex;
            align-items: center;
        }
        
        .admin-welcome-alert h4 i {
            margin-right: 10px;
            color: #0a9396;
        }
        
        .admin-welcome-alert span {
            color: #0a9396;
            font-weight: 700;
        }
        
        /* Stats cards */
        .stats-container {
            display: flex;
            flex-wrap: wrap;
            margin: 0 -10px;
        }
        
        .stat-card {
            flex: 1 1 calc(25% - 20px);
            margin: 10px;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            min-width: 200px;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.15);
        }
        
        .stat-card .stat-icon {
            font-size: 48px;
            margin-bottom: 15px;
            color: #0a9396;
        }
        
        .stat-card .stat-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #333;
        }
        
        .stat-card .stat-label {
            font-size: 14px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Chart cards */
        .chart-container {
            margin-top: 30px;
            display: flex;
            flex-wrap: wrap;
            margin: 30px -10px 0;
        }
        
        .chart-card {
            flex: 1 1 calc(50% - 20px);
            margin: 10px;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            min-width: 300px;
            /* Add fixed height to limit chart size */
            max-height: 350px;
            overflow: hidden;
            position: relative;
        }
        
        /* Create canvas container for proper sizing */
        .chart-canvas-container {
            position: relative;
            height: 250px;
            width: 100%;
        }
        
        .chart-title {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
            position: relative;
            padding-bottom: 8px;
            display: flex;
            align-items: center;
        }
        
        .chart-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 2px;
            background-color: #0a9396;
        }
        
        .chart-title i {
            margin-right: 8px;
            color: #0a9396;
            font-size: 14px;
        }
        
        /* Recent activity */
        .recent-activity {
            margin-top: 30px;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        
        .activity-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
            position: relative;
            padding-bottom: 10px;
            display: flex;
            align-items: center;
        }
        
        .activity-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background-color: #0a9396;
        }
        
        .activity-title i {
            margin-right: 8px;
            color: #0a9396;
        }
        
        .activity-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .activity-table th {
            text-align: left;
            padding: 12px 10px;
            border-bottom: 2px solid #eee;
            font-weight: 600;
            color: #333;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
        }
        
        .activity-table td {
            padding: 12px 10px;
            border-bottom: 1px solid #eee;
            color: #555;
        }
        
        .activity-table tr:last-child td {
            border-bottom: none;
        }
        
        .activity-table tr:hover td {
            background-color: #f9f9f9;
        }
        
        /* Announcements */
        .announcements {
            margin-top: 30px;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        
        .announcements-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        .announcements-table th {
            text-align: left;
            padding: 12px 10px;
            border-bottom: 2px solid #eee;
            font-weight: 600;
            color: #333;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
        }
        
        .announcements-table td {
            padding: 12px 10px;
            border-bottom: 1px solid #eee;
            color: #555;
        }
        
        .announcements-table tr:last-child td {
            border-bottom: none;
        }
        
        .announcements-table tr:hover td {
            background-color: #f9f9f9;
        }
        
        /* Responsive adjustments */
        @media (max-width: 991px) {
            .stat-card {
                flex: 1 1 calc(50% - 20px);
            }
            
            .chart-card {
                flex: 1 1 100%;
                margin: 10px;
            }
        }
        
        @media (max-width: 767px) {
            .stat-card {
                flex: 1 1 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Custom Admin Navbar -->
        <nav class="navbar navbar-default admin-navbar">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#admin-navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="admin.php">
                        <img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
                        <i class="fa fa-tachometer"></i> Admin Dashboard
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="admin-navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="admin.php"><i class="fa fa-home"></i> Dashboard</a></li>
                        <li><a href="bookstable.php"><i class="fa fa-book"></i> Books</a></li>
                        <li><a href="users.php"><i class="fa fa-users"></i> Admins</a></li>
                        <li><a href="viewstudents.php"><i class="fa fa-graduation-cap"></i> Students</a></li>
                        <li><a href="borrowedbooks.php"><i class="fa fa-exchange"></i> Borrowed Books</a></li>
                        <li><a href="fines.php"><i class="fa fa-money"></i> Fines</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $admin; ?></li>
                        <li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- navbar ends -->
        
        <div class="container">
            <!-- info alert -->
            <div class="admin-welcome-alert">
                <h4><i class="fa fa-bell"></i> Welcome <span><?php echo $admin; ?></span> to the Library Management Dashboard</h4>
            </div>

            <!-- Stats Cards -->
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fa fa-book"></i></div>
                    <div class="stat-value"><?php echo $total_books; ?></div>
                    <div class="stat-label">Total Books</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon"><i class="fa fa-exchange"></i></div>
                    <div class="stat-value"><?php echo $total_borrowed; ?></div>
                    <div class="stat-label">Books Borrowed</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon"><i class="fa fa-graduation-cap"></i></div>
                    <div class="stat-value"><?php echo $total_students; ?></div>
                    <div class="stat-label">Total Students</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon"><i class="fa fa-money"></i></div>
                    <div class="stat-value"><?php echo $fines_count; ?></div>
                    <div class="stat-label">Pending Fines</div>
                </div>
            </div>
            
            <!-- Charts -->
            <div class="chart-container">
                <div class="chart-card">
                    <h3 class="chart-title"><i class="fa fa-pie-chart"></i> Books Status</h3>
                    <div class="chart-canvas-container">
                        <canvas id="bookStatusChart"></canvas>
                    </div>
                </div>
                
                <div class="chart-card">
                    <h3 class="chart-title"><i class="fa fa-bar-chart"></i> Books by Category</h3>
                    <div class="chart-canvas-container">
                        <canvas id="bookCategoryChart"></canvas>
                    </div>
                </div>
                
                <div class="chart-card">
                    <h3 class="chart-title"><i class="fa fa-line-chart"></i> Monthly Book Borrowing</h3>
                    <div class="chart-canvas-container">
                        <canvas id="borrowingTrendChart"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="recent-activity">
                <h3 class="activity-title"><i class="fa fa-clock-o"></i> Recent Book Borrowings</h3>
                <table class="activity-table">
                    <thead>
                        <tr>
                            <th>Member Name</th>
                            <th>Book Title</th>
                            <th>Borrow Date</th>
                            <th>Return Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($query_recent)): ?>
                        <tr>
                            <td><?php echo $row['memberName']; ?></td>
                            <td><?php echo $row['bookName']; ?></td>
                            <td><?php echo date('M d, Y', strtotime($row['borrowDate'])); ?></td>
                            <td><?php echo date('M d, Y', strtotime($row['returnDate'])); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Announcements -->
            <div class="announcements">
                <h3 class="activity-title"><i class="fa fa-bullhorn"></i> Announcements</h3>
                <table class="announcements-table">
                    <thead>
                        <tr>
                            <th width="10%">ID</th>
                            <th width="80%">Announcement</th>
                            <th width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sql2 = "SELECT * from news ORDER BY newsId DESC";
                        $query2 = mysqli_query($conn, $sql2);
                        $counter = 1;
                        while ($row = mysqli_fetch_array($query2)) {  
                        ?>
                        <tr>
                            <td><?php echo $counter++; ?></td>
                            <td><?php echo $row['announcement']; ?></td>
                            <td>
                                <form method='post' action='admin.php'>
                                    <input type='hidden' value="<?php echo $row['newsId']; ?>" name='id'>
                                    <button name='del' type='submit' value='Delete' class='btn btn-sm btn-warning' onclick='return Delete()'>
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
                
                <!-- New Announcement Form -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Publish New Announcement</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" action="admin.php" method="post">
                            <div class="form-group">
                                <textarea class="form-control" rows="3" name="news" placeholder="Enter your announcement here..."></textarea>  
                            </div>
                            <div class="form-group text-right">
                                <button class="btn btn-primary" name="submit">
                                    <i class="fa fa-plus-circle"></i> Publish Announcement
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Chart.js scripts -->
    <script>
        // Book status chart (pie chart)
        const statusCtx = document.getElementById('bookStatusChart').getContext('2d');
        const bookStatusChart = new Chart(statusCtx, {
            type: 'pie',
            data: {
                labels: ['Available', 'Borrowed'],
                datasets: [{
                    data: [<?php echo $available_books; ?>, <?php echo $total_borrowed; ?>],
                    backgroundColor: ['#0a9396', '#e9d8a6'],
                    borderColor: ['#ffffff', '#ffffff'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12,
                            padding: 10,
                            font: {
                                size: 11
                            }
                        }
                    },
                    tooltip: {
                        bodyFont: {
                            size: 12
                        },
                        titleFont: {
                            size: 13
                        }
                    }
                }
            }
        });
        
        // Book category chart (bar chart)
        const categoryCtx = document.getElementById('bookCategoryChart').getContext('2d');
        const bookCategoryChart = new Chart(categoryCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($categories); ?>,
                datasets: [{
                    label: 'Number of Books',
                    data: <?php echo json_encode($category_counts); ?>,
                    backgroundColor: '#0a9396',
                    borderColor: '#0a9396',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        bodyFont: {
                            size: 12
                        },
                        titleFont: {
                            size: 13
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            font: {
                                size: 10
                            }
                        },
                        grid: {
                            display: true,
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        ticks: {
                            font: {
                                size: 10
                            },
                            maxRotation: 45,
                            minRotation: 45
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        
        // Borrowing trend chart (line chart)
        const trendCtx = document.getElementById('borrowingTrendChart').getContext('2d');
        const borrowingTrendChart = new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($months); ?>,
                datasets: [{
                    label: 'Books Borrowed',
                    data: <?php echo json_encode($monthly_borrows); ?>,
                    backgroundColor: 'rgba(10, 147, 150, 0.2)',
                    borderColor: '#0a9396',
                    borderWidth: 2,
                    tension: 0.1,
                    pointBackgroundColor: '#0a9396',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        bodyFont: {
                            size: 12
                        },
                        titleFont: {
                            size: 13
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            font: {
                                size: 10
                            }
                        },
                        grid: {
                            display: true,
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        ticks: {
                            font: {
                                size: 10
                            },
                            maxRotation: 45,
                            minRotation: 45
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    </script>
    
    <script type="text/javascript">
        function Delete() {
            return confirm('Would you like to delete this announcement?');
        }
    </script>

    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>	
</body>
</html>