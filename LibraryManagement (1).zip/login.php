<?php
session_start(); 

// Redirect if already logged in
if ((isset($_SESSION['auth']) && $_SESSION['auth'] === true)) {
	header("Location: admin.php");
	exit();
}

if (isset($_GET['access'])) {
	$alert_user = true;
}

require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

$error_message = "";

if(isset($_POST['submit'])){
	$username = sanitize(trim($_POST['username']));
	$password = sanitize(trim($_POST['password']));

	// First check admin login with direct comparison (assuming admins still use plaintext)
	$sql_admin = "SELECT * from admin where username = '$username' and password = '$password'";
	$query = mysqli_query($conn, $sql_admin);
	
	if(mysqli_num_rows($query) > 0) {
		while($row = mysqli_fetch_assoc($query)) {
			$_SESSION['auth'] = true;
			$_SESSION['admin'] = $row['username'];		
		}
		if ($_SESSION['auth'] === true) {
			header("Location: admin.php");
			exit();
		}
	} else {
		// For students, use password_verify to check hashed passwords
		$sql_stud = "SELECT * from students where username='$username'";
		$query = mysqli_query($conn, $sql_stud);
		
		if(mysqli_num_rows($query) > 0) {
			$row = mysqli_fetch_assoc($query);
			if(password_verify($password, $row['password'])) {
				$_SESSION['student-username'] = $row['username'];
				$_SESSION['student-name'] = $row['name'];
				$_SESSION['student-matric'] = $row['matric_no'];
				header("Location:studentportal.php");
				exit();
			} else {
				$error_message = "Invalid username or password. Please try again.";
			}
		} else {
			$error_message = "Invalid username or password. Please try again.";
		}
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>Sign In - Easy Library</title>
	<style>
		:root {
			--primary-color: #0a9396;
			--secondary-color: #005f73;
			--accent-color: #94d2bd;
			--text-color: #333;
			--light-bg: #f8f9fa;
			--white: #ffffff;
			--gray-light: #ced4da;
			--gray: #6c757d;
			--shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
			--shadow-dark: 0 10px 30px rgba(0, 0, 0, 0.15);
		}
		
		/* Override navbar styling for the login page */
		body {
			padding-top: 70px; /* Add padding for fixed navbar */
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			background-color: var(--light-bg);
			min-height: 100vh;
			position: relative;
			margin: 0;
					}		
					
		/* Ensure navbar is visible on login page */
		.navbar {
			z-index: 1030;
		}
		
		.login-page {
			display: flex;
			min-height: calc(100vh - 70px); /* Account for navbar height */
			overflow: hidden;
		}
		
		.login-left {
			flex: 1;
			background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
			color: white;
			display: flex;
			align-items: center;
			justify-content: center;
			padding: 40px;
			position: relative;
		}
		
		.login-left-content {
			max-width: 500px;
			z-index: 2;
		}
		
		.login-left-bg {
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background-image: url('images/header-bg.jpg');
			background-size: cover;
			background-position: center;
			opacity: 0.15;
		}
		
		.login-logo {
			display: flex;
			align-items: center;
			margin-bottom: 40px;
		}
		
		.login-logo i {
			font-size: 36px;
			margin-right: 15px;
		}
		
		.login-logo span {
			font-size: 28px;
			font-weight: 700;
		}
		
		.login-title {
			font-size: 40px;
			font-weight: 700;
			margin-bottom: 20px;
			line-height: 1.2;
		}
		
		.login-subtitle {
			font-size: 18px;
			opacity: 0.9;
			margin-bottom: 30px;
			line-height: 1.6;
		}
		
		.feature-list {
			margin-top: 40px;
		}
		
		.feature-item {
			display: flex;
			align-items: flex-start;
			margin-bottom: 25px;
		}
		
		.feature-icon {
			width: 40px;
			height: 40px;
			min-width: 40px;
			background-color: rgba(255, 255, 255, 0.15);
			border-radius: 50%;
			display: flex;
			align-items: center;
			justify-content: center;
			margin-right: 15px;
		}
		
		.feature-text h4 {
			font-size: 18px;
			margin-bottom: 5px;
			font-weight: 600;
		}
		
		.feature-text p {
			font-size: 14px;
			opacity: 0.8;
			margin: 0;
			line-height: 1.5;
		}
		
		.login-right {
			flex: 1;
			display: flex;
			align-items: center;
			justify-content: center;
			padding: 40px;
			background-color: var(--white);
		}
		
		.login-form-container {
			width: 100%;
			max-width: 450px;
		}
		
		.login-form-header {
			text-align: center;
			margin-bottom: 40px;
		}
		
		.login-form-header h2 {
			font-size: 30px;
			color: var(--text-color);
			font-weight: 600;
			margin-bottom: 15px;
		}
		
		.login-form-header p {
			color: var(--gray);
			font-size: 16px;
			line-height: 1.5;
		}
		
		.form-group {
			margin-bottom: 25px;
		}
		
		.form-group label {
			display: block;
			margin-bottom: 8px;
			font-weight: 500;
			color: var(--text-color);
			font-size: 15px;
		}
		
		.form-control {
			width: 100%;
			height: 55px;
			border-radius: 8px;
			border: 2px solid var(--gray-light);
			padding: 10px 45px 10px 15px;
			font-size: 16px;
			transition: all 0.3s ease;
			background-color: var(--white);
		}
		
		.form-control:focus {
			border-color: var(--primary-color);
			box-shadow: 0 0 0 3px rgba(10, 147, 150, 0.15);
			outline: none;
		}
		
		.input-group {
			position: relative;
		}
		
		.input-icon {
			position: absolute;
			right: 15px;
			top: 50%;
			transform: translateY(-50%);
			color: var(--gray);
			font-size: 18px;
		}
		
		.btn-login {
			width: 100%;
			height: 55px;
			border-radius: 8px;
			background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
			color: white;
			font-size: 16px;
			font-weight: 600;
			border: none;
			cursor: pointer;
			transition: all 0.3s ease;
			margin-top: 10px;
			box-shadow: 0 4px 10px rgba(10, 147, 150, 0.3);
		}
		
		.btn-login:hover {
			background: linear-gradient(to right, var(--secondary-color), var(--primary-color));
			transform: translateY(-2px);
			box-shadow: 0 6px 15px rgba(10, 147, 150, 0.35);
		}
		
		.form-footer {
			text-align: center;
			margin-top: 30px;
		}
		
		.form-footer p {
			color: var(--gray);
			margin-bottom: 15px;
		}
		
		.social-login {
			display: flex;
			justify-content: center;
			gap: 15px;
			margin-top: 20px;
		}
		
		.social-btn {
			width: 50px;
			height: 50px;
			display: flex;
			align-items: center;
			justify-content: center;
			border-radius: 50%;
			background-color: var(--light-bg);
			color: var(--gray);
			font-size: 20px;
			transition: all 0.3s ease;
		}
		
		.social-btn:hover {
			background-color: var(--primary-color);
			color: white;
			transform: translateY(-2px);
		}
		
		.register-link {
			margin-top: 30px;
			text-align: center;
			font-size: 15px;
			color: var(--gray);
		}
		
		.register-link a {
			color: var(--primary-color);
			font-weight: 600;
			text-decoration: none;
		}
		
		.register-link a:hover {
			text-decoration: underline;
		}
		
		.form-check {
			display: flex;
			align-items: center;
			margin-top: 15px;
			margin-bottom: 20px;
		}
		
		.form-check input {
			margin-right: 10px;
		}
		
		.form-check label {
			margin-bottom: 0;
			font-weight: 400;
			color: var(--gray);
			font-size: 14px;
		}
		
		.forget-link {
			color: var(--primary-color);
			font-weight: 500;
			text-decoration: none;
			font-size: 14px;
			display: block;
			text-align: right;
			margin-top: -25px;
			position: relative;
			z-index: 1;
		}
		
		.forget-link:hover {
			text-decoration: underline;
		}
		
		.alert-danger {
			background-color: #f8d7da;
			color: #721c24;
			padding: 12px 15px;
			border-radius: 8px;
			margin-bottom: 25px;
			border-left: 4px solid #dc3545;
			font-size: 14px;
			display: flex;
			align-items: center;
		}
		
		.alert-danger i {
			margin-right: 10px;
			font-size: 18px;
		}
		
		.divider {
			display: flex;
			align-items: center;
			margin: 30px 0;
		}
		
		.divider::before,
		.divider::after {
			content: "";
			flex: 1;
			height: 1px;
			background-color: var(--gray-light);
		}
		
		.divider span {
			padding: 0 15px;
			color: var(--gray);
			font-size: 14px;
		}
		
		@media (max-width: 991px) {
			.login-page {
				flex-direction: column;
			}
			
			.login-left, .login-right {
				flex: none;
				width: 100%;
				padding: 30px 20px;
			}
			
			.login-left {
				min-height: 300px;
			}
			
			.login-form-container {
				max-width: 100%;
			}
			
			.login-title {
				font-size: 32px;
			}
			
			.login-subtitle {
				font-size: 16px;
			}
			
			.feature-list {
				margin-top: 20px;
			}
			
			.login-form-header {
				margin-bottom: 30px;
			}
		}
		
		@media (max-width: 767px) {
			.login-page {
				flex-direction: column;
			}
			
			.login-left {
				padding: 30px 20px;
				min-height: 250px;
			}
			
			.login-logo {
				margin-bottom: 20px;
			}
			
			.feature-list {
				display: none;
			}
			
			.login-title {
				font-size: 26px;
				margin-bottom: 15px;
			}
			
			.login-subtitle {
				font-size: 14px;
				margin-bottom: 20px;
			}
		}
		
		/* Simple page footer */
		.page-footer {
			background-color: var(--light-bg);
			text-align: center;
			padding: 15px 0;
			color: var(--gray);
			font-size: 14px;
			border-top: 1px solid var(--gray-light);
		}
	</style>
</head>
<body>
	<?php include "includes/nav.php"; ?>
	
	<div class="login-page">
		<div class="login-left">
			<div class="login-left-bg"></div>
			<div class="login-left-content">
				<div class="login-logo">
					<i class="fa fa-book"></i>
					<span>Regent Library</span>
				</div>
				<h1 class="login-title">Welcome to Your Regent Digital Library Portal</h1>
				<p class="login-subtitle">Access all your library resources, manage your borrowings, and discover new books in one place.</p>
				
				<div class="feature-list">
					<div class="feature-item">
						<div class="feature-icon">
							<i class="fa fa-book"></i>
						</div>
						<div class="feature-text">
							<h4>Extensive Collection</h4>
							<p>Access over 40,000 books, journals, and digital resources</p>
						</div>
					</div>
					
					<div class="feature-item">
						<div class="feature-icon">
							<i class="fa fa-clock-o"></i>
						</div>
						<div class="feature-text">
							<h4>24/7 Accessibility</h4>
							<p>Manage your account and reservations anytime, anywhere</p>
						</div>
					</div>
					
					<div class="feature-item">
						<div class="feature-icon">
							<i class="fa fa-bell"></i>
						</div>
						<div class="feature-text">
							<h4>Smart Notifications</h4>
							<p>Get timely reminders for due dates and available holds</p>
						</div>		
					</div>
				</div>
			</div>
		</div>
		
		<div class="login-right">
			<div class="login-form-container">
				<div class="login-form-header">
					<h2>Sign in to your account</h2>
					<p>Please enter your credentials to continue</p>
				</div>
				
				<?php if(!empty($error_message)): ?>
				<div class="alert-danger">
					<i class="fa fa-exclamation-circle"></i> <?php echo $error_message; ?>
				</div>
				<?php endif; ?>
				
				<form method="post" action="login.php">
					<div class="form-group">
						<label for="username">Username</label>
						<div class="input-group">
							<input type="text" class="form-control" id="username" name="username" placeholder="Enter your username" required>
							<span class="input-icon">
								<i class="fa fa-user"></i>
							</span>
						</div>		
					</div>
					
					<div class="form-group">
						<label for="password">Password</label>
						<div class="input-group">
							<input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
							<span class="input-icon">
								<i class="fa fa-lock"></i>
							</span>
						</div>
					</div>
			
					<div class="form-check">
						<input type="checkbox" id="remember" name="remember">
						<label for="remember">Remember me</label>
					</div>
					
					<a href="#" class="forget-link">Forgot password?</a>
					
					<button type="submit" name="submit" class="btn-login">
						Sign In
					</button>
				</form>
				
				<div class="divider">
					<span>OR CONTINUE WITH</span>
				</div>
				
				<div class="social-login">
					<a href="https://www.facebook.com/rerfofficial" class="social-btn">
						<i class="fa fa-facebook"></i>
					</a>
					<a href="https://www.rerf.in/" class="social-btn">
						<i class="fa fa-google"></i>
					</a>
					<a href="https://x.com/RegentEdu/status/1798732330506522766" class="social-btn">
						<i class="fa fa-twitter"></i>
					</a>
					<a href="https://www.linkedin.com/school/regent-education-and-research-foundation-group-of-institutions-263/posts/?feedView=all" class="social-btn">
						<i class="fa fa-linkedin"></i>
					</a>
				</div>
				
				<div class="register-link">
					<p>Don't have an account? <a href="addstudent.php">Create Account</a></p>
				</div>
			</div>
		</div>
	</div>
	
	<div class="page-footer">
		<div class="container">
			<p>&copy; <?php echo date('Y'); ?> Easy Library. All rights reserved.</p>
		</div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/sweetalert.min.js"></script>
	<?php if (isset($alert_user)) { ?>
	<script type="text/javascript">
		swal("Oops...", "You are not allowed to view this page directly...!", "error");
	</script>
	<?php } ?>
</body>
</html>