<?php 

require 'includes/db-inc.php';
session_start();
$student_name = $_SESSION['student-username'];

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>Student Profile - Easy Library</title>
	<style type="text/css">

.student-navbar {
			background: linear-gradient(to right, #0a9396, #94d2bd);
			border: none;
			box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
			margin-bottom: 25px;
			border-radius: 0;
		}
		
		.student-navbar .navbar-brand {
			color: #ffffff !important;
			font-weight: 700;
			font-size: 22px;
			letter-spacing: 0.5px;
			padding: 15px 15px;
			height: auto;
			display: flex;
			align-items: center;
		}
		
		.student-navbar .navbar-brand i {
			font-size: 24px;
			margin-right: 8px;
			color: #e9d8a6;
		}
		
		.student-navbar .navbar-nav > li > a {
			color: rgba(255, 255, 255, 0.9) !important;
			font-weight: 500;
			padding: 18px 15px;
			position: relative;
			text-transform: uppercase;
			font-size: 13px;
			letter-spacing: 0.5px;
			transition: all 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li > a:hover,
		.student-navbar .navbar-nav > li > a:focus,
		.student-navbar .navbar-nav > li.active > a {
			color: #ffffff !important;
			background-color: rgba(255, 255, 255, 0.1);
		}
		
		.student-navbar .navbar-nav > li.active > a:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 3px;
			background-color: #e9d8a6;
		}
		
		.student-navbar .navbar-nav > li > a:hover:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 3px;
			background-color: rgba(233, 216, 166, 0.7);
			transform: scaleX(0);
			transition: transform 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li > a:hover:after {
			transform: scaleX(1);
		}
		
		.student-navbar .navbar-toggle {
			border-color: transparent;
			margin-top: 12px;
		}
		
		.student-navbar .navbar-toggle .icon-bar {
			background-color: #ffffff;
			height: 2px;
		}
		
		.student-navbar .navbar-collapse {
			border-color: rgba(255, 255, 255, 0.1);
		}
		
		.student-navbar .user-welcome {
			display: flex;
			align-items: center;
			color: rgba(255, 255, 255, 0.9) !important;
			padding: 18px 15px;
			margin-right: 5px;
			font-weight: 500;
		}
		
		.student-navbar .user-welcome i {
			color: #e9d8a6;
			margin-right: 8px;
			font-size: 16px;
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a {
			background-color: rgba(255, 255, 255, 0.15);
			border-radius: 4px;
			padding: 8px 15px;
			margin: 10px 0;
			transition: all 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a:hover {
			background-color: rgba(255, 255, 255, 0.25);
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a:after {
			display: none;
		}
		
		@media (max-width: 767px) {
			.student-navbar .navbar-collapse {
				background-color: #0a9396;
				max-height: none;
			}
			
			.student-navbar .navbar-nav {
				margin: 0 -15px;
			}
			
			.student-navbar .navbar-nav > li > a {
				padding: 12px 20px;
				border-bottom: 1px solid rgba(255, 255, 255, 0.1);
			}
			
			.student-navbar .navbar-nav > li.active > a:after {
				display: none;
			}
			
			.student-navbar .user-welcome {
				border-bottom: 1px solid rgba(255, 255, 255, 0.1);
				padding: 15px 20px;
				margin: 0;
			}
			
			.student-navbar .navbar-nav > li.logout-btn > a {
				border-radius: 0;
				margin: 0;
				padding: 12px 20px;
			}
		}


	body {
		background: linear-gradient(120deg,rgb(243, 248, 247),rgb(235, 241, 237) 100%);
		min-height: 100vh;
		padding-top: 70px;
	}
	.profile-wrapper {
		display: flex;
		justify-content: center;
		align-items: center;
		min-height: 80vh;
	}
	.profile-card {
		background: rgba(255,255,255,0.95);
		border-radius: 18px;
		box-shadow: 0 8px 32px 0 rgba(31,38,135,0.15);
		display: flex;
		flex-direction: row;
		padding: 40px 32px;
		gap: 32px;
		max-width: 1100px;
		width: 100%;
	}
	.profile-img-section {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 18px;
		min-width: 240px;
	}
	.profile-img-section img {
		width: 220px;
		height: 270px;
		object-fit: cover;
		border-radius: 10px;
		border: 3px solid #0a9396;
		background: #e0e0e0;
	}
	.upload-btn {
		width: 100%;
		background: linear-gradient(90deg, #11998e, #38ef7d);
		color: #fff;
		border: none;
		border-radius: 8px;
		padding: 8px 0;
		font-size: 16px;
		font-weight: 600;
		transition: background 0.2s;
		margin-top: 8px;
	}
	.upload-btn:hover {
		background: linear-gradient(90deg, #38ef7d, #11998e);
	}
	.profile-fields {
		flex: 1;
		display: flex;
		flex-direction: column;
		gap: 18px;
	}
	.field-row {
		display: flex;
		gap: 18px;
	}
	.field-col {
		flex: 1;
		display: flex;
		flex-direction: column;
		margin-bottom: 8px;
	}
	.field-col label {
		font-weight: 600;
		margin-bottom: 4px;
		color: #222;
	}
	.field-col input, .field-col textarea {
		border-radius: 6px;
		border: 1px solid #b2dfdb;
		padding: 8px 12px;
		font-size: 16px;
		background: #f6fefc;
		color: #333;
		resize: none;
	}
	.edit-btn {
		width: 100%;
		background: linear-gradient(90deg, #11998e, #38ef7d);
		color: #fff;
		border: none;
		border-radius: 18px;
		padding: 12px 0;
		font-size: 20px;
		font-weight: 600;
		margin-top: 18px;
		transition: background 0.2s;
	}
	.edit-btn:hover {
		background: linear-gradient(90deg, #38ef7d, #11998e);
	}
	
	.navbar-logo {
		height: 30px;
		margin-right: 10px;
	}
	
	@media (max-width: 900px) {
		.profile-card {
			flex-direction: column;
			align-items: center;
			padding: 24px 8px;
		}
		.profile-img-section {
			align-items: center;
		}
	}
	</style>
</head>
<body>
	<!-- Custom Student Navbar (Reverted to previous version) -->
	<nav class="navbar navbar-default navbar-fixed-top student-navbar">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#student-navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="studentportal.php">
					<img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
					<!-- <i class="fa fa-book"></i> Student Library -->
				</a>
			</div>

			<div class="collapse navbar-collapse" id="student-navbar-collapse">
				<ul class="nav navbar-nav">
					<li><a href="studentportal.php"><i class="fa fa-home"></i> Dashboard</a></li>
					<li class="active"><a href="profile.php"><i class="fa fa-user"></i> Profile</a></li>
					<li><a href="borrow-student.php"><i class="fa fa-exchange"></i> Borrow Books</a></li>
					<li><a href="fine-student.php"><i class="fa fa-money"></i> Fines</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li><a href="cart.php"><i class="fa fa-shopping-cart"></i> <span class="cart-count">0</span> Cart</a></li>
					<li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $student_name; ?></li>
					<li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
				</ul>
			</div>
		</div>
	</nav>
	<div class="container" style="display: flex; justify-content: center; align-items: center; min-height: 90vh;">
		<div class="card" style="max-width: 700px; width: 100%; background: #fff; border-radius: 18px; box-shadow: 0 8px 32px 0 rgba(31,38,135,0.15); display: flex; flex-direction: row; padding: 32px; gap: 32px;">
			<?php 
			$sql = "SELECT * from students where username = '$student_name'";
			$query = mysqli_query($conn, $sql);
			$row = mysqli_fetch_assoc($query);
			// Split name if possible
			$first_name = $last_name = '';
			if (!empty($row['name'])) {
				$name_parts = explode(' ', $row['name'], 2);
				$first_name = $name_parts[0];
				$last_name = isset($name_parts[1]) ? $name_parts[1] : '';
			}
			$photo_path = 'posts-images/' . $row['photo'];
			echo "<!-- Checking: $photo_path, Exists: " . (file_exists($photo_path) ? 'yes' : 'no') . " -->";
			$photo = (!empty($row['photo']) && file_exists($photo_path)) ? $photo_path : 'https://img.freepik.com/free-vector/3d-mannequin-head_97886-2910.jpg?size=338&ext=jpg';
			
			// Get actual books borrowed count from the borrow table
			$matricNo = $row['matric_no'];
			$borrowedBooksQuery = mysqli_query($conn, "SELECT COUNT(*) as book_count FROM borrow WHERE matricNo = '$matricNo'");
			$borrowedBooksData = mysqli_fetch_assoc($borrowedBooksQuery);
			$borrowedBooksCount = $borrowedBooksData['book_count'];
			?>
			<div style="flex: 0 0 220px; display: flex; flex-direction: column; align-items: center;">
				<img src="<?php echo $photo; ?>" alt="Profile Photo" style="width: 200px; height: 240px; object-fit: cover; border-radius: 10px; border: 3px solid #0a9396; background: #e0e0e0; margin-bottom: 18px;">
			</div>
			<div style="flex: 1; display: flex; flex-direction: column; gap: 12px; justify-content: center;">
				<h2 style="color: #0a9396; font-weight: 700; margin-bottom: 12px;"><i class="fa fa-user-circle"></i> <?php echo htmlspecialchars($first_name . ' ' . $last_name); ?></h2>
				<div style="margin-bottom: 8px;"><strong>Email:</strong> <?php echo htmlspecialchars($row['email']); ?></div>
				<div style="margin-bottom: 8px;"><strong>Phone:</strong> <?php echo htmlspecialchars($row['phoneNumber']); ?></div>
				<div style="margin-bottom: 8px;"><strong>Matric No:</strong> <?php echo htmlspecialchars($row['matric_no']); ?></div>
				<div style="margin-bottom: 8px;"><strong>Department:</strong> <?php echo htmlspecialchars($row['dept']); ?></div>
				<div style="margin-bottom: 8px;"><strong>Username:</strong> <?php echo htmlspecialchars($row['username']); ?></div>
				<div style="margin-bottom: 8px;"><strong>Books Borrowed:</strong> <?php echo htmlspecialchars($borrowedBooksCount); ?></div>
				<!-- <div style="margin-bottom: 8px;"><strong>Money Owed:</strong> <?php echo htmlspecialchars($row['moneyOwed']); ?></div> -->
				<?php if (!empty($row['address'])): ?>
					<div style="margin-bottom: 8px;"><strong>Address:</strong> <?php echo htmlspecialchars($row['address']); ?></div>
				<?php endif; ?>
				<?php if (!empty($row['city'])): ?>
					<div style="margin-bottom: 8px;"><strong>City:</strong> <?php echo htmlspecialchars($row['city']); ?></div>
				<?php endif; ?>
				<?php if (!empty($row['state'])): ?>
					<div style="margin-bottom: 8px;"><strong>State:</strong> <?php echo htmlspecialchars($row['state']); ?></div>
				<?php endif; ?>
				<?php if (!empty($row['pincode'])): ?>
					<div style="margin-bottom: 8px;"><strong>Pincode:</strong> <?php echo htmlspecialchars($row['pincode']); ?></div>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<script src="js/jquery-2.2.3.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<script>
		$(document).ready(function() {
			// Update cart count
			function updateCartCount() {
				var cart = JSON.parse(localStorage.getItem('library_cart')) || [];
				$('.cart-count').text(cart.length);
			}
			
			// Initialize
			updateCartCount();
		});
	</script>
</body>
</html>