<?php 
require 'includes/db-inc.php';
include "includes/header.php"; 
session_start();
	$book = $_SESSION['book_Title'];
	$name = $_SESSION['student-name'];
	$number = $_SESSION['student-matric'];

	
if(isset($_POST['submit'])){
	$bid = trim($_POST['bookId']);
	$bdate = trim($_POST['borrowDate']);
	$due = trim($_POST['dueDate']);

	$bqry = mysqli_query($conn,"SELECT * FROM books where bookId = {$bid} ");
	$bdata = mysqli_fetch_array($bqry);
	
	// Check if book copies are available
	if ($bdata['bookCopies'] <= 0) {
		echo "<script>alert('Sorry, this book is not available for borrowing at the moment.');</script>";
	} else {
		// Insert borrow record
		$sql = "INSERT INTO borrow(memberName, matricNo, bookName, borrowDate, returnDate, bookId, fine) values('$name', '$number', '{$bdata['bookTitle']}', '$bdate', '$due', '$bid', '0')";
		$query = mysqli_query($conn, $sql);
		
		// Update book count
		$updatedCopies = $bdata['bookCopies'] - 1;
		$available = ($updatedCopies > 0) ? "YES" : "NO";
		
		$updateBookSql = "UPDATE books SET bookCopies = '$updatedCopies', available = '$available' WHERE bookId = '$bid'";
		$updateBook = mysqli_query($conn, $updateBookSql);
		
		// Update student's numOfBooks count
		$updateStudentSql = "UPDATE students SET numOfBooks = numOfBooks + 1 WHERE matric_no = '$number'";
		$updateStudent = mysqli_query($conn, $updateStudentSql);
		
		$error = false;
		if($query && $updateBook && $updateStudent){
			$error = true;
		}
		else {
			echo "
			<script>
			alert('Unsuccessful');
			</script>
		";
		}
	}
}

if(isset($_GET['bid'])) {
	$bookId = $_GET['bid'];
	$bookQuery = mysqli_query($conn, "SELECT * FROM books WHERE bookId = '$bookId'");
	$bookData = mysqli_fetch_assoc($bookQuery);
	$bookImage = !empty($bookData['image']) && file_exists("book-images/".$bookData['image']) ? 
		"book-images/".$bookData['image'] : 
		"https://via.placeholder.com/150x200/0a9396/ffffff?text=No+Image";
}
	
?>

<style type="text/css">
    /* Enhanced Student Portal Navbar Styling */
    .student-navbar {
        background: linear-gradient(to right, #0a9396, #94d2bd);
        border: none;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
        margin-bottom: 25px;
        border-radius: 0;
    }
    
    .student-navbar .navbar-brand {
        color: #ffffff !important;
        font-weight: 700;
        font-size: 22px;
        letter-spacing: 0.5px;
        padding: 15px 15px;
        height: auto;
        display: flex;
        align-items: center;
    }
    
    .student-navbar .navbar-brand i {
        font-size: 24px;
        margin-right: 8px;
        color: #e9d8a6;
    }
    
    .student-navbar .navbar-nav > li > a {
        color: rgba(255, 255, 255, 0.9) !important;
        font-weight: 500;
        padding: 18px 15px;
        position: relative;
        text-transform: uppercase;
        font-size: 13px;
        letter-spacing: 0.5px;
        transition: all 0.3s ease;
    }
    
    .student-navbar .navbar-nav > li > a:hover,
    .student-navbar .navbar-nav > li > a:focus,
    .student-navbar .navbar-nav > li.active > a {
        color: #ffffff !important;
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .student-navbar .navbar-nav > li.active > a:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: #e9d8a6;
    }
    
    .student-navbar .navbar-nav > li > a:hover:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: rgba(233, 216, 166, 0.7);
        transform: scaleX(0);
        transition: transform 0.3s ease;
    }
    
    .student-navbar .navbar-nav > li > a:hover:after {
        transform: scaleX(1);
    }
    
    .student-navbar .navbar-toggle {
        border-color: transparent;
        margin-top: 12px;
    }
    
    .student-navbar .navbar-toggle .icon-bar {
        background-color: #ffffff;
        height: 2px;
    }
    
    .student-navbar .navbar-collapse {
        border-color: rgba(255, 255, 255, 0.1);
    }
    
    .student-navbar .user-welcome {
        display: flex;
        align-items: center;
        color: rgba(255, 255, 255, 0.9) !important;
        padding: 18px 15px;
        margin-right: 5px;
        font-weight: 500;
    }
    
    .student-navbar .user-welcome i {
        color: #e9d8a6;
        margin-right: 8px;
        font-size: 16px;
    }
    
    .student-navbar .navbar-nav > li.logout-btn > a {
        background-color: rgba(255, 255, 255, 0.15);
        border-radius: 4px;
        padding: 8px 15px;
        margin: 10px 0;
        transition: all 0.3s ease;
    }
    
    .student-navbar .navbar-nav > li.logout-btn > a:hover {
        background-color: rgba(255, 255, 255, 0.25);
    }
    
    .student-navbar .navbar-nav > li.logout-btn > a:after {
        display: none;
    }
    
    @media (max-width: 767px) {
        .student-navbar .navbar-collapse {
            background-color: #0a9396;
            max-height: none;
        }
        
        .student-navbar .navbar-nav {
            margin: 0 -15px;
        }
        
        .student-navbar .navbar-nav > li > a {
            padding: 12px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .student-navbar .navbar-nav > li.active > a:after {
            display: none;
        }
        
        .student-navbar .user-welcome {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding: 15px 20px;
            margin: 0;
        }
        
        .student-navbar .navbar-nav > li.logout-btn > a {
            border-radius: 0;
            margin: 0;
            padding: 12px 20px;
        }
    }
    
    /* Book Card Styling */
    .book-card {
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        padding: 25px;
        margin-bottom: 30px;
        transition: all 0.3s ease;
        border: 1px solid #eaeaea;
        width: 100%;
        max-width: 100%;
    }
    
    .book-card:hover {
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        transform: translateY(-5px);
    }
    
    .book-image {
        position: relative;
        overflow: hidden;
        border-radius: 8px;
        border: none;
        box-shadow: 0 5px 15px rgba(10, 147, 150, 0.2);
        margin-bottom: 20px;
    }
    
    .book-image img {
        width: 100%;
        max-width: 180px;
        max-height: 250px;
        object-fit: cover;
        border-radius: 8px;
        transition: all 0.3s ease;
    }
    
    .book-title {
        font-size: 22px;
        font-weight: 700;
        color: #333;
        margin: 15px 0 5px;
        line-height: 1.3;
    }
    
    .book-author {
        font-size: 16px;
        color: #0a9396;
        font-weight: 600;
        margin-bottom: 15px;
    }
    
    .book-details-section {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 15px;
        margin-top: 15px;
        border-left: 4px solid #0a9396;
        max-height: 150px;
        overflow-y: auto;
    }
    
    .book-details-section::-webkit-scrollbar {
        width: 8px;
    }
    
    .book-details-section::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 8px;
    }
    
    .book-details-section::-webkit-scrollbar-thumb {
        background: #0a9396;
        border-radius: 8px;
    }
    
    .book-details-section::-webkit-scrollbar-thumb:hover {
        background: #005f73;
    }
    
    .book-details-section h5 {
        font-size: 18px;
        font-weight: 700;
        color: #005f73;
        margin-top: 0;
        margin-bottom: 10px;
    }
    
    .book-details-section p {
        font-size: 15px;
        color: #333;
        line-height: 1.6;
        margin-bottom: 0;
        font-weight: 400;
    }
    
    .book-status {
        display: inline-block;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 14px;
        font-weight: 600;
        margin-top: 10px;
        background-color: #e9d8a6;
        color: #005f73;
    }
    
    .navbar-logo {
        height: 30px;
        margin-right: 10px;
    }
</style>

<div class="container">
    <!-- Student Navbar -->
    <nav class="navbar navbar-default navbar-fixed-top student-navbar">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#student-navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="studentportal.php">
                    <img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
                    <i class="fa fa-book"></i> Student Library
                </a>
            </div>

            <div class="collapse navbar-collapse" id="student-navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="studentportal.php"><i class="fa fa-home"></i> Dashboard</a></li>
                    <li><a href="profile.php"><i class="fa fa-user"></i> Profile</a></li>
                    <li class="active"><a href="borrow-student.php"><i class="fa fa-exchange"></i> Borrow Books</a></li>
                    <li><a href="fine-student.php"><i class="fa fa-money"></i> Fines</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $name; ?></li>
                    <li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
	<div class="container  col-lg-9 col-md-11 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0  " style="margin-top: 30px">
		<div class="jumbotron login col-lg-10 col-md-11 col-sm-12 col-xs-12">
			 <?php if(isset($error)===true) { ?>
        <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <strong>Record Added Successfully!</strong>
            </div>
            <?php } ?>
			<p class="page-header" style="text-align: center">LEND BOOK</p>

			<div class="container">
				<?php if(isset($_GET['bid'])): ?>
				<div class="row" style="margin-bottom: 30px;">
					<div class="col-sm-8 col-sm-offset-2">
						<div class="book-card text-center">
							<div class="book-image">
								<img src="<?php echo $bookImage; ?>" alt="Book Cover" class="mx-auto">
							</div>
							<h3 class="book-title"><?php echo $bookData['bookTitle']; ?></h3>
							<p class="book-author">By: <?php echo $bookData['author']; ?></p>
							
							<?php if(isset($bookData['bookCopies']) && $bookData['bookCopies'] > 0): ?>
							<div class="book-status">
								Available Copies: <?php echo $bookData['bookCopies']; ?>
							</div>
							<?php endif; ?>
							
							<div class="book-details-section">
								<h5><i class="fa fa-info-circle"></i> Book Details</h5>
								<p><?php echo !empty($bookData['details']) ? $bookData['details'] : 'No details available'; ?></p>
							</div>
						</div>
					</div>
				</div>
				<?php endif; ?>
				<form class="form-horizontal" role="form" action="lend-student.php" method="post" enctype="multipart/form-data">
					<div class="form-group">
						<label for="Book Title" class="col-sm-2 control-label">BOOK TITLE</label>
						<div class="col-sm-10">
							<select class="form-control" name="bookId">
								<option>SELECT BOOK</option>
								<?php 
								$sql = "SELECT * FROM books WHERE bookCopies > 0";
								$query = mysqli_query($conn, $sql);
								while ($row = mysqli_fetch_assoc($query)) { ?>
                                <option value="<?php echo $row['bookId'] ?>" <?php echo isset($_GET['bid']) && $_GET['bid'] == $row['bookId'] ? "selected" : "" ?>><?php echo $row['bookTitle']; ?> (Available: <?php echo $row['bookCopies']; ?>)</option>
                                <?php	} ?>
								 ?>

							</select>
						</div>		
					</div>
					<div class="form-group">
						<label for="Book Title" class="col-sm-2 control-label">MEMBER NAME</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="member" id="bookTitle" value="<?php echo $name; ?>">
						</div>		
					</div>
					<div class="form-group">
						<label for="Member Card ID" class="col-sm-2 control-label">MATRIC NO</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="matric" value="<?php echo $number; ?>">
						</div>		
					</div>
					<div class="form-group">
						<label for="Borrow Date" class="col-sm-2 control-label">BORROW DATE</label>
						<div class="col-sm-10">
             			 <input type="date" class="form-control" name="borrowDate" id="brand">
						</div>		
					</div>
					<div class="form-group">
						<label for="Password" class="col-sm-2 control-label">RETURN DATE</label>
						<div class="col-sm-10" id="show_product">
              			<input type='date' class='form-control' name='dueDate'>
						</div>		
					</div>
					

					
					<div class="form-group ">
						<div class="col-sm-offset-2 col-sm-10 ">
							<button type="submit" class="btn btn-info col-lg-4 " name="submit">
								Submit
							</button>
							
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	
</div>


<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>

 <script>  
 $(document).ready(function(){  
      $('#brand').change(function(){  
           var brand_id = $(this).val();  
           $.ajax({  
                url:"load_data.php",  
                method:"POST",  
                data:{brand_id:brand_id},  
                success:function(data){  
                     $('#show_product').html(data);  
                }  
           });  
      });  
 });  
 </script>
</body>
</html>