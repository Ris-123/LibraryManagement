<?php 
require 'includes/db-inc.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['student-username'])) {
    header("Location: login.php?access=false");
    exit();
}

// Get both session variables for student information
$student_username = $_SESSION['student-username'];
$student_name = $_SESSION['student-name'];

// Process cart checkout (borrow multiple books)
if(isset($_POST['borrow_all'])) {
    // Debug logs
    error_log("POST data: " . print_r($_POST, true));
    
    $bookIds = isset($_POST['selected_books']) ? $_POST['selected_books'] : [];
    $matricNo = $_POST['matric_no'];
    $borrowDate = $_POST['borrow_date'] ?? date('Y-m-d');
    $returnDate = $_POST['return_date'] ?? date('Y-m-d', strtotime('+7 days'));
    
    // Debug logs
    error_log("Selected books: " . print_r($bookIds, true));
    error_log("Matric No: $matricNo, Borrow Date: $borrowDate, Return Date: $returnDate");
    
    $success = true;
    $failed = [];
    
    // Only proceed if books were selected
    if(empty($bookIds)) {
        $_SESSION['no_books_selected'] = true;
        header("Location: cart.php");
        exit();
    }
    
    // Get student details
    $studentQuery = mysqli_query($conn, "SELECT * FROM students WHERE username = '$student_username'");
    $studentData = mysqli_fetch_assoc($studentQuery);
    $matricNo = $studentData['matric_no'];
    
    // Start transaction
    mysqli_autocommit($conn, false);
    
    foreach($bookIds as $bookId) {
        // Check book availability
        $bookQuery = mysqli_query($conn, "SELECT bookTitle, bookCopies FROM books WHERE bookId = '$bookId'");
        $bookData = mysqli_fetch_assoc($bookQuery);
        
        if($bookData['bookCopies'] > 0) {
            // Insert into borrow table - use student_name to match what fine-student.php expects
            $insertQuery = mysqli_query($conn, "INSERT INTO borrow (memberName, matricNo, bookName, borrowDate, returnDate, bookId, fine) 
                VALUES ('$student_name', '$matricNo', '{$bookData['bookTitle']}', '$borrowDate', '$returnDate', '$bookId', '0')");
            
            // Update book copies
            if($insertQuery) {
                $updateQuery = mysqli_query($conn, "UPDATE books SET bookCopies = bookCopies - 1 WHERE bookId = '$bookId'");
                if(!$updateQuery) {
                    $success = false;
                    $failed[] = $bookData['bookTitle'];
                }
            } else {
                $success = false;
                $failed[] = $bookData['bookTitle'];
            }
        } else {
            $success = false;
            $failed[] = $bookData['bookTitle'];
        }
    }
    
    // Commit or rollback
    if($success) {
        mysqli_commit($conn);
        $_SESSION['borrow_success'] = true;
        $_SESSION['clear_cart'] = true; // Signal to clear the cart after successful borrowing
        $_SESSION['borrowed_books'] = $bookIds; // Store IDs of successfully borrowed books
    } else {
        mysqli_rollback($conn);
        $_SESSION['borrow_failed'] = $failed;
    }
    
    mysqli_autocommit($conn, true);
    header("Location: cart.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="sweetalert.css">
	<title>Your Cart - Easy Library</title>
	<style type="text/css">
        /* Navbar styling (copied from borrow-student.php) */
        .student-navbar {
			background: linear-gradient(to right, #0a9396, #94d2bd);
			border: none;
			box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
			margin-bottom: 25px;
			border-radius: 0;
		}
		
		.student-navbar .navbar-brand {
			color: #ffffff !important;
			font-weight: 700;
			font-size: 22px;
			letter-spacing: 0.5px;
			padding: 15px 15px;
			height: auto;
			display: flex;
			align-items: center;
		}
		
		.student-navbar .navbar-brand i {
			font-size: 24px;
			margin-right: 8px;
			color: #e9d8a6;
		}
		
		.student-navbar .navbar-nav > li > a {
			color: rgba(255, 255, 255, 0.9) !important;
			font-weight: 500;
			padding: 18px 15px;
			position: relative;
			text-transform: uppercase;
			font-size: 13px;
			letter-spacing: 0.5px;
			transition: all 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li > a:hover,
		.student-navbar .navbar-nav > li > a:focus,
		.student-navbar .navbar-nav > li.active > a {
			color: #ffffff !important;
			background-color: rgba(255, 255, 255, 0.1);
		}
		
		.student-navbar .navbar-nav > li.active > a:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 3px;
			background-color: #e9d8a6;
		}
		
		.student-navbar .navbar-nav > li > a:hover:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 3px;
			background-color: rgba(233, 216, 166, 0.7);
			transform: scaleX(0);
			transition: transform 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li > a:hover:after {
			transform: scaleX(1);
		}
		
		.student-navbar .navbar-toggle {
			border-color: transparent;
			margin-top: 12px;
		}
		
		.student-navbar .navbar-toggle .icon-bar {
			background-color: #ffffff;
			height: 2px;
		}
		
		.student-navbar .navbar-collapse {
			border-color: rgba(255, 255, 255, 0.1);
		}
		
		.student-navbar .user-welcome {
			display: flex;
			align-items: center;
			color: rgba(255, 255, 255, 0.9) !important;
			padding: 18px 15px;
			margin-right: 5px;
			font-weight: 500;
		}
		
		.student-navbar .user-welcome i {
			color: #e9d8a6;
			margin-right: 8px;
			font-size: 16px;
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a {
			background-color: rgba(255, 255, 255, 0.15);
			border-radius: 4px;
			padding: 8px 15px;
			margin: 10px 0;
			transition: all 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a:hover {
			background-color: rgba(255, 255, 255, 0.25);
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a:after {
			display: none;
		}
		
		.navbar-logo {
			height: 30px;
			margin-right: 10px;
		}
		
		@media (max-width: 767px) {
			.student-navbar .navbar-collapse {
				background-color: #0a9396;
				max-height: none;
			}
			
			.student-navbar .navbar-nav {
				margin: 0 -15px;
			}
			
			.student-navbar .navbar-nav > li > a {
				padding: 12px 20px;
				border-bottom: 1px solid rgba(255, 255, 255, 0.1);
			}
			
			.student-navbar .navbar-nav > li.active > a:after {
				display: none;
			}
			
			.student-navbar .user-welcome {
				border-bottom: 1px solid rgba(255, 255, 255, 0.1);
				padding: 15px 20px;
				margin: 0;
			}
			
			.student-navbar .navbar-nav > li.logout-btn > a {
				border-radius: 0;
				margin: 0;
				padding: 12px 20px;
			}
		}
        
        /* Page specific styles */
        body {
            background-color: #f8f9fa;
            padding-top: 70px;
        }
        
        .cart-alert {
            background-color: #e9d8a6;
            color: #333;
            border: none;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-top: 25px;
            display: flex;
            align-items: center;
            padding: 15px 20px;
            margin-bottom: 25px;
        }
        
        .cart-alert span {
            font-size: 24px;
            margin-right: 10px;
            color: #0a9396;
        }
        
        .cart-alert strong {
            font-size: 18px;
        }
        
        .cart-items {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .cart-header {
            padding: 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .cart-header h3 {
            margin: 0;
            color: #333;
            font-weight: 600;
        }
        
        .cart-item {
            display: flex;
            border-bottom: 1px solid #eee;
            padding: 20px;
            transition: background 0.3s;
        }
        
        .cart-item:hover {
            background-color: #f9f9f9;
        }
        
        .cart-item-img {
            width: 80px;
            height: 100px;
            background-color: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .cart-item-img img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }
        
        .cart-item-details {
            flex: 1;
        }
        
        .cart-item-title {
            font-weight: 600;
            font-size: 18px;
            margin-bottom: 5px;
            color: #333;
        }
        
        .cart-item-author {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
        }
        
        .cart-item-remove {
            color: #e63946;
            cursor: pointer;
            margin-left: 10px;
            align-self: flex-start;
            border: none;
            background: none;
            padding: 0;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .cart-item-remove:hover {
            color: #c72b37;
            transform: scale(1.1);
        }
        
        .cart-empty {
            padding: 50px 20px;
            text-align: center;
            color: #666;
        }
        
        .cart-empty i {
            font-size: 50px;
            color: #ddd;
            display: block;
            margin-bottom: 20px;
        }
        
        .cart-actions {
            display: flex;
            justify-content: space-between;
            padding: 20px;
            border-top: 1px solid #eee;
        }
        
        .btn-borrow-all {
            background: linear-gradient(135deg, #0a9396, #005f73);
            border: none;
            border-radius: 50px;
            padding: 12px 30px;
            color: #fff;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 10px rgba(10, 147, 150, 0.3);
            transition: all 0.3s ease;
        }
        
        .btn-borrow-all:hover {
            background: linear-gradient(135deg, #005f73, #0a9396);
            box-shadow: 0 6px 15px rgba(10, 147, 150, 0.4);
            transform: translateY(-2px);
        }
        
        .btn-clear-cart {
            background: linear-gradient(135deg, #e63946, #d00000);
            border: none;
            border-radius: 50px;
            padding: 12px 30px;
            color: #fff;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 10px rgba(230, 57, 70, 0.3);
            transition: all 0.3s ease;
        }
        
        .btn-clear-cart:hover {
            background: linear-gradient(135deg, #d00000, #e63946);
            box-shadow: 0 6px 15px rgba(230, 57, 70, 0.4);
            transform: translateY(-2px);
        }
        
        .btn-continue-shopping {
            background: linear-gradient(135deg, #94d2bd, #0a9396);
            border: none;
            border-radius: 50px;
            padding: 12px 30px;
            color: #fff;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 10px rgba(148, 210, 189, 0.3);
            transition: all 0.3s ease;
        }
        
        .btn-continue-shopping:hover {
            background: linear-gradient(135deg, #0a9396, #94d2bd);
            box-shadow: 0 6px 15px rgba(148, 210, 189, 0.4);
            transform: translateY(-2px);
        }
        
        /* Checkbox styling */
        .cart-item-checkbox {
            display: flex;
            align-items: center;
            justify-content: center;
            padding-right: 15px;
        }
        
        .book-checkbox {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        
        .select-all-container {
            padding: 10px 20px;
            border-bottom: 1px solid #eee;
            background-color: #f5f5f5;
        }
        
        .has-error {
            border-color: #a94442;
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
        }
        
        .text-danger {
            color: #a94442;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <!-- Custom Student Navbar -->
    <nav class="navbar navbar-default navbar-fixed-top student-navbar">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#student-navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="studentportal.php">
                    <img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
                    <!-- <i class="fa fa-book"></i> Student Library -->
                </a>
            </div>

            <div class="collapse navbar-collapse" id="student-navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="studentportal.php"><i class="fa fa-home"></i> Dashboard</a></li>
                    <li><a href="profile.php"><i class="fa fa-user"></i> Profile</a></li>
                    <li><a href="borrow-student.php"><i class="fa fa-exchange"></i> Borrow Books</a></li>
                    <li><a href="fine-student.php"><i class="fa fa-money"></i> Fines</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="active"><a href="cart.php"><i class="fa fa-shopping-cart"></i> <span class="cart-count">0</span> Cart</a></li>
                    <li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $student_name; ?></li>
                    <li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- Cart Header -->
        <div class="cart-alert">
            <span class="fa fa-shopping-cart"></span>
            <strong>Your Book Cart</strong>
        </div>
        
        <?php
        // Show success message if books were borrowed successfully
        if(isset($_SESSION['borrow_success'])) {
            echo '<div class="alert alert-success"><i class="fa fa-check-circle"></i> Books have been borrowed successfully!</div>';
            unset($_SESSION['borrow_success']);
        }
        
        // Show error message if no books were selected
        if(isset($_SESSION['no_books_selected'])) {
            echo '<div class="alert alert-warning"><i class="fa fa-exclamation-circle"></i> Please select at least one book to borrow.</div>';
            unset($_SESSION['no_books_selected']);
        }
        
        // Show error message if any books failed to borrow
        if(isset($_SESSION['borrow_failed'])) {
            $failed = implode(", ", $_SESSION['borrow_failed']);
            echo '<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> Failed to borrow the following books: ' . $failed . '</div>';
            unset($_SESSION['borrow_failed']);
        }
        
        // Get student details for the form
        $sql = "SELECT * FROM students WHERE username = '$student_username'";
        $query = mysqli_query($conn, $sql);
        $student = mysqli_fetch_assoc($query);
        $matricNo = $student['matric_no'];
        
        // Default dates
        $defaultBorrowDate = date('Y-m-d');
        $defaultReturnDate = date('Y-m-d', strtotime('+7 days'));
        ?>
        
        <!-- Cart Items -->
        <div class="cart-items">
            <div class="cart-header">
                <h3><i class="fa fa-book"></i> Books in Cart</h3>
            </div>
            
            <!-- Checkout Form -->
            <form id="checkout-form" method="post" action="cart.php">
                <input type="hidden" name="matric_no" value="<?php echo $matricNo; ?>">
                
                <!-- Select All option -->
                <div class="select-all-container">
                    <label>
                        <input type="checkbox" id="select-all-books" checked> Select/Deselect All Books
                    </label>
                </div>
                
                <div id="cart-items-container">
                    <!-- Cart items will be populated with JavaScript -->
                    <div class="cart-empty">
                        <i class="fa fa-shopping-cart"></i>
                        <p>Your cart is empty.</p>
                        <a href="borrow-student.php" class="btn btn-continue-shopping">
                            <i class="fa fa-arrow-left"></i> Browse Books
                        </a>
                    </div>
                </div>
                
                <!-- Date Selection - will be shown/hidden with JavaScript -->
                <div class="date-selection-container" style="display: none;">
                    <div class="row" style="padding: 20px 20px 0;">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="borrow_date"><strong>Borrow Date:</strong></label>
                                <input type="date" id="borrow_date" name="borrow_date" class="form-control" value="<?php echo $defaultBorrowDate; ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="return_date"><strong>Return Date:</strong></label>
                                <input type="date" id="return_date" name="return_date" class="form-control" value="<?php echo $defaultReturnDate; ?>" required>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="cart-actions">
                    <a href="borrow-student.php" class="btn btn-continue-shopping">
                        <i class="fa fa-arrow-left"></i> Continue Searching 
                    </a>
                    <div>
                        <button type="button" class="btn btn-clear-cart" id="clear-cart">
                            <i class="fa fa-trash"></i> Clear Cart
                        </button>
                        <button type="submit" name="borrow_all" class="btn btn-borrow-all">
                            <i class="fa fa-check"></i> Borrow Selected Books
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="sweetalert.min.js"></script>
    <script>
        $(document).ready(function() {
            // Display cart items
            function displayCartItems() {
                var cart = JSON.parse(localStorage.getItem('library_cart')) || [];
                var cartContainer = $('#cart-items-container');
                
                // Update cart count
                $('.cart-count').text(cart.length);
                
                // Clear previous content
                cartContainer.empty();
                
                if(cart.length === 0) {
                    // Show empty cart message
                    cartContainer.html(`
                        <div class="cart-empty">
                            <i class="fa fa-shopping-cart"></i>
                            <p>Your cart is empty.</p>
                            <a href="borrow-student.php" class="btn btn-continue-shopping">
                                <i class="fa fa-arrow-left"></i> Browse Books
                            </a>
                        </div>
                    `);
                    
                    // Hide form actions
                    $('.cart-actions').hide();
                    $('.select-all-container').hide();
                    $('.date-selection-container').hide();
                } else {
                    // Show form actions
                    $('.cart-actions').show();
                    $('.select-all-container').show();
                    $('.date-selection-container').show();
                    
                    // Add each item to the cart
                    cart.forEach(function(item) {
                        cartContainer.append(`
                            <div class="cart-item">
                                <div class="cart-item-checkbox">
                                    <input type="checkbox" name="selected_books[]" value="${item.id}" class="book-checkbox" checked>
                                </div>
                                <div class="cart-item-img">
                                    <img src="${item.image}" alt="${item.title}">
                                </div>
                                <div class="cart-item-details">
                                    <div class="cart-item-title">${item.title}</div>
                                    <div class="cart-item-author"><i class="fa fa-user"></i> ${item.author}</div>
                                </div>
                                <button type="button" class="cart-item-remove" data-id="${item.id}">
                                    <i class="fa fa-times"></i>
                                </button>
                            </div>
                        `);
                    });
                }
            }
            
            // Initialize cart display
            displayCartItems();
            
            // Check if we need to clear the cart (after successful borrowing)
            <?php if(isset($_SESSION['clear_cart']) && $_SESSION['clear_cart']): ?>
                // Get borrowed book IDs
                var borrowedBookIds = <?php echo json_encode($_SESSION['borrowed_books'] ?? []); ?>;
                var cart = JSON.parse(localStorage.getItem('library_cart')) || [];
                
                // Remove borrowed books from cart
                if(borrowedBookIds.length > 0) {
                    cart = cart.filter(function(item) {
                        return !borrowedBookIds.includes(item.id.toString());
                    });
                    
                    // Save updated cart
                    localStorage.setItem('library_cart', JSON.stringify(cart));
                    
                    // Update display
                    displayCartItems();
                }
                
                <?php 
                unset($_SESSION['clear_cart']);
                unset($_SESSION['borrowed_books']);
                ?>
            <?php endif; ?>
            
            // Handle select all checkbox
            $('#select-all-books').on('change', function() {
                var isChecked = $(this).prop('checked');
                $('.book-checkbox').prop('checked', isChecked);
            });
            
            // Update select all checkbox when individual checkboxes change
            $(document).on('change', '.book-checkbox', function() {
                var allChecked = $('.book-checkbox:checked').length === $('.book-checkbox').length;
                $('#select-all-books').prop('checked', allChecked);
            });
            
            // Remove item from cart
            $(document).on('click', '.cart-item-remove', function() {
                var bookId = $(this).data('id');
                var cart = JSON.parse(localStorage.getItem('library_cart')) || [];
                
                // Filter out the removed book
                cart = cart.filter(function(item) {
                    return item.id != bookId;
                });
                
                // Save updated cart
                localStorage.setItem('library_cart', JSON.stringify(cart));
                
                // Update display
                displayCartItems();
            });
            
            // Clear cart
            $('#clear-cart').on('click', function() {
                if(confirm("Are you sure you want to clear your cart?")) {
                    localStorage.setItem('library_cart', JSON.stringify([]));
                    displayCartItems();
                }
            });
            
            // Validate dates
            $('#borrow_date, #return_date').on('change', function() {
                var borrowDate = new Date($('#borrow_date').val());
                var returnDate = new Date($('#return_date').val());
                
                if(returnDate <= borrowDate) {
                    $('#return_date').addClass('has-error');
                    $('#date-error-msg').remove();
                    $('#return_date').after('<div id="date-error-msg" class="text-danger">Return date must be after borrow date</div>');
                } else {
                    $('#return_date').removeClass('has-error');
                    $('#date-error-msg').remove();
                }
            });
            
            // Form validation before submit
            $('#checkout-form').on('submit', function(e) {
                // Check if any books are selected
                if($('.book-checkbox:checked').length === 0) {
                    e.preventDefault();
                    alert("Please select at least one book to borrow.");
                    return false;
                }
                
                // Validate dates
                var borrowDate = new Date($('#borrow_date').val());
                var returnDate = new Date($('#return_date').val());
                
                if(returnDate <= borrowDate) {
                    e.preventDefault();
                    alert("Return date must be after borrow date.");
                    return false;
                }
                
                return true;
            });
        });
    </script>
</body>
</html> 