# Email Configuration Guide

To ensure the OTP verification emails are sent properly, you need to configure the SMTP settings in `includes/mailer.php`. Here are instructions for different email providers:

## Option 1: Using Gmail

1. Open `includes/mailer.php`
2. Find the Gmail SMTP configuration section
3. Update the following lines:
   ```php
   $mail->Username = 'your.email@gmail.com'; // Replace with your Gmail address
   $mail->Password = 'your-app-password';    // Replace with your password
   ```

### For Gmail accounts with 2-Factor Authentication:
You'll need to create an "App Password":
1. Go to your Google Account settings
2. Navigate to Security > App passwords
3. Select "Mail" and "Other (Custom name)"
4. Generate and use the 16-character password provided

### For Gmail accounts without 2-Factor Authentication:
You'll need to enable "Less secure app access":
1. Go to your Google Account settings
2. Navigate to Security > Less secure app access
3. Turn on "Allow less secure apps"

## Option 2: Using Mailtrap (For Testing)

This guide will help you set up Mailtrap for email testing in your Library Management System. Mailtrap is a fake SMTP server that captures all outgoing emails for testing purposes without actually sending them to real recipients.

## Step 1: Sign Up for Mailtrap

1. Go to [Mailtrap.io](https://mailtrap.io) and sign up for a free account
2. After signing in, you'll be directed to your Mailtrap dashboard
3. In the "Email Testing" section, you'll see your default inbox (or create a new one)
4. Click on "SMTP Settings" to view your credentials

## Step 2: Get Your SMTP Credentials

1. In the SMTP Settings section, you will see various integration options
2. Select "Integrations" dropdown and choose "PHPMailer"
3. You will see code with your unique credentials that looks something like this:
   ```php
   $mail->Host = 'sandbox.smtp.mailtrap.io';
   $mail->SMTPAuth = true;
   $mail->Username = 'your_mailtrap_username'; // This will be a long string of characters
   $mail->Password = 'your_mailtrap_password'; // This will be a long string of characters
   $mail->Port = 2525;
   ```
4. Copy these credentials, especially the Username and Password values

## Step 3: Update Your Project Configuration

1. Open the file `includes/mailer.php` in your project
2. Find the Mailtrap settings section (around line 25)
3. Replace the placeholder values with your actual Mailtrap credentials:
   ```php
   $mail->Host = 'sandbox.smtp.mailtrap.io';
   $mail->SMTPAuth = true;
   $mail->Username = 'YOUR_MAILTRAP_USERNAME'; // Replace with your actual Mailtrap username
   $mail->Password = 'YOUR_MAILTRAP_PASSWORD'; // Replace with your actual Mailtrap password
   $mail->Port = 2525;
   ```
4. Save the file

## Step 4: Configure the Sender Email

In the same `mailer.php` file, update the sender email address to something appropriate for your application:

```php
$mail->setFrom('library@yourdomain.com', 'Library System');
```

## Step 5: Testing the OTP Email System

1. Start your XAMPP server (Apache and MySQL)
2. Open your library management application in a browser
3. Go to the student registration page (addstudent.php)
4. Fill out the registration form with valid information including a test email address
5. Submit the form
6. The system should generate an OTP and attempt to send it via Mailtrap
7. You will be redirected to the OTP verification page

## Step 6: Verify Emails in Mailtrap

1. Go back to your Mailtrap dashboard
2. Check your inbox to see if the OTP email was received
3. You can view the email content, HTML structure, spam analysis, and more
4. Note the OTP code in the email and use it in your verification page to complete registration

## Troubleshooting

If you're not receiving emails in Mailtrap:

1. Check your Mailtrap credentials in `includes/mailer.php` are correct
2. Verify that PHPMailer is properly installed in your project
3. Look for error messages in your PHP/Apache error logs
4. Temporarily enable debug mode by changing `$mail->SMTPDebug = 0;` to `$mail->SMTPDebug = 2;` in `mailer.php`
5. Make sure the sendOTP function is being called when a user registers

## Moving to Production

When you're ready to send real emails to actual users:

1. Sign up for a transactional email service like SendGrid, Mailgun, or use a real SMTP server
2. Update the SMTP settings in `mailer.php` to use your production email service
3. Thoroughly test the system with real email addresses
4. Set `$mail->SMTPDebug = 0;` to disable debug output in production

## Additional Notes

- Mailtrap is only for testing and will not deliver emails to real recipients
- Each Mailtrap free account has sending limits, check your plan details
- For enhanced security in production, consider storing email credentials in environment variables
- Always validate email addresses before attempting to send emails

## Option 3: Using XAMPP's Local Mail Server

1. Configure the Mercury Mail server in XAMPP:
   - Open XAMPP Control Panel
   - Click on "Config" for Mercury
   - Set up local domains and accounts
2. Open `includes/mailer.php`
3. Uncomment the Local XAMPP Mail Server configuration section and comment out the others

## Testing Your Configuration

After setting up your email configuration:
1. Register a new student account with a valid email address
2. Check if the OTP email is received
3. If not, check the error logs in XAMPP/logs directory

## Troubleshooting

If emails are not being sent:
1. Verify your SMTP settings are correct
2. Check for firewall or antivirus software blocking outgoing mail
3. Ensure your email provider allows SMTP access
4. Try different port numbers (587, 465, or 25)
5. Check XAMPP error logs for more detailed error messages 