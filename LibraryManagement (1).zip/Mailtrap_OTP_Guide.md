# Setting Up Email OTP Verification with Mailtrap

This guide will walk you through the process of setting up email OTP (One-Time Password) verification in your Library Management System using Mailtrap for testing.

## What is Mailtrap?

Mailtrap is a fake SMTP server that captures all outgoing emails sent by your application. It's perfect for testing email functionality without sending actual emails to real recipients. This way, you can safely test your OTP verification system without spamming real email addresses.

## Step 1: Sign Up for Mailtrap

1. Go to [Mailtrap.io](https://mailtrap.io) and sign up for a free account
2. After signing in, you'll be directed to your Mailtrap dashboard
3. In the "Email Testing" section, you'll see your default inbox or create a new one
4. Click on your inbox to access it

## Step 2: Get Your SMTP Credentials

1. In your inbox, click on "SMTP Settings" tab
2. From the "Integrations" dropdown, select "PHPMailer"
3. You'll see code with your unique SMTP credentials that looks like:
   ```php
   $mail->Host = 'sandbox.smtp.mailtrap.io';
   $mail->SMTPAuth = true;
   $mail->Username = 'your_unique_username';
   $mail->Password = 'your_unique_password';
   $mail->Port = 2525;
   ```
4. Copy these credentials for the next step

## Step 3: Update Your Project Configuration

1. Open the `includes/mailer.php` file in your project
2. Find the Mailtrap settings section (around line 25)
3. Replace the placeholder values with your actual Mailtrap credentials:
   ```php
   $mail->Host = 'sandbox.smtp.mailtrap.io';
   $mail->SMTPAuth = true;
   $mail->Username = 'your_unique_username'; // Replace with your actual Mailtrap username
   $mail->Password = 'your_unique_password'; // Replace with your actual Mailtrap password
   $mail->Port = 2525;
   ```
4. Update the sender email address to something appropriate:
   ```php
   $mail->setFrom('library@yourdomain.com', 'Library System');
   ```
5. Save the file

## Step 4: Testing the OTP System

1. Start your XAMPP server (ensure Apache and MySQL services are running)
2. Open your browser and navigate to your library application
3. Go to the registration page (addstudent.php)
4. Fill out the registration form with valid information including a test email
5. Submit the form
6. The system will:
   - Generate a 6-digit OTP
   - Store the registration data in the session
   - Send the OTP to the provided email via Mailtrap
   - Redirect to the OTP verification page

## Step 5: Check Your Mailtrap Inbox

1. Go back to your Mailtrap dashboard while the OTP verification page is open
2. Refresh your inbox
3. You should see a new email with the OTP
4. Open the email to view the OTP code

## Step 6: Complete the Verification

1. Enter the OTP code from Mailtrap into the verification form
2. Submit the form
3. If the OTP is correct, your account will be created and you'll see a success message
4. If incorrect, you'll see an error message and can try again

## Important Notes About OTP Security

The OTP implementation in your system includes these security features:

1. **OTP Expiration**: Each OTP expires after 10 minutes
2. **Password Hashing**: User passwords are securely hashed before storage
3. **Session Management**: OTP and registration data are securely stored in the session
4. **Visual Timer**: A countdown timer shows the user how much time is left

## Troubleshooting

If you encounter issues:

1. **OTP Not Received in Mailtrap**: 
   - Verify your Mailtrap credentials are correct
   - Check that PHPMailer is properly installed
   - Enable debugging by changing `$mail->SMTPDebug = 0;` to `$mail->SMTPDebug = 2;`

2. **OTP Verification Fails**:
   - Make sure you're entering the exact OTP shown in Mailtrap
   - Check if the OTP has expired (10-minute limit)
   - Try resending the OTP

3. **Registration Fails After OTP Verification**:
   - Check your database connection
   - Look for error messages in the PHP/Apache logs

## Moving to Production

When you're ready to send real emails:

1. Sign up for a transactional email service (SendGrid, Mailgun, etc.)
2. Update the SMTP settings in `mailer.php` with your production credentials
3. Test thoroughly with real email addresses (in a controlled way)
4. Set `$mail->SMTPDebug = 0;` to disable debug output

## Security Best Practices for OTP Systems

1. Always use HTTPS in production to protect user data
2. Implement rate limiting for OTP requests
3. Log all authentication attempts
4. Consider implementing multi-factor authentication for admin accounts
5. Regularly audit and update your security measures 