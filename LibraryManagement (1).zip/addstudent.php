<?php 
session_start();
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php"; 

if(isset($_POST['submit'])) {

    $matric = sanitize(trim($_POST['matric_no']));
    $password = sanitize(trim($_POST['password']));
    $password2 = sanitize(trim($_POST['password2']));
    $username = sanitize(trim($_POST['username']));
    $email = sanitize(trim($_POST['email']));
    $dept = sanitize(trim($_POST['dept']));
    $books = sanitize(trim($_POST['num_books']));
    $money = sanitize(trim($_POST['money_owed']));
    $phone = sanitize(trim($_POST['phone']));
    $name = sanitize(trim($_POST['name']));
    $filename =''; 

if (isset($_FILES['postimg'])) {
        $img_size = $_FILES['postimg']['size'];
        $temp = $_FILES['postimg']['tmp_name'];
        $img_type = $_FILES['postimg']['type'];
        $img_name = $_FILES['postimg']['name'];

        if ($img_size > 500000) {
            $err_flag = true;
            $error_msg = "Your image size is too big... Try again.";
        }

        $extensions = array('jpg', 'jpeg', 'png', 'gif');
        $img_ext = explode('/', $img_type);
        $img_ext = end($img_ext);
        $img_ext = strtolower($img_ext);
        if (!(in_array($img_ext, $extensions))) {
            $err_flag = true;
            $error_msg = "Unwanted image file type... Only jpg, jpeg, png and gif allowed";
        }
        // Prepare image folder in the server
        $imgFile = 'posts-images/';
        $filename = rand(1000, 8000) . '_' .time() . '.' . $img_ext;
        $filepath = $imgFile . $filename;
        
        // Move uploaded file
        move_uploaded_file($temp, $filepath);
    }

   if ($password == $password2) {
      // Check if email or username already exists
      $check_sql = "SELECT * FROM students WHERE email = '$email' OR username = '$username' OR matric_no = '$matric'";
      $check_query = mysqli_query($conn, $check_sql);
      
      if(mysqli_num_rows($check_query) > 0) {
          $registration_error = "Email, username, or matric number already exists!";
      } else {
          // Generate OTP
          $otp = rand(100000, 999999);
          
          // Store registration data in session
          $_SESSION['student_reg'] = array(
              'matric_no' => $matric,
              'password' => $password,
              'username' => $username,
              'email' => $email,
              'dept' => $dept,
              'numOfBooks' => $books,
              'moneyOwed' => $money,
              'photo' => $filename,
              'phoneNumber' => $phone,
              'name' => $name,
              'otp' => $otp
          );
          
          // Store OTP generation time for expiry check
          $_SESSION['otp_generated_time'] = time();
          unset($_SESSION['otp_expired']);
          
          // Send OTP email
          require 'includes/mailer.php';
          $mail_sent = sendOTP($email, $name, $otp);
          
          if($mail_sent) {
              // Redirect to OTP verification page
              header("Location: verify_otp.php");
              exit();
          } else {
              $registration_error = "Failed to send OTP email. Please check your email address or try again later. If the problem persists, contact the administrator.";
          }
      }
   }
   else {
    $password_error = "Passwords do not match!";
   }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Student Registration - Regent Library</title>
    <style type="text/css">
        :root {
            --primary-color: #0a9396;
            --secondary-color: #005f73;
            --accent-color: #94d2bd;
            --text-color: #333;
            --light-bg: #f8f9fa;
            --white: #ffffff;
            --gray-light: #ced4da;
            --gray: #6c757d;
            --shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            --shadow-dark: 0 10px 30px rgba(0, 0, 0, 0.15);
        }
        
        /* Override navbar styling for the registration page */
        body {
            padding-top: 70px; /* Add padding for fixed navbar */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
            min-height: 100vh;
            position: relative;
            margin: 0;
            padding-bottom: 50px;
        }
        
        /* Ensure navbar is visible on registration page */
        .navbar {
            z-index: 1030;
        }
        
        .registration-container {
            max-width: 900px;
            margin: 40px auto;
        }
        
        .registration-card {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-bottom: 30px;
        }
        
        .registration-header {
            text-align: center;
            margin-bottom: 30px;
            color: #0a9396;
            border-bottom: 2px solid #e9d8a6;
            padding-bottom: 15px;
        }
        
        .registration-header h2 {
            font-weight: 700;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .registration-header p {
            color: #666;
            font-size: 16px;
            margin-bottom: 0;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .control-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }
        
        .form-control {
            height: 45px;
            border-radius: 4px;
            border: 1px solid #ddd;
            padding: 10px 15px;
            font-size: 15px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #0a9396;
            box-shadow: 0 0 8px rgba(10, 147, 150, 0.2);
        }
        
        .help-block {
            color: #dc3545;
            font-size: 13px;
            margin-top: 5px;
        }
        
        .btn-register {
            background: linear-gradient(to right, #0a9396, #005f73);
            color: white;
            border: none;
            border-radius: 4px;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .btn-register:hover {
            background: linear-gradient(to right, #005f73, #003d47);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .alert {
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background-color: #d1e7dd;
            border-color: #badbcc;
            color: #0f5132;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c2c7;
            color: #842029;
        }
        
        .input-group-addon {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-right: none;
            color: #0a9396;
        }
        
        .input-group-addon i {
            width: 16px;
        }
        
        .file-input-label {
            background-color: #e9d8a6;
            color: #343a40;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            display: inline-block;
            margin-bottom: 0;
            font-weight: 600;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            touch-action: manipulation;
            transition: all 0.3s ease;
        }
        
        .file-input-label:hover {
            background-color: #f4a261;
        }
        
        .file-input {
            width: 0.1px;
            height: 0.1px;
            opacity: 0;
            overflow: hidden;
            position: absolute;
            z-index: -1;
        }
        
        .form-section {
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 25px;
        }
        
        .form-section-title {
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 20px;
            color: #0a9396;
            font-weight: 600;
        }
        
        .login-link {
            text-align: center;
            margin-top: 20px;
            color: #666;
        }
        
        .login-link a {
            color: #0a9396;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .login-link a:hover {
            color: #005f73;
            text-decoration: underline;
        }
        
        /* Simple page footer */
        .page-footer {
            background-color: var(--light-bg);
            text-align: center;
            padding: 15px 0;
            color: var(--gray);
            font-size: 14px;
            border-top: 1px solid var(--gray-light);
            position: absolute;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <?php include "includes/nav.php"; ?>
    
    <div class="container">
        <div class="registration-container">
            <div class="registration-card">
                <div class="registration-header">
                    <h2><i class="fa fa-user-plus"></i> Student Registration</h2>
                    <p>Create an account to access the library services</p>
                </div>

                <?php if(isset($error) && $error === true) { ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong><i class="fa fa-check-circle"></i> Success!</strong> Your account has been created successfully. You can now login.
                </div>
                <?php } ?>
                
                <?php if(isset($registration_error)) { ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong><i class="fa fa-exclamation-circle"></i> Error!</strong> <?php echo $registration_error; ?>
                </div>
                <?php } ?>
                
                <?php if(isset($error_msg)) { ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong><i class="fa fa-exclamation-circle"></i> Error!</strong> <?php echo $error_msg; ?>
                </div>
                <?php } ?>
                
                <form class="form-horizontal" role="form" action="addstudent.php" method="post" enctype="multipart/form-data">
                    <div class="form-section">
                        <div class="form-section-title">Personal Information</div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name" class="control-label">Full Name</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                        <input type="text" class="form-control" name="name" placeholder="Enter your full name" id="name" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="matric_no" class="control-label">Matric Number</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-id-card"></i></span>
                                        <input type="text" class="form-control" name="matric_no" placeholder="Enter your matric number" id="matric_no" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="dept" class="control-label">Department</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-building"></i></span>
                                        <input type="text" class="form-control" name="dept" placeholder="Enter your department" id="dept" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone" class="control-label">Phone Number</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                        <input type="text" class="form-control" name="phone" placeholder="Enter your phone number" id="phone" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="email" class="control-label">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                <input type="email" class="form-control" name="email" placeholder="Enter your email address" id="email" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="postimg" class="control-label">Profile Image</label>
                            <div class="input-group">
                                <input type="file" class="file-input" name="postimg" id="file-upload" required accept="image/*">
                                <label for="file-upload" class="file-input-label col-md-12">
                                    <i class="fa fa-cloud-upload"></i> Choose a profile image
                                </label>
                                <p class="help-block">Accepted formats: JPG, JPEG, PNG, GIF. Max size: 500KB</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <div class="form-section-title">Account Information</div>
                        <div class="form-group">
                            <label for="username" class="control-label">Username</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user-circle"></i></span>
                                <input type="text" class="form-control" name="username" placeholder="Choose a username" id="username" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="password" class="control-label">Password</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                        <input type="password" class="form-control" name="password" placeholder="Create a password" id="password" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="password2" class="control-label">Confirm Password</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                        <input type="password" class="form-control" name="password2" placeholder="Confirm your password" id="password2" required>
                                    </div>
                                    <?php if(isset($password_error)) { ?>
                                    <span class="help-block"><i class="fa fa-exclamation-triangle"></i> <?php echo $password_error; ?></span>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                        
                        <input type="hidden" name="num_books" value="0">
                        <input type="hidden" name="money_owed" value="0">
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-register" name="submit">
                                <i class="fa fa-user-plus"></i> Create Account
                            </button>
                        </div>
                    </div>
                </form>
                
                <div class="login-link">
                    Already have an account? <a href="login.php">Log in here</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="page-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Regent Library. All rights reserved.</p>
        </div>
    </div>

    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript">
        window.onload = function () {
            document.getElementById('name').focus();
        }
        
        // Display selected filename
        document.getElementById('file-upload').addEventListener('change', function(e) {
            var fileName = e.target.files[0].name;
            var label = document.querySelector('.file-input-label');
            label.innerHTML = '<i class="fa fa-file-image-o"></i> ' + fileName;
        });
    </script>
</body>
</html>