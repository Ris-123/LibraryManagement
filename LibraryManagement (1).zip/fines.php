<?php
session_start();
require 'includes/snippet.php';
require 'includes/db-inc.php';
 include "includes/header.php"; 

// Check if user is logged in as admin
if (!(isset($_SESSION['auth']) && $_SESSION['auth'] === true)) {
    header("Location: login.php?access=false");
    exit();
}
else {
    $admin = $_SESSION['admin'];
}


if(isset($_POST['del'])){
	$id = trim($_POST['del-btn']);
	$msg = "Paid";
	$sql = "UPDATE borrow set `fine` = '$msg' where borrowId = '$id'";
	$query = mysqli_query($conn, $sql);
	$error = false;
	if($query){
		$error = true;
	}
}
?>

<style>
    /* Enhanced Admin Navbar Styling */
    .admin-navbar {
        background: linear-gradient(to right, #0a9396, #005f73);
        border: none;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
        margin-bottom: 25px;
        border-radius: 0;
    }
    
    .admin-navbar .navbar-brand {
        color: #ffffff !important;
        font-weight: 700;
        font-size: 22px;
        letter-spacing: 0.5px;
        padding: 15px 15px;
        height: auto;
        display: flex;
        align-items: center;
    }
    
    .admin-navbar .navbar-brand i {
        font-size: 24px;
        margin-right: 8px;
        color: #e9d8a6;
    }
    
    .admin-navbar .navbar-nav > li > a {
        color: rgba(255, 255, 255, 0.9) !important;
        font-weight: 500;
        padding: 18px 15px;
        position: relative;
        text-transform: uppercase;
        font-size: 13px;
        letter-spacing: 0.5px;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li > a:hover,
    .admin-navbar .navbar-nav > li > a:focus,
    .admin-navbar .navbar-nav > li.active > a {
        color: #ffffff !important;
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .navbar-nav > li.active > a:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: #e9d8a6;
    }
    
    .admin-navbar .navbar-nav > li > a:hover:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background-color: rgba(233, 216, 166, 0.7);
        transform: scaleX(0);
        transition: transform 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li > a:hover:after {
        transform: scaleX(1);
    }
    
    .admin-navbar .navbar-toggle {
        border-color: transparent;
        margin-top: 12px;
    }
    
    .admin-navbar .navbar-toggle .icon-bar {
        background-color: #ffffff;
        height: 2px;
    }
    
    .admin-navbar .navbar-collapse {
        border-color: rgba(255, 255, 255, 0.1);
    }
    
    .admin-navbar .user-welcome {
        display: flex;
        align-items: center;
        color: rgba(255, 255, 255, 0.9) !important;
        padding: 18px 15px;
        margin-right: 5px;
        font-weight: 500;
    }
    
    .admin-navbar .user-welcome i {
        color: #e9d8a6;
        margin-right: 8px;
        font-size: 16px;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a {
        background-color: rgba(255, 255, 255, 0.15);
        border-radius: 4px;
        padding: 8px 15px;
        margin: 10px 0;
        transition: all 0.3s ease;
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:hover {
        background-color: rgba(255, 255, 255, 0.25);
    }
    
    .admin-navbar .navbar-nav > li.logout-btn > a:after {
        display: none;
    }
    
    @media (max-width: 767px) {
        .admin-navbar .navbar-collapse {
            background-color: #005f73;
            max-height: none;
        }
        
        .admin-navbar .navbar-nav {
            margin: 0 -15px;
        }
        
        .admin-navbar .navbar-nav > li > a {
            padding: 12px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .admin-navbar .navbar-nav > li.active > a:after {
            display: none;
        }
        
        .admin-navbar .user-welcome {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding: 15px 20px;
            margin: 0;
        }
        
        .admin-navbar .navbar-nav > li.logout-btn > a {
            border-radius: 0;
            margin: 0;
            padding: 12px 20px;
        }
    }
    
    /* Enhanced Fines Page Styles */
    .fines-alert {
        background-color: #f8f9fa;
        border-left: 4px solid #0a9396;
        color: #333;
        padding: 15px 20px;
        margin-top: 25px;
        border-radius: 4px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        display: flex;
        align-items: center;
    }
    
    .fines-alert i {
        font-size: 24px;
        color: #0a9396;
        margin-right: 10px;
    }
    
    .fines-alert strong {
        font-size: 18px;
        font-weight: 600;
    }
    
    /* Table styling */
    .panel {
        border: none;
        box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        border-radius: 5px;
        margin-bottom: 30px;
    }
    
    .panel-heading {
        background-color: #ffffff;
        padding: 20px;
        border-bottom: 1px solid #eee;
    }
    
    .panel .button {
        background: linear-gradient(to right, #0a9396, #005f73);
        border: none;
        text-transform: uppercase;
        font-weight: 600;
        letter-spacing: 0.5px;
        transition: all 0.3s ease;
    }
    
    .panel .button:hover {
        background: linear-gradient(to right, #005f73, #003d47);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    
    .table {
        margin-bottom: 0;
    }
    
    .table > thead > tr > th {
        background-color: #f5f5f5;
        border-bottom: 2px solid #0a9396;
        color: #444;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 12px;
        letter-spacing: 0.5px;
        padding: 12px 15px;
    }
    
    .table > tbody > tr > td {
        vertical-align: middle;
        padding: 12px 15px;
        border-top: 1px solid #eee;
    }
    
    .table > tbody > tr:hover {
        background-color: #f9f9f9;
    }
    
    .btn-danger {
        background-color: #e63946;
        border-color: #e63946;
        transition: all 0.3s ease;
    }
    
    .btn-danger:hover {
        background-color: #d62828;
        border-color: #d62828;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    
    .alert-success {
        background-color: #d1e7dd;
        border-color: #badbcc;
        color: #0f5132;
        border-radius: 4px;
        padding: 15px;
        margin-bottom: 20px;
    }
    
    /* Modal styling */
    .modal-content {
        border-radius: 5px;
        border: none;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .modal-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #eee;
        padding: 15px 20px;
    }
    
    .modal-body {
        padding: 20px;
    }
    
    .modal-footer {
        background-color: #f8f9fa;
        border-top: 1px solid #eee;
        padding: 15px 20px;
    }
    
    .navbar-logo {
        height: 30px;
        margin-right: 10px;
    }
</style>

<div class="container-fluid">
    <!-- Custom Admin Navbar -->
    <nav class="navbar navbar-default admin-navbar">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#admin-navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="admin.php">
                    <img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
                    <i class="fa fa-tachometer"></i> Admin Dashboard
                </a>
            </div>

            <div class="collapse navbar-collapse" id="admin-navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="admin.php"><i class="fa fa-home"></i> Dashboard</a></li>
                    <li><a href="bookstable.php"><i class="fa fa-book"></i> Books</a></li>
                    <li><a href="users.php"><i class="fa fa-users"></i> Admins</a></li>
                    <li><a href="viewstudents.php"><i class="fa fa-graduation-cap"></i> Students</a></li>
                    <li><a href="borrowedbooks.php"><i class="fa fa-exchange"></i> Borrowed Books</a></li>
                    <li class="active"><a href="fines.php"><i class="fa fa-money"></i> Fines</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $admin; ?></li>
                    <li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- navbar ends -->

<div class="container">
	<!-- info alert -->
        <div class="fines-alert">
            <i class="fa fa-money"></i>
            <strong>Fines Table</strong>
        </div>
    </div>
	</div>

	<div class="container">
		<div class="panel panel-default">
		  <!-- Default panel contents -->
		  <div class="panel-heading">
		  	 <?php if(isset($error)===true) { ?>
        <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <strong>Record Updated Successfully!</strong>
            </div>
            <?php } ?>
		  	<div class="row">
		  	  <a><button class="btn btn-success col-lg-3 col-md-4 col-sm-11 col-xs-11 button" style="margin-left: 15px;margin-bottom: 5px"> Fines</button></a>
			  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pull-right">
			  	<!-- <form >
			  		<div class="input-group pull-right">
				      <span class="input-group-addon">
				        <label>Search</label> 
				      </span>
				      <input type="text" class="form-control">
			      </div>
			  	</form> -->
			    
			  </div><!-- /.col-lg-6 -->
  
			</div>
		  </div>
		  <table class="table table-bordered">
		          <thead>
		               <tr> 
		                  <th>ID</th>
		                  <th>Member Name</th>
		                  <th>Matric Number</th>
		                  <th>Book Name</th>
		                  <th>Borrow date</th>
	                 <th>Return date</th>
		                  <th>Overdue Charges</th>
	                 <th>Action</th>
		                </tr>    
		          </thead>  
	         <tbody>
	          <?php 

                     $sql = "SELECT * FROM borrow where fine != '' AND fine != 'Paid'";
                  		$query = mysqli_query($conn, $sql);
                     $counter = 1;
                  		while($row = mysqli_fetch_assoc($query)) { 
                     	$bid = $row['borrowId'];
                     	$sid = $row['memberName'];
                      $bdate = $row['borrowDate'];
                      $due = $row['returnDate'];
                      $fine = $row['fine'];
                      $bname = $row['bookName'];
                      $mno = $row['matricNo'];                   
                     
                     

                   ?>
                   <tr>
                    <td><?php echo $counter++; ?></td>
                    <td><?php echo $sid ?></td>
                    <td><?php echo $mno ?></td>
                    <td><?php echo $bname ?></td>
                    <td><?php echo $bdate ?></td>
                    <td><?php echo $due ?></td>
                    <td><?php echo $fine ?></td>
                    <td>
                     <form action="fines.php" method="post">
                     <input type="hidden" value="<?php echo $bid ?>" name="del-btn">
                     <button name="del" type="submit" value="<?php echo $bid ?>" class="btn btn-danger">STOP Count</button>
                     	</form>
		             </td>
		            </tr> 
                 
		            <?php } ?> 
		         </tbody> 
		   </table>
		 
	
        
	</div>

	<div class="modal fade" id="info">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h3 class="modal-title">Information</h3>
        			</div>
        			<div class="modal-body">
					<p>This table shows the amount of fine that the students has to pay if he/she fails to return the book in due date.</p>
					<p>The amount of fine is 10 naira per day. This amount is calculated and updated by the admin.</p>
        			</div>
        		</div>
        		</div>
        	</div>
        </div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>	
</body>
</html>