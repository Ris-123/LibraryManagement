<?php

require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php"; 

session_start();

// Check if user is logged in as student
if (!isset($_SESSION['student-name'])) {
    header("Location: login.php?access=false");
    exit();
}
else {
    $student = $_SESSION['student-name'];
}

// Initialize fines for new borrows that don't have fine values
$initFineSql = "UPDATE borrow SET fine = '0' WHERE memberName = '$student' AND (fine IS NULL OR fine = '')";
$initFineQuery = mysqli_query($conn, $initFineSql);

// Automatically check unpaid fines when the page loads - explicitly exclude 'Paid' fines
$autoCheckSql = "SELECT borrowId FROM borrow WHERE memberName = '$student' AND fine != 'Paid'";
$autoCheckQuery = mysqli_query($conn, $autoCheckSql);
while($checkRow = mysqli_fetch_assoc($autoCheckQuery)) {
    $checkId = $checkRow['borrowId'];
    
    // First verify this fine hasn't been marked as Paid in the meantime
    $verifyNotPaidSql = "SELECT fine FROM borrow WHERE borrowId = '$checkId'";
    $verifyNotPaidQuery = mysqli_query($conn, $verifyNotPaidSql);
    $verifyNotPaidRow = mysqli_fetch_assoc($verifyNotPaidQuery);
    
    // Skip this record if it's been paid
    if ($verifyNotPaidRow['fine'] === 'Paid') {
        continue;
    }
    
    // Get return date
    $returnDateSql = "SELECT returnDate from borrow where borrowId = '$checkId'";
    $returnDateQuery = mysqli_query($conn, $returnDateSql);
    $returnDateRow = mysqli_fetch_assoc($returnDateQuery);
    
    if ($returnDateRow) {
        $now = date_create(date('Y-m-d'));
        $prev = date_create(date("Y-m-d", strtotime($returnDateRow['returnDate'])));
        $diff = date_diff($prev, $now);
        $diff = str_replace('+', '', $diff->format('%R%a'));
        
        if ($diff > 0) {
            $fine = 30 * $diff;
            $updateFineSql = "UPDATE `borrow` SET `fine`= '$fine' WHERE borrowId = '$checkId'";
            mysqli_query($conn, $updateFineSql);
        }
        else if ($now < $prev) {
            $updateFineSql = "UPDATE `borrow` SET `fine`= '0' WHERE borrowId = '$checkId'";
            mysqli_query($conn, $updateFineSql);
        }
    }
}

if(isset($_POST['del'])){
	$id = trim($_POST['del-btn']);

	$sql = "DELETE  FROM student where id = '$id'";
	$query = mysqli_query($conn, $sql);
	$error = false;
	if($query){
		$error = true;
	}
}

if (isset($_POST['check'])) {
	$id = $_POST['id'];
	
	// First check if this fine is already marked as Paid
	$checkPaidSql = "SELECT fine FROM borrow WHERE borrowId = '$id'";
	$checkPaidQuery = mysqli_query($conn, $checkPaidSql);
	$checkPaidRow = mysqli_fetch_assoc($checkPaidQuery);
	
	// Only proceed with calculation if fine is not already Paid
	if ($checkPaidRow && $checkPaidRow['fine'] !== 'Paid') {
		$sql = "SELECT returnDate from borrow where borrowId = '$id'";
		$query = mysqli_query($conn, $sql);
		$row = mysqli_fetch_assoc($query);

		if ($row) {
			$now = date_create(date('Y-m-d'));
			"<br>";
			$prev = date_create(date("Y-m-d", strtotime($row['returnDate'])));
			"<br>";
			$diff = date_diff($prev, $now);
			"<br>";
			$diff = str_replace('+', '', $diff->format('%R%a'));
			
			if ($diff > 0) {
				// echo "greater";
				$fine = 30 * $diff;

				$add = "UPDATE `borrow` SET `fine`= '$fine' WHERE borrowId = '$id'";
				$query = mysqli_query($conn, $add);
			}
			else if ($now < $prev) {
				// echo "lesser";
				$add = "UPDATE `borrow` SET `fine`= '0' WHERE borrowId = '$id'";
				$query = mysqli_query($conn, $add);
			}
		} else {
			// Handle the case where no record was found
			echo "<script>alert('No record found for this borrow ID!');</script>";
		}
	} else {
		// If already paid, show a message
		echo "<script>alert('This fine has already been paid!');</script>";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>Student Fines - Easy Library</title>
	<style type="text/css">
		/* Enhanced Student Portal Navbar Styling */
		.student-navbar {
			background: linear-gradient(to right, #0a9396, #94d2bd);
			border: none;
			box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
			margin-bottom: 25px;
			border-radius: 0;
		}
		
		.student-navbar .navbar-brand {
			color: #ffffff !important;
			font-weight: 700;
			font-size: 22px;
			letter-spacing: 0.5px;
			padding: 15px 15px;
			height: auto;
			display: flex;
			align-items: center;
		}
		
		.student-navbar .navbar-brand i {
			font-size: 24px;
			margin-right: 8px;
			color: #e9d8a6;
		}
		
		.student-navbar .navbar-nav > li > a {
			color: rgba(255, 255, 255, 0.9) !important;
			font-weight: 500;
			padding: 18px 15px;
			position: relative;
			text-transform: uppercase;
			font-size: 13px;
			letter-spacing: 0.5px;
			transition: all 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li > a:hover,
		.student-navbar .navbar-nav > li > a:focus,
		.student-navbar .navbar-nav > li.active > a {
			color: #ffffff !important;
			background-color: rgba(255, 255, 255, 0.1);
		}
		
		.student-navbar .navbar-nav > li.active > a:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 3px;
			background-color: #e9d8a6;
		}
		
		.student-navbar .navbar-nav > li > a:hover:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 3px;
			background-color: rgba(233, 216, 166, 0.7);
			transform: scaleX(0);
			transition: transform 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li > a:hover:after {
			transform: scaleX(1);
		}
		
		.student-navbar .navbar-toggle {
			border-color: transparent;
			margin-top: 12px;
		}
		
		.student-navbar .navbar-toggle .icon-bar {
			background-color: #ffffff;
			height: 2px;
		}
		
		.student-navbar .navbar-collapse {
			border-color: rgba(255, 255, 255, 0.1);
		}
		
		.student-navbar .user-welcome {
			display: flex;
			align-items: center;
			color: rgba(255, 255, 255, 0.9) !important;
			padding: 18px 15px;
			margin-right: 5px;
			font-weight: 500;
		}
		
		.student-navbar .user-welcome i {
			color: #e9d8a6;
			margin-right: 8px;
			font-size: 16px;
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a {
			background-color: rgba(255, 255, 255, 0.15);
			border-radius: 4px;
			padding: 8px 15px;
			margin: 10px 0;
			transition: all 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a:hover {
			background-color: rgba(255, 255, 255, 0.25);
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a:after {
			display: none;
		}
		
		@media (max-width: 767px) {
			.student-navbar .navbar-collapse {
				background-color: #0a9396;
				max-height: none;
			}
			
			.student-navbar .navbar-nav {
				margin: 0 -15px;
			}
			
			.student-navbar .navbar-nav > li > a {
				padding: 12px 20px;
				border-bottom: 1px solid rgba(255, 255, 255, 0.1);
			}
			
			.student-navbar .navbar-nav > li.active > a:after {
				display: none;
			}
			
			.student-navbar .user-welcome {
				border-bottom: 1px solid rgba(255, 255, 255, 0.1);
				padding: 15px 20px;
				margin: 0;
			}
			
			.student-navbar .navbar-nav > li.logout-btn > a {
				border-radius: 0;
				margin: 0;
				padding: 12px 20px;
			}
		}
		
		/* Page specific styling */
		body {
			padding-top: 70px;
			background-color: #f8f9fa;
		}
		
		.fines-alert {
			background-color: #e76f51;
			color: white;
			border: none;
			border-radius: 5px;
			box-shadow: 0 2px 10px rgba(0,0,0,0.1);
			margin-top: 25px;
			margin-bottom: 25px;
			display: flex;
			align-items: center;
			padding: 15px 20px;
			width: 100%;
		}
		
		.fines-alert span {
			font-size: 24px;
			margin-right: 10px;
			color: #fff;
		}
		
		.fines-alert strong {
			font-size: 18px;
		}
		
		.panel {
			border: none;
			box-shadow: 0 2px 10px rgba(0,0,0,0.08);
			border-radius: 5px;
			margin-bottom: 30px;
		}
		
		.panel-heading {
			background-color: #ffffff;
			padding: 20px;
			border-bottom: 1px solid #eee;
		}
		
		.panel .button {
			background: linear-gradient(to right, #0a9396, #005f73);
			border: none;
			text-transform: uppercase;
			font-weight: 600;
			letter-spacing: 0.5px;
			transition: all 0.3s ease;
			color: white;
		}
		
		.panel .button:hover {
			background: linear-gradient(to right, #005f73, #003d47);
			box-shadow: 0 4px 8px rgba(0,0,0,0.1);
		}
		
		.table {
			margin-bottom: 0;
		}
		
		.table > thead > tr > th {
			background-color: #f5f5f5;
			border-bottom: 2px solid #0a9396;
			color: #444;
			font-weight: 600;
			text-transform: uppercase;
			font-size: 12px;
			letter-spacing: 0.5px;
			padding: 12px 15px;
		}
		
		.table > tbody > tr > td {
			vertical-align: middle;
			padding: 12px 15px;
			border-top: 1px solid #eee;
		}
		
		.table > tbody > tr:hover {
			background-color: #f9f9f9;
		}
		
		.btn-warning {
			background-color: #e9c46a;
			border-color: #e9c46a;
			color: #343a40;
			font-weight: 600;
			transition: all 0.3s ease;
		}
	 
		.btn-warning:hover {
			background-color: #f4a261;
			border-color: #f4a261;
			box-shadow: 0 2px 5px rgba(0,0,0,0.1);
		}
		
		.alert-success {
			background-color: #d1e7dd;
			border-color: #badbcc;
			color: #0f5132;
			border-radius: 4px;
			padding: 15px;
			margin-bottom: 20px;
		}
		
		.navbar-logo {
			height: 30px;
			margin-right: 10px;
		}
	</style>
</head>
<body>
	<!-- Custom Student Navbar -->
	<nav class="navbar navbar-default navbar-fixed-top student-navbar">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#student-navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="studentportal.php">
					<img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
					<!-- <i class="fa fa-book"></i> Student Library -->
				</a>
			</div>

			<div class="collapse navbar-collapse" id="student-navbar-collapse">
				<ul class="nav navbar-nav">
					<li><a href="studentportal.php"><i class="fa fa-home"></i> Dashboard</a></li>
					<li><a href="profile.php"><i class="fa fa-user"></i> Profile</a></li>
					<li><a href="borrow-student.php"><i class="fa fa-exchange"></i> Borrow Books</a></li>
					<li class="active"><a href="fine-student.php"><i class="fa fa-money"></i> Fines</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li><a href="cart.php"><i class="fa fa-shopping-cart"></i> <span class="cart-count">0</span> Cart</a></li>
					<li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $student; ?></li>
					<li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
				</ul>
			</div>
		</div>
	</nav>

<div class="container">
	<!-- info alert -->
	<div class="fines-alert">
		<span class="fa fa-exclamation-triangle"></span>
	    <strong>Fines</strong> Table
	</div>

	<div class="panel panel-default">
	  <!-- Default panel contents -->
	  <div class="panel-heading">
	  	 <?php if(isset($error)===true) { ?>
        <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <strong>Record Deleted Successfully!</strong>
            </div>
            <?php } ?>
		  	<div class="row">
		  	  <a><button class="btn btn-success col-lg-3 col-md-4 col-sm-11 col-xs-11 button" style="margin-left: 15px;margin-bottom: 5px"> Your Fines</button></a>
			  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pull-right">
			  
			  </div><!-- /.col-lg-6 -->
  
			</div>
		  </div>
		  <div id="fines-table-container">
		  <table class="table table-bordered">
		          <thead>
		               <tr> 
		                  <th>ID</th>
		                  <th>Member Name</th>
		                  <th>Matric Number</th>
		                  <th>Book Name</th>
		                  <th>Borrow date</th>
		                  <th>Return Date</th>
		                  <th>Overdue Charges</th>
		                </tr>    
		          </thead>  

		           <?php 
                  		// Show all borrowed books for this student, regardless of fine status
                  		$sql = "SELECT * FROM borrow WHERE memberName = '$student'";
                  		$query = mysqli_query($conn, $sql);
                  		$counter = 1;
                  		while($row = mysqli_fetch_assoc($query)) { 
                   ?>

		          <tbody> 
		            <tr> 
		             <td><?php echo $counter++; ?></td>
		             <td><?php echo $row['memberName']; ?></td>
		             <td><?php echo $row['matricNo']; ?></td>
		             <td><?php echo $row['bookName']; ?></td>
		             <td><?php echo $row['borrowDate']; ?></td>
		             <td><?php echo $row['returnDate']; ?></td>
		             <td> 
		             	<?php 
                        // Check if fine value is "Paid" (with capital P as set in fines.php)
                        if ($row['fine'] === "Paid") {
                            echo '<span class="label label-success" style="font-size: 14px; padding: 5px 10px;">PAID</span>';
                        } else {
                            echo $row['fine']; 
                        ?>
                        <?php } ?>
		             </td>
		            </tr> 
		            <?php } ?> 
		         </tbody> 
		   </table>
		 </div>
	  </div>
	</div>
</div>

<div class="mod modal fade" id="popUpWindow">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			
        			<!-- header begins here -->
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
        				<h3 class="modal-title"> Warning</h3>
        			</div>

        			<!-- body begins here -->
        			<div class="modal-body">
        				<p>Are you sure you want to delete this book?</p>
        			</div>

        			<!-- button -->
        			<div class="modal-footer ">
        				<button class="col-lg-4 col-sm-4 col-xs-6 col-md-4 btn btn-warning pull-right"  style="margin-left: 10px" class="close" data-dismiss="modal">
        					No
        				</button>&nbsp;
        				<button class="col-lg-4 col-sm-4 col-xs-6 col-md-4 btn btn-success pull-right"  class="close" data-dismiss="modal" data-toggle="modal" data-target="#info">
        					Yes
        				</button>
        			</div>
        		</div>
        	</div>
        </div>
        <div class="modal fade" id="info">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			
        			<!-- header begins here -->
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
        				<h3 class="modal-title"> Warning</h3>
        			</div>

        			<!-- body begins here -->
        			<div class="modal-body">
        				<p>Book deleted <span class="glyphicon glyphicon-ok"></span></p>
        			</div>

        		</div>
        	</div>
        </div>
		




<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script>
// Auto-refresh the fines table every 5 seconds
$(document).ready(function() {
    setInterval(function() {
        $("#fines-table-container").load(window.location.href + " #fines-table-container > *");
    }, 5000); // 5000 milliseconds = 5 seconds
    
    // Update cart count
    function updateCartCount() {
        var cart = JSON.parse(localStorage.getItem('library_cart')) || [];
        $('.cart-count').text(cart.length);
    }
    
    // Initialize
    updateCartCount();
});
</script>	
</body>
</html>