<?php
include "includes/header.php";
session_start();

// Check if user is logged in as student
if (!isset($_SESSION['student-name'])) {
    header("Location: login.php?access=false");
    exit();
}
else {
    $student = $_SESSION['student-name'];
}

require 'includes/snippet.php';
require 'includes/db-inc.php';
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>Borrow Books - Easy Library</title>
	<style type="text/css">
		/* Enhanced Student Portal Navbar Styling */
		.student-navbar {
			background: linear-gradient(to right, #0a9396, #94d2bd);
			border: none;
			box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
			margin-bottom: 25px;
			border-radius: 0;
		}
		
		.student-navbar .navbar-brand {
			color: #ffffff !important;
			font-weight: 700;
			font-size: 22px;
			letter-spacing: 0.5px;
			padding: 15px 15px;
			height: auto;
			display: flex;
			align-items: center;
		}
		
		.student-navbar .navbar-brand i {
			font-size: 24px;
			margin-right: 8px;
			color: #e9d8a6;
		}
		
		.student-navbar .navbar-nav > li > a {
			color: rgba(255, 255, 255, 0.9) !important;
			font-weight: 500;
			padding: 18px 15px;
			position: relative;
			text-transform: uppercase;
			font-size: 13px;
			letter-spacing: 0.5px;
			transition: all 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li > a:hover,
		.student-navbar .navbar-nav > li > a:focus,
		.student-navbar .navbar-nav > li.active > a {
			color: #ffffff !important;
			background-color: rgba(255, 255, 255, 0.1);
		}
		
		.student-navbar .navbar-nav > li.active > a:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 3px;
			background-color: #e9d8a6;
		}
		
		.student-navbar .navbar-nav > li > a:hover:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 3px;
			background-color: rgba(233, 216, 166, 0.7);
			transform: scaleX(0);
			transition: transform 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li > a:hover:after {
			transform: scaleX(1);
		}
		
		.student-navbar .navbar-toggle {
			border-color: transparent;
			margin-top: 12px;
		}
		
		.student-navbar .navbar-toggle .icon-bar {
			background-color: #ffffff;
			height: 2px;
		}
		
		.student-navbar .navbar-collapse {
			border-color: rgba(255, 255, 255, 0.1);
		}
		
		.student-navbar .user-welcome {
			display: flex;
			align-items: center;
			color: rgba(255, 255, 255, 0.9) !important;
			padding: 18px 15px;
			margin-right: 5px;
			font-weight: 500;
		}
		
		.student-navbar .user-welcome i {
			color: #e9d8a6;
			margin-right: 8px;
			font-size: 16px;
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a {
			background-color: rgba(255, 255, 255, 0.15);
			border-radius: 4px;
			padding: 8px 15px;
			margin: 10px 0;
			transition: all 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a:hover {
			background-color: rgba(255, 255, 255, 0.25);
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a:after {
			display: none;
		}
		
		@media (max-width: 767px) {
			.student-navbar .navbar-collapse {
				background-color: #0a9396;
				max-height: none;
			}
			
			.student-navbar .navbar-nav {
				margin: 0 -15px;
			}
			
			.student-navbar .navbar-nav > li > a {
				padding: 12px 20px;
				border-bottom: 1px solid rgba(255, 255, 255, 0.1);
			}
			
			.student-navbar .navbar-nav > li.active > a:after {
				display: none;
			}
			
			.student-navbar .user-welcome {
				border-bottom: 1px solid rgba(255, 255, 255, 0.1);
				padding: 15px 20px;
				margin: 0;
			}
			
			.student-navbar .navbar-nav > li.logout-btn > a {
				border-radius: 0;
				margin: 0;
				padding: 12px 20px;
			}
		}
		
		/* Page specific styling */
		body {
			padding-top: 70px;
			background-color: #f8f9fa;
		}
		
		.borrow-alert {
			background-color: #e9d8a6;
			color: #333;
			border: none;
			border-radius: 5px;
			box-shadow: 0 2px 10px rgba(0,0,0,0.05);
			margin-top: 25px;
			display: flex;
			align-items: center;
			padding: 15px 20px;
		}
		
		.borrow-alert span {
			font-size: 24px;
			margin-right: 10px;
			color: #0a9396;
		}
		
		.borrow-alert strong {
			font-size: 18px;
		}
		
		.panel {
			border: none;
			box-shadow: 0 2px 10px rgba(0,0,0,0.08);
			border-radius: 5px;
			margin-bottom: 30px;
		}
		
		.panel-heading {
			background-color: #ffffff;
			padding: 20px;
			border-bottom: 1px solid #eee;
		}
		
		.table {
			margin-bottom: 0;
		}
		
		.table > thead > tr > th {
			background-color: #f5f5f5;
			border-bottom: 2px solid #0a9396;
			color: #444;
			font-weight: 600;
			text-transform: uppercase;
			font-size: 12px;
			letter-spacing: 0.5px;
			padding: 12px 15px;
		}
		
		.table > tbody > tr > td {
			vertical-align: middle;
			padding: 12px 15px;
			border-top: 1px solid #eee;
		}
		
		.table > tbody > tr:hover {
			background-color: #f9f9f9;
		}
		
		.btn-success {
			background-color: #0a9396;
			border-color: #0a9396;
			transition: all 0.3s ease;
		}
		
		.btn-success:hover {
			background-color: #008688;
			border-color: #008688;
			box-shadow: 0 2px 5px rgba(0,0,0,0.1);
		}
		
		/* Book Card Styles */
		.book-card {
			transition: all 0.3s ease;
			height: 100%;
			display: flex;
			flex-direction: column;
			border: 1px solid #e0e0e0;
			border-radius: 12px;
			overflow: hidden;
			box-shadow: 0 4px 12px rgba(0,0,0,0.08);
			margin-bottom: 30px;
			background-color: #fff;
		}
		
		.book-card:hover {
			transform: translateY(-7px);
			box-shadow: 0 10px 25px rgba(0,0,0,0.15);
			border-color: #d0d0d0;
		}
		
		.book-card-img {
			height: 250px;
			overflow: hidden;
			position: relative; 
			background-color: #f8f8f8;
			display: flex;
			align-items: center;
			justify-content: center;
			transition: all 0.4s ease;
		}
		
		.book-card-img img {
			max-width: 100%;
			max-height: 100%;
			object-fit: contain;
			transition: all 0.4s ease;
		}
		
		.book-card:hover .book-card-img img {
			transform: scale(1.08);
		}
		
		.book-card-content {
			flex: 1;
			display: flex;
			flex-direction: column;
			padding: 20px;
			min-height: 280px; /* Fixed minimum height for content */
			position: relative;
		}
		
		.book-card h4 {
			font-weight: 700;
			margin-top: 0;
			margin-bottom: 8px;
			color: #222;
			font-size: 18px;
			line-height: 1.3;
			height: 47px; /* Fixed height for two lines of title */
			overflow: hidden;
			display: -webkit-box;
			-webkit-line-clamp: 2;
			-webkit-box-orient: vertical;
		}
		
		.book-card .author {
			font-size: 14px;
			color: #666;
			margin-bottom: 18px;
			font-style: italic;
		}
		
		.book-card .author i {
			color: #0a9396;
			margin-right: 5px;
		}
		
		.book-details {
			margin-bottom: 20px;
		}
		
		.book-details h5 {
			font-weight: 600;
			margin-top: 0;
			margin-bottom: 8px;
			color: #0a9396;
			font-size: 15px;
			position: relative;
			padding-bottom: 8px;
		}
		
		.book-details h5:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 50px;
			height: 2px;
			background-color: #0a9396;
		}
		
		.book-details p {
			font-size: 13px;
			color: #666;
			line-height: 1.6;
			height: 63px; /* Fixed height for description */
			overflow: hidden;
			margin-bottom: 5px;
		}
		
		.book-meta {
			display: flex;
			margin-bottom: 20px;
			font-size: 13px;
			color: #777;
			padding: 10px 0;
			border-top: 1px dashed #eee;
			border-bottom: 1px dashed #eee;
		}
		
		.book-meta div {
			flex: 1;
		}
		
		.book-meta i {
			color: #0a9396;
			margin-right: 5px;
		}
		
		.button-container {
			margin-top: auto;
		}
		
		.availability-badge {
			position: absolute;
			top: 15px;
			right: 15px;
			z-index: 2;
		}
		
		.availability-badge .label {
			font-size: 12px;
			padding: 6px 10px;
			border-radius: 50px;
			box-shadow: 0 2px 5px rgba(0,0,0,0.1);
			font-weight: 600;
			letter-spacing: 0.5px;
		}
		
		.label-success {
			background-color: #0a9396;
		}
		
		.label-danger {
			background-color: #e63946;
		}
		
		.btn-view-more {
			color: #0a9396;
			padding: 0;
			font-weight: 600;
			font-size: 12px;
			background: none;
			border: none;
			transition: all 0.3s ease;
		}
		
		.btn-view-more:hover {
			color: #007bff;
			text-decoration: none;
		}
		
		.btn-borrow {
			border-radius: 50px;
			padding: 10px 0;
			font-weight: 600;
			letter-spacing: 0.5px;
			text-transform: uppercase;
			font-size: 14px;
			transition: all 0.3s ease;
		}
		
		.btn-success.btn-borrow {
			background: linear-gradient(135deg, #0a9396, #005f73);
			border: none;
			box-shadow: 0 4px 10px rgba(10, 147, 150, 0.3);
		}
		
		.btn-success.btn-borrow:hover {
			background: linear-gradient(135deg, #005f73, #0a9396);
			box-shadow: 0 6px 15px rgba(10, 147, 150, 0.4);
		}
		
		.btn-danger.btn-borrow {
			background: linear-gradient(135deg, #e63946, #d00000);
			border: none;
			box-shadow: 0 4px 10px rgba(230, 57, 70, 0.3);
		}
		
		.btn-danger.btn-borrow:hover {
			background: linear-gradient(135deg, #d00000, #e63946);
			box-shadow: 0 6px 15px rgba(230, 57, 70, 0.4);
		}
		
		/* Card grid responsiveness */
		.book-row {
			display: flex;
			flex-wrap: wrap;
		}
		
		.book-col {
			width: 33.333%;
			padding: 0 15px;
			margin-bottom: 30px;
		}
		
		@media (max-width: 991px) {
			.book-col {
				width: 50%;
			}
		}
		
		@media (max-width: 767px) {
			.book-col {
				width: 100%;
				margin-bottom: 20px;
			}
		}
		
		.book-unavailable:focus {
			background-color: #d32f2f;
		}
		
		.navbar-logo {
			height: 30px;
			margin-right: 10px;
		}
	</style>
</head>
<body>
	<!-- Custom Student Navbar -->
	<nav class="navbar navbar-default navbar-fixed-top student-navbar">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#student-navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="studentportal.php">
					<img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
					<!-- <i class="fa fa-book"></i> Student Library -->
				</a>
			</div>

			<div class="collapse navbar-collapse" id="student-navbar-collapse">
				<ul class="nav navbar-nav">
					<li><a href="studentportal.php"><i class="fa fa-home"></i> Dashboard</a></li>
					<li><a href="profile.php"><i class="fa fa-user"></i> Profile</a></li>
					<li class="active"><a href="borrow-student.php"><i class="fa fa-exchange"></i> Borrow Books</a></li>
					<li><a href="fine-student.php"><i class="fa fa-money"></i> Fines</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li><a href="cart.php"><i class="fa fa-shopping-cart"></i> <span class="cart-count">0</span> Cart</a></li>
					<li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $student; ?></li>
					<li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
				</ul>
			</div>
		</div>
	</nav>

<div class="container">
	<!-- info alert -->
	<div class="borrow-alert">
		<span class="fa fa-book"></span>
	    <strong>Borrow Books</strong>
	</div>

	<div class="panel panel-default">
	  <!-- Default panel contents -->
	  <div class="panel-heading">
	  	<div class="row">
			  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			  <form method="post" action="borrow-student.php" class="form-inline">
			  		<div class="input-group" style="width: 100%; margin-bottom: 15px;">
				      <input type="text" class="form-control" name="search_query" placeholder="Search by book title, author, or category..." value="<?php echo isset($_POST['search_query']) ? htmlspecialchars($_POST['search_query']) : ''; ?>">
				      <span class="input-group-btn">
				        <button class="btn btn-success" type="submit" name="search"><i class="fa fa-search"></i> Search</button>
				        <?php if(isset($_POST['search'])): ?>
				        <a href="borrow-student.php" class="btn btn-default"><i class="fa fa-refresh"></i> Reset</a>
				        <?php endif; ?>
				      </span>
			      </div>
			  </form>
			  </div>
			</div>
		  </div>

		  <div class="panel-body">
		  	<div class="book-row">
				<?php
				// SQL query builder with search
				$sql = "SELECT * FROM books";
				
				if(isset($_POST['search'])) {
					$search_query = sanitize($_POST['search_query']);
					$sql .= " WHERE bookTitle LIKE '%$search_query%' OR author LIKE '%$search_query%' OR categories LIKE '%$search_query%'";
				}
				
				$query = mysqli_query($conn, $sql);
				
				if(mysqli_num_rows($query) > 0) {
					while($row = mysqli_fetch_array($query)){
						$_SESSION['book_Title'] = $row['bookTitle'];
						
						// Determine availability class and button
						$availabilityClass = $row['bookCopies'] > 0 ? 'success' : 'danger';
						$availabilityStatus = $row['bookCopies'] > 0 ? '<span class="label label-success">Available</span>' : '<span class="label label-danger">Not Available</span>';
						$borrowButton = $row['bookCopies'] > 0 ? 
							'<a href="lend-student.php?bid='.$row['bookId'].'" class="btn btn-success btn-block btn-borrow borrow-link">Borrow Now</a>' : 
							'<button class="btn btn-danger btn-block btn-borrow book-unavailable" data-title="'.htmlspecialchars($row['bookTitle']).'">Not Available</button>';
						
						// Prepare details
						$details = !empty($row['details']) ? $row['details'] : 'No details available';
						$short_details = substr($details, 0, 100) . (strlen($details) > 100 ? '...' : '');
						
						// Prepare image path
						$imagePath = !empty($row['image']) && file_exists("book-images/".$row['image']) ? 
							"book-images/".$row['image'] : 
							"https://via.placeholder.com/200x250/0a9396/ffffff?text=No+Image";
						?>

						<div class="book-col">
							<div class="book-card">
								<!-- Card Header - Image -->
								<div class="book-card-img">
									<img src="<?php echo $imagePath; ?>" alt="<?php echo htmlspecialchars($row['bookTitle']); ?>">
									<div class="availability-badge">
										<?php echo $availabilityStatus; ?>
									</div>
								</div>
								
								<!-- Card Body - Content -->
								<div class="book-card-content">
									<h4><?php echo htmlspecialchars($row['bookTitle']); ?></h4>
									<p class="author">
										<i class="fa fa-user"></i> <?php echo htmlspecialchars($row['author']); ?>
									</p>
									
									<div class="book-details">
										<h5>Details</h5>
										<p>
											<?php echo $short_details; ?>
											<?php if(strlen($details) > 100): ?>
												<button class="btn-view-more view-details" data-toggle="modal" data-target="#detailsModal" 
													data-title="<?php echo htmlspecialchars($row['bookTitle']); ?>" 
													data-details="<?php echo htmlspecialchars($details); ?>">
													View More
												</button>
											<?php endif; ?>
										</p>
									</div>
									
									<div class="book-meta">
										<div>
											<i class="fa fa-tags"></i> <?php echo htmlspecialchars($row['categories']); ?>
										</div>
										<div>
											<i class="fa fa-copy"></i> <?php echo $row['bookCopies']; ?> available
										</div>
									</div>
							  
									<!-- Hidden inputs for JS -->
									<input type="hidden" class="book-id" value="<?php echo $row['bookId']; ?>">
									<input type="hidden" class="book-name" value="<?php echo htmlspecialchars($row['bookTitle']); ?>">
									<input type="hidden" class="book-copies" value="<?php echo $row['bookCopies']; ?>">
									
									<!-- Borrow Button -->
									<div class="button-container">
										<?php if($row['bookCopies'] > 0): ?>
										<button class="btn btn-info btn-block btn-cart add-to-cart" 
											data-id="<?php echo $row['bookId']; ?>" 
											data-title="<?php echo htmlspecialchars($row['bookTitle']); ?>"
											data-author="<?php echo htmlspecialchars($row['author']); ?>"
											data-image="<?php echo $imagePath; ?>"
											style="margin-bottom: 10px;">
											<i class="fa fa-cart-plus"></i> Add to Cart
										</button>
										<?php endif; ?>
										<?php echo $borrowButton; ?>
									</div>
								</div>
							</div>
						</div>
						
					<?php 
					}
				} else {
					echo '<div class="col-xs-12 text-center"><div class="alert alert-info"><i class="fa fa-info-circle"></i> No books found. Please try a different search.</div></div>';
				}
				?>
			</div>
		  </div>
	</div>
	
	<!-- Details Modal -->
	<div class="modal fade" id="detailsModal" tabindex="-1" role="dialog" aria-labelledby="detailsModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="detailsModalLabel">Book Details</h4>
				</div>
				<div class="modal-body">
					<p id="modal-details-content"></p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<div class="mod modal fade" id="popUpWindow">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			
        			<!-- header begins here -->
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
        				<h3 class="modal-title"> Warning</h3>
        			</div>

        			<!-- body begins here -->
        			<div class="modal-body">
        				<p>Are you sure you want to delete this book?</p>
        			</div>

        			<!-- button -->
        			<div class="modal-footer ">
        				<button class="col-lg-4 col-sm-4 col-xs-6 col-md-4 btn btn-warning pull-right"  style="margin-left: 10px" class="close" data-dismiss="modal">
        					No
        				</button>&nbsp;
        				<button class="col-lg-4 col-sm-4 col-xs-6 col-md-4 btn btn-success pull-right"  class="close" data-dismiss="modal" data-toggle="modal" data-target="#info">
        					Yes
        				</button>
        			</div>
        		</div>
        	</div>
        </div>
        <div class="modal fade" id="info">
        	<div class="modal-dialog">
        		<div class="modal-content">
        			
        			<!-- header begins here -->
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
        				<h3 class="modal-title"> Warning</h3>
        			</div>

        			<!-- body begins here -->
        			<div class="modal-body">
        				<p>Book deleted <span class="glyphicon glyphicon-ok"></span></p>
        			</div>

        		</div>
        	</div>
        </div>
		




<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>	
<script type="text/javascript" src="sweetalert.min.js"></script>

<script>
    $(document).ready(function(){
        // Handle click on "Not Available" button
        $('.book-unavailable').on('click', function() {
            var bookTitle = $(this).data('title');
            swal({
                title: "Book Unavailable",
                text: "Sorry, '" + bookTitle + "' is currently out of stock.",
                type: "error",
                confirmButtonText: "OK",
                confirmButtonColor: "#0a9396"
            });
        });
        
        // Check availability before redirecting
        $('.borrow-link').on('click', function(e) {
            var bookCopies = $(this).siblings('.book-copies').val();
            var bookName = $(this).siblings('.book-name').val();
            
            if (bookCopies <= 0) {
                e.preventDefault(); // Prevent navigation to lend-student.php
                swal({
                    title: "Book Unavailable",
                    text: "Sorry, '" + bookName + "' is currently out of stock.",
                    type: "error",
                    confirmButtonText: "OK",
                    confirmButtonColor: "#0a9396"
                });
            }
        });
        
        // Handle "View More" button click for book details
        $('.view-details').on('click', function() {
            var title = $(this).data('title');
            var details = $(this).data('details');
            
            // Update modal content
            $('#detailsModalLabel').text(title + ' - Details');
            $('#modal-details-content').text(details);
        });
        
        // Cart Functionality
        function updateCartCount() {
            var cart = JSON.parse(localStorage.getItem('library_cart')) || [];
            $('.cart-count').text(cart.length);
        }
        
        // Initialize
        updateCartCount();
        
        // Add to Cart
        $('.add-to-cart').on('click', function() {
            var bookId = $(this).data('id');
            var bookTitle = $(this).data('title');
            var bookAuthor = $(this).data('author');
            var bookImage = $(this).data('image');
            
            var cart = JSON.parse(localStorage.getItem('library_cart')) || [];
            
            // Check if book is already in cart
            var bookInCart = cart.find(function(item) {
                return item.id === bookId;
            });
            
            if (bookInCart) {
                swal({
                    title: "Already in Cart",
                    text: "'" + bookTitle + "' is already in your cart.",
                    type: "info",
                    confirmButtonText: "OK",
                    confirmButtonColor: "#0a9396"
                });
            } else {
                // Add to cart
                cart.push({
                    id: bookId,
                    title: bookTitle,
                    author: bookAuthor,
                    image: bookImage
                });
                
                // Save to localStorage
                localStorage.setItem('library_cart', JSON.stringify(cart));
                
                // Update count
                updateCartCount();
                
                swal({
                    title: "Added to Cart",
                    text: "'" + bookTitle + "' has been added to your cart.",
                    type: "success",
                    confirmButtonText: "OK",
                    confirmButtonColor: "#0a9396"
                });
            }
        });
    });
</script>
</body>
</html>