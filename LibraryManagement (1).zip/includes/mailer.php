<?php
/**
 * Email functionality for the Library Management System
 * Using SendGrid for email delivery
 */

// Store SendGrid API key and sender email (keep these secure in production)
define('SENDGRID_API_KEY', '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'); // Replace with your actual SendGrid API key
define('SENDER_EMAIL', 'royrinika5@gmail.com'); // Replace with your sender email
define('SENDER_NAME', 'Library System');

/**
 * Send OTP verification email to user
 * 
 * @param string $email Recipient email address
 * @param string $name Recipient name
 * @param string $otp One-time password for verification
 * @return bool True if email sent successfully, false otherwise
 */
function sendOTP($email, $name, $otp) {
    // Always store OTP in session for verification and fallback
    $_SESSION['last_otp'] = $otp;
    
    // Log OTP for debugging
    error_log("Generated OTP for $email: $otp");
    
    try {
        // Prepare email content
        $subject = 'OTP Verification - Library Management System';
        $htmlContent = getEmailBody($name, $otp);
        $plainContent = "Your OTP for Library System is: $otp";
        
        // Set up the API request
        $url = 'https://api.sendgrid.com/v3/mail/send';
        $data = [
            'personalizations' => [
                [
                    'to' => [
                        ['email' => $email, 'name' => $name]
                    ],
                    'subject' => $subject
                ]
            ],
            'from' => [
                'email' => SENDER_EMAIL,
                'name' => SENDER_NAME
            ],
            'content' => [
                [
                    'type' => 'text/plain',
                    'value' => $plainContent
                ],
                [
                    'type' => 'text/html',
                    'value' => $htmlContent
                ]
            ]
        ];
        
        // JSON encode the data
        $payload = json_encode($data);
        
        // Set up cURL
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . SENDGRID_API_KEY,
            'Content-Type: application/json'
        ]);
        
        // Execute the request
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        // Check if the request was successful
        if ($httpCode >= 200 && $httpCode < 300) {
            error_log("Email sent successfully to $email with OTP: $otp");
            return true;
        } else {
            error_log("Failed to send email via SendGrid. HTTP Code: $httpCode, Response: $response");
            return false;
        }
    } catch (Exception $e) {
        error_log("Email could not be sent. Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Generate the HTML email body
 * 
 * @param string $name Recipient name
 * @param string $otp One-time password
 * @return string HTML email body
 */
function getEmailBody($name, $otp) {
    return '
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #0a9396; color: white; padding: 15px; text-align: center; }
            .content { padding: 20px; background-color: #f8f9fa; border-radius: 5px; }
            .otp-box { font-size: 24px; font-weight: bold; text-align: center; 
                       padding: 15px; background-color: #e9ecef; border-radius: 5px; 
                       margin: 20px 0; letter-spacing: 5px; }
            .footer { font-size: 12px; text-align: center; margin-top: 20px; color: #6c757d; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>Library Management System</h2>
            </div>
            <div class="content">
                <p>Dear ' . $name . ',</p>
                <p>Thank you for registering with our Library Management System. To complete your registration, please use the following One-Time Password (OTP):</p>
                <div class="otp-box">' . $otp . '</div>
                <p>This OTP is valid for 10 minutes. Please do not share this OTP with anyone.</p>
                <p>If you did not request this registration, please ignore this email.</p>
                <p>Best regards,<br>Library Management Team</p>
            </div>
            <div class="footer">
                <p>This is an automated email. Please do not reply to this message.</p>
            </div>
        </div>
    </body>
    </html>
    ';
}