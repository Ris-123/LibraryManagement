<?php 
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if(isset($_POST['submit'])){
    // Enhanced input validation with error handling
    $error_messages = array();
    
    if(empty($_POST['title'])) {
        $error_messages[] = "Book title is required";
    } else {
        $title = sanitize(trim($_POST['title']));
    }
    
    if(empty($_POST['author'])) {
        $error_messages[] = "Author name is required";
    } else {
        $author = sanitize(trim($_POST['author']));
    }
    
    if(empty($_POST['label'])) {
        $error_messages[] = "ISBN is required";
    } else {
        $label = sanitize(trim($_POST['label']));
    }
    
    if(empty($_POST['bookCopies'])) {
        $error_messages[] = "Number of book copies is required";
    } else if(!is_numeric($_POST['bookCopies'])) {
        $error_messages[] = "Book copies must be a number";
    } else {
        $bookCopies = sanitize(trim($_POST['bookCopies']));
    }
    
    $publisher = sanitize(trim($_POST['publisher']));
    
    if($_POST['select'] == "SELECT") {
        $error_messages[] = "Please select availability status";
    } else {
        $select = sanitize(trim($_POST['select']));
    }
    
    $category = sanitize(trim($_POST['category']));
    $details = sanitize(trim($_POST['details']));
    
    // Handle image upload
    $bookImage = "default-book.jpg"; // Default image
    
    // Only process image if one was uploaded and there are no errors
    if(isset($_FILES['bookimg']) && $_FILES['bookimg']['error'] == 0 && $_FILES['bookimg']['size'] > 0) {
        $allowed = array('jpg', 'jpeg', 'png', 'gif');
        $filename = $_FILES['bookimg']['name'];
        $filetype = pathinfo($filename, PATHINFO_EXTENSION);
        
        // Check if file type is allowed
        if(in_array(strtolower($filetype), $allowed)) {
            // Generate unique filename
            $newname = "book_" . time() . "." . $filetype;
            $target = "book-images/" . $newname;
            
            // Create directory if it doesn't exist
            if(!file_exists("book-images")) {
                if(!mkdir("book-images", 0777, true)) {
                    $error_messages[] = "Failed to create book-images directory";
                }
            }
            
            // Move uploaded file
            if(move_uploaded_file($_FILES['bookimg']['tmp_name'], $target)) {
                $bookImage = $newname;
            } else {
                $error_messages[] = "Failed to upload image. Check directory permissions.";
            }
        } else {
            $error_messages[] = "Invalid image format. Only JPG, JPEG, PNG, and GIF are allowed.";
        }
    } else if (isset($_FILES['bookimg']) && $_FILES['bookimg']['error'] != 0 && $_FILES['bookimg']['error'] != 4) {
        // Error 4 is "no file uploaded" which is allowed
        $error_messages[] = "Image upload failed with error code: " . $_FILES['bookimg']['error'];
    }

    // Only proceed with database insertion if there are no errors
    if(empty($error_messages)) {
        // Check if ISBN already exists
        $check_sql = "SELECT * FROM books WHERE ISBN = '$label'";
        $check_result = mysqli_query($conn, $check_sql);
        
        if(mysqli_num_rows($check_result) > 0) {
            $error_messages[] = "A book with this ISBN already exists in the database";
        } else {
            // Create the SQL query
            $sql = "INSERT INTO books(bookTitle, author, ISBN, bookCopies, publisherName, available, categories, image, details)
                 VALUES ('$title','$author','$label','$bookCopies','$publisher','$select','$category','$bookImage','$details')";

            // Execute the query
            $query = mysqli_query($conn, $sql);

            if($query) {
                $success = true;
            } else {
                $error_messages[] = "Database error: " . mysqli_error($conn);
            }
        }
    }
}
?>

<div class="container" style="display: flex; justify-content: center; align-items: center; min-height: 90vh;">
    <div class="card" style="max-width: 700px; width: 100%; background: #fff; border-radius: 18px; box-shadow: 0 8px 32px 0 rgba(31,38,135,0.15); padding: 32px;">
        <div class="card-body">
            <h2 class="card-title" style="color: #2c3e50; font-weight: 700; text-align: center; margin-bottom: 24px;"><i class="fa fa-book"></i> Add Book</h2>
            
            <?php if(isset($success) && $success === true): ?>
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <strong><i class="fa fa-check-circle"></i> Success!</strong> Book has been added successfully.
                <div style="margin-top: 10px;">
                    <a href="bookstable.php" class="btn btn-sm btn-primary">View Books Table</a>
                    <button type="button" class="btn btn-sm btn-default" onclick="window.location.href='addbook.php'">Add Another Book</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if(isset($error_messages) && !empty($error_messages)): ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <strong><i class="fa fa-exclamation-circle"></i> Error!</strong>
                <ul style="margin-top: 5px;">
                    <?php foreach($error_messages as $error): ?>
                    <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            
            <form class="form-horizontal" role="form" enctype="multipart/form-data" action="addbook.php" method="post">
                <div class="form-group">
                    <label for="Title" class="col-sm-3 control-label">BOOK TITLE</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="title" placeholder="Enter Title" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="Author" class="col-sm-3 control-label">AUTHOR</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="author" placeholder="Enter Author" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="ISBN" class="col-sm-3 control-label">ISBN</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="label" placeholder="Enter ISBN" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="Book Copies" class="col-sm-3 control-label">BOOK COPIES</label>
                    <div class="col-sm-9">
                        <input type="number" min="1" class="form-control" name="bookCopies" placeholder="Enter BOOK COPIES" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="Publisher" class="col-sm-3 control-label">PUBLISHER</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="publisher" placeholder="Enter Publisher" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="Password" class="col-sm-3 control-label">AVAILABLE</label>
                    <div class="col-sm-9">
                        <select class="form-control" name="select" required>
                            <option>SELECT</option>
                            <option>YES</option>
                            <option>NO</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="Publisher" class="col-sm-3 control-label">CATEGORY</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="category" placeholder="Enter Category" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="details" class="col-sm-3 control-label">BOOK DETAILS</label>
                    <div class="col-sm-9">
                        <textarea class="form-control" name="details" rows="4" placeholder="Enter book description, publication details, or any other information"></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <label for="bookimg" class="col-sm-3 control-label">Book Image</label>
                    <div class="col-sm-9">
                        <input type="file" class="form-control" name="bookimg" id="bookimg" accept="image/*">
                        <p class="help-block">Upload an image for this book. Accepted formats: JPG, JPEG, PNG, GIF.</p>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-9">
                        <button name="submit" class="btn btn-primary btn-block" style="background: linear-gradient(90deg, #2c3e50, #3498db); border: none; border-radius: 8px; font-weight: 600; font-size: 18px;">
                            <i class="fa fa-plus"></i> Add Book
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript">
 	window.onload = function () {
		var input = document.querySelector('input[name="title"]').focus();
	}
 </script>
</body>
</html>