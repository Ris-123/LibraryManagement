<?php
session_start();

// Check if user is logged in as student
if (!isset($_SESSION['student-name'])) {
    header("Location: login.php?access=false");
    exit();
}
else {
    $student = $_SESSION['student-name'];
}

require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="flickity/flickity.css">
	<script type="text/javascript" src="flickity/flickity.js"></script>
	<title>Student Portal - Easy Library</title>
	<style>
		/* Enhanced Student Portal Navbar Styling */
		.student-navbar {
			background: linear-gradient(to right, #0a9396, #94d2bd);
			border: none;
			box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
			margin-bottom: 25px;
			border-radius: 0;
		}
		
		.student-navbar .navbar-brand {
			color: #ffffff !important;
			font-weight: 700;
			font-size: 22px;
			letter-spacing: 0.5px;
			padding: 15px 15px;
			height: auto;
			display: flex;
			align-items: center;
		}
		
		.navbar-logo {
			height: 30px;
			margin-right: 10px;
		}
		
		.student-navbar .navbar-brand i {
			font-size: 24px;
			margin-right: 8px;
			color: #e9d8a6;
		}
		
		.student-navbar .navbar-nav > li > a {
			color: rgba(255, 255, 255, 0.9) !important;
			font-weight: 500;
			padding: 18px 15px;
			position: relative;
			text-transform: uppercase;
			font-size: 13px;
			letter-spacing: 0.5px;
			transition: all 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li > a:hover,
		.student-navbar .navbar-nav > li > a:focus,
		.student-navbar .navbar-nav > li.active > a {
			color: #ffffff !important;
			background-color: rgba(255, 255, 255, 0.1);
		}
		
		.student-navbar .navbar-nav > li.active > a:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 3px;
			background-color: #e9d8a6;
		}
		
		.student-navbar .navbar-nav > li > a:hover:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 3px;
			background-color: rgba(233, 216, 166, 0.7);
			transform: scaleX(0);
			transition: transform 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li > a:hover:after {
			transform: scaleX(1);
		}
		
		.student-navbar .navbar-toggle {
			border-color: transparent;
			margin-top: 12px;
		}
		
		.student-navbar .navbar-toggle .icon-bar {
			background-color: #ffffff;
			height: 2px;
		}
		
		.student-navbar .navbar-collapse {
			border-color: rgba(255, 255, 255, 0.1);
		}
		
		.student-navbar .user-welcome {
			display: flex;
			align-items: center;
			color: rgba(255, 255, 255, 0.9) !important;
			padding: 18px 15px;
			margin-right: 5px;
			font-weight: 500;
		}
		
		.student-navbar .user-welcome i {
			color: #e9d8a6;
			margin-right: 8px;
			font-size: 16px;
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a {
			background-color: rgba(255, 255, 255, 0.15);
			border-radius: 4px;
			padding: 8px 15px;
			margin: 10px 0;
			transition: all 0.3s ease;
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a:hover {
			background-color: rgba(255, 255, 255, 0.25);
		}
		
		.student-navbar .navbar-nav > li.logout-btn > a:after {
			display: none;
		}
		
		@media (max-width: 767px) {
			.student-navbar .navbar-collapse {
				background-color: #0a9396;
				max-height: none;
			}
			
			.student-navbar .navbar-nav {
				margin: 0 -15px;
			}
			
			.student-navbar .navbar-nav > li > a {
				padding: 12px 20px;
				border-bottom: 1px solid rgba(255, 255, 255, 0.1);
			}
			
			.student-navbar .navbar-nav > li.active > a:after {
				display: none;
			}
			
			.student-navbar .user-welcome {
				border-bottom: 1px solid rgba(255, 255, 255, 0.1);
				padding: 15px 20px;
				margin: 0;
			}
			
			.student-navbar .navbar-nav > li.logout-btn > a {
				border-radius: 0;
				margin: 0;
				padding: 12px 20px;
			}
		}
		
		/* Reset body padding to account for new fixed navbar */
		body {
			padding-top: 70px;
		}
		
		.welcome-alert {
			margin-top: 20px;
			margin-bottom: 30px;
			background-color: #0a9396;
			color: white;
			border-color: #005f73;
		}
		.welcome-alert h4 {
			text-align: center;
			font-weight: 500;
		}
		.welcome-alert h4 span {
			font-weight: 700;
		}
		.feature-box {
			padding: 20px;
			background-color: white;
			border-radius: 8px;
			box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
			height: 100%;
		}
		.feature-box h2 {
			color: #0a9396;
			margin-bottom: 20px;
		}
		.carousel {
			border-radius: 8px;
			overflow: hidden;
			margin-bottom: 30px;
			box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
		}
	</style>
</head>
<body>
	<!-- Custom Student Navbar -->
	<nav class="navbar navbar-default navbar-fixed-top student-navbar">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#student-navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="studentportal.php">
					<img src="images/logo.png" alt="Easy Library Logo" class="navbar-logo">
					<!-- <i class="fa fa-book"></i> Easy Library -->
				</a>
			</div>

			<div class="collapse navbar-collapse" id="student-navbar-collapse">
				<ul class="nav navbar-nav">
					<li class="active"><a href="studentportal.php"><i class="fa fa-home"></i> Dashboard</a></li>
					<li><a href="profile.php"><i class="fa fa-user"></i> Profile</a></li>
					<li><a href="borrow-student.php"><i class="fa fa-exchange"></i> Borrow Books</a></li>
					<li><a href="fine-student.php"><i class="fa fa-money"></i> Fines</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li><a href="cart.php"><i class="fa fa-shopping-cart"></i> <span class="cart-count">0</span> Cart</a></li>
					<li class="user-welcome"><i class="fa fa-user-circle"></i> Hello, <?php echo $student; ?></li>
					<li class="logout-btn"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
				</ul>
			</div>
		</div>
	</nav>

	<div class="container">
		<div class="alert welcome-alert">
			<h4><strong>Welcome to your Dashboard,</strong> <span><?php echo $student; ?></span></h4>
		</div>

		<div class="container-fluid slide">
			<div class="slider">
				<div class="carousel" data-flickity='{ "autoPlay": true }'>
					<div class="carousel-cell" auto-play>
						<img src="https://scontent.fccu32-1.fna.fbcdn.net/v/t39.30808-6/462844921_2925090564324442_3810128298719525112_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=0b6b33&_nc_ohc=d697Dx51PRoQ7kNvwERYBxt&_nc_oc=AdlnTXlhPfBXcvfs3icBheDXTsY0taPdSEfkbyz6aZqAknOo2bMU6gH1BP0E2Qbnt6w&_nc_zt=23&_nc_ht=scontent.fccu32-1.fna&_nc_gid=_MB6oNT97jC8wwJNT1le8w&oh=00_AfJfNoo_zRE5T5B-yvDGRe7X_jBddYZMdefd3zSj_MqFfQ&oe=68351495">
					</div>
					<div class="carousel-cell" auto-play>
						<img src="https://pbs.twimg.com/media/EAxM0PMU0AEY9dx.jpg">
					</div>
					<div class="carousel-cell" auto-play>
						<img src="https://pbs.twimg.com/media/EAxM0PMU0AEY9dx.jpg">
					</div>
				</div>
			</div>
		</div>

		<div class="container slide2">
			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 column">
					<div class="feature-box">
						<h2>your Library Portal</h2>
						<p>Welcome to your student library portal. Here you can manage your account, borrow books, check due dates, and pay any outstanding fines.</p>
						<p>Check out your extensive collection of books and digital resyources to help with your studies.</p>
						<a href="borrow-student.php"><p class="slide2"><button class="btn btn-success">Borrow Books</button></p></a>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 column">
					<div class="feature-box">
						<h2>24/7 Online Access</h2>
						<p>Access the library portal any time, from anywhere. Check book availability, manage your borrowings, and renew books online.</p>
						<p>your digital resyources are available round the clock to help you with your research and assignments.</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 column">
					<div class="feature-box">
						<h2>How It Works</h2>
						<p>Browse your catalog to find books of interest. Request a book to borrow, and collect it from the library desk.</p>
						<p>Return books by their due date to avoid fines. Need more time? Renew your books through your account.</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid slide3" style="background-color: #f8f9fa; padding: 30px 0; margin-top: 30px;">
		<div class="container">
			<h2 class="text-center" style="margin-bottom: 30px; color: #0a9396;">Featured Collections</h2>
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<a href="#" class="thumbnail">
						<img src="https://assets.collegedunia.com/public/college_data/images/appImage/1593608842Cover.jpg" alt="Featured Collection">
					</a>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<a href="#" class="thumbnail">
						<img src="https://content3.jdmagicbox.com/comp/kolkata/b8/033pxx33.xx33.220623125615.m8b8/catalogue/regent-education-and-research-foundation-sewli-telinipara-niliganj-bazar-kolkata-colleges-x7lt7pm9tn.jpg" alt="Featured Collection">
					</a>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<a href="#" class="thumbnail">
						<img src="https://images.shiksha.com/mediadata/images/1727327215phppBPeax.jpeg" alt="Featured Collection">
					</a>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<a href="#" class="thumbnail">
						<img src="https://www.sikshapedia.com/public/data/colleges/regent-education-and-research-foundation-kolkata-west-bengal/h72XYejbHE.webp" alt="Featured Collection">
					</a>
				</div>
			</div>
		</div>
	</div>

	<div class="container text-center" style="margin: 40px auto;">
		<h3>Need help with your library account?</h3>
		<p style="margin: 20px 0;">
			<a href="contact.php"><button class="btn btn-primary">Contact Support</button></a>
			<!-- <a href="#"><button class="btn btn-info">Library FAQ</button></a> -->
		</p>
	</div>

	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script>
		$(document).ready(function() {
			// Update cart count
			function updateCartCount() {
				var cart = JSON.parse(localStorage.getItem('library_cart')) || [];
				$('.cart-count').text(cart.length);
			}
			
			// Initialize
			updateCartCount();
		});
	</script>
</body>
</html>